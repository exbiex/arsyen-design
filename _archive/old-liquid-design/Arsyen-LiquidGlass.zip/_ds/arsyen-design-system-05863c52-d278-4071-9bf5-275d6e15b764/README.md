# arsyen — Design System

> **arsyen** is an app **for artists only**. It is a dark, **embossed (neumorphic)**,
> cinematic space where artists keep a portfolio, share work, discover other
> artists, and manage commissions. Restraint is the product: the interface gets
> out of the way so the work is the brightest thing on the screen.
>
> **Aesthetic pillars — Black · Minimal · Embossed · Cinematic.**

---

## 1. Product context

arsyen is a members-only home for working artists — illustrators, 3D artists,
photographers, designers, painters. The app is **mobile-first** (the primary
surface) with a complementary **marketing / landing** web surface.

Core jobs the product does for an artist:

- **Portfolio** — a clean, gallery-grade presentation of their work.
- **Discover / Feed** — a curated, low-noise stream of other artists' work.
- **Artwork detail** — full-bleed viewing, metadata (medium, year, tools), saves.
- **Commissions / Inbox** — receive and manage commission requests.
- **Profile / Studio** — identity, stats, settings.

Because the audience is artists, **detail and craft matter more than usual**.
Chrome is quiet and matt so that color and imagery (the art) carry all the
energy. The single coral accent is used sparingly, like a signature.

### Sources provided
The brand was delivered as a **mood / direction board** (no codebase, no Figma):

- `uploads/IMG_3085.jpeg` — **official brand swatches**: `#EAEAEA` (paper),
  `#26282B` (ink), `#FF555D` (coral). → saved to `assets/brand-swatches.jpeg`.
- `uploads/IMG_3086–3089.PNG` — PlayStation app screens (glass top bars, rounded
  dark cards, pill tabs, white CTAs) — **interaction & surface reference**.
- `uploads/*.jpg` — a set of dark/minimal UI references: notes app, workout app,
  knowledge bases, dark CRM, neumorphic calendar, matt-black pricing page.
  These set the **matt-black + squircle-card + monochrome-icon** language.

> ⚠️ **There is no source codebase or Figma.** The system below is built from the
> explicit brand swatches plus the aesthetic direction in the boards. If a real
> product spec, codebase, or Figma exists, re-attach it and this system can be
> tightened to match exactly.

---

## 2. Content fundamentals — voice & copy

arsyen speaks like a **quiet, confident gallery** — never a hype-y consumer app.

| Trait | Rule | Example |
|---|---|---|
| **Person** | Address the artist as **you**; arsyen refers to itself rarely, never "we're so excited". | "Your work, the way you meant it." |
| **Casing** | **Sentence case** everywhere — buttons, titles, nav. Reserve ALL-CAPS for tiny mono labels/metadata only. | Button: "Add work" · Label: `MEDIUM` |
| **Tone** | Calm, precise, a little reverent toward the craft. Short lines. No exclamation marks. | "Nothing here yet. When you add work, it lives here." |
| **Length** | Terse. Empty states are one sentence. Helper text is one line. | "Drop a file or browse." |
| **Numbers / units** | Lowercase units, mono font. `2.4k views`, `12 works`, `oil on linen`. | — |
| **Emoji** | **Never.** The system is monochrome and serious; emoji break it. | — |
| **Jargon** | Use artists' real vocabulary: *medium, edition, study, commission, plate, series*. Avoid SaaS-speak ("onboard", "leverage"). | — |

**Microcopy vibe examples**
- Empty portfolio → *"Nothing here yet. When you add work, it lives here."*
- Commission request → *"Mara wants to commission you."*
- Save confirmation → *"Saved to your collection."*
- Error → *"That didn't upload. Try again."* (plain, no blame, no jokes)
- CTA verbs → *Add work · Follow · Save · Request · Publish.* (short, active)

---

## 3. Visual foundations

The whole system is **matt** — no glossy gradients, no shiny rims. Depth comes
from layered near-black surfaces, deep diffuse shadows, and frosted glass.

### Color
- **One accent only: coral `#FF555D`.** It marks the single most important action
  per view (primary CTA, active nav, unread dot, selected state). If two things
  are coral, one is wrong.
- **Everything else is monochrome** on a matt-black ramp:
  `--bg-base #0B0C0D` → `--surface-1 #161719` → `--surface-2 #1F2123` →
  `--surface-3 #26282B` (the brand ink) → `--surface-4 #303237`.
- Text ramp: `--fg-1 #EDEDEE` (primary) · `--fg-2 #9B9DA2` (secondary) ·
  `--fg-3 #66686D` (muted/placeholder).
- **Imagery is the color.** Artwork thumbnails are the only saturated things on
  screen — the UI stays grayscale so the work pops. Default to full-color art;
  the chrome never competes.

### Type
- **Space Grotesk** — display & headings, and all big numerics (stats, counts).
  Tight tracking on large sizes (`-0.02em`/`-0.03em`).
- **Hanken Grotesk** — all UI and body text. Neutral, legible.
- **Space Mono** — tiny uppercase labels and metadata (`MEDIUM`, `2024`,
  `EDITION 3/10`) with `+0.06em` tracking. Mono signals "data", not "prose".

### Spacing & layout
- **4pt base grid** (`--sp-*`). Cards pad `16–24px`. Screen gutter `20px` on mobile.
- Generous vertical rhythm — lots of black breathing room around content.
- **Fixed glass chrome**: the top bar and bottom tab bar are sticky, frosted,
  and float above scrolling content (see Glass).

### Corner radii (soft squircles)
- Inputs / chips: `--r-sm 10px` · Cards: `--r-md 16px` · Sheets / big tiles:
  `--r-lg 22px` · Hero tiles: `--r-xl 30px` · Pills & avatars: `--r-pill`.
- The squircle look (large, even radii) is core — nothing is sharp-cornered.

### Cards & surfaces (EMBOSSED — the core motif)
- The entire UI is **embossed / neumorphic**, extruded from the matt ink base
  `--neu-base #26282B`. Every surface uses the paired-shadow system with a
  **top-left light source**: a dark shadow bottom-right + a faint light shadow
  top-left.
- **Raised (convex)** = default resting state of cards, buttons, chips, avatars,
  tab bar → `--neu-raise` / `--neu-raise-sm` / `--neu-raise-lg`.
- **Pressed / selected / active (concave)** = `--neu-inset` / `--neu-inset-sm`.
  Segmented controls are an inset trough with a raised active thumb; selected
  chips and active nav icons press *in*.
- **Artwork seats** sit in a recessed well (`--neu-inset-sm` + a 1px inner dark
  ring) so the image reads as set *into* the surface.
- A content card's **only affordance is to open** — the whole card is the tap
  target, with a chevron and an `Open · details` (or `For sale · $…`) label in the
  footer. **No bookmark/save button on cards** (save lives on the detail screen).
- **No flat cards, no plain 1px-border boxes, no colored left-border accents, no
  emoji cards, no purple gradients, no glossy rims** (the finish is matt).

### Glass (secondary, used sparingly)
- Glass is now reserved for the rare floating overlay (toasts, the share/more
  buttons that sit *on top of* full-bleed artwork). The primary chrome is
  **embossed**, not frosted. `--glass-fill` + `backdrop-filter` still exist for
  those over-image moments.

### Elevation & shadows
- Three-step diffuse shadow ramp (`--shadow-1/2/3`) — all soft, all black, no
  spread of color. Glass panels use `--shadow-glass` (deeper).
- The coral "neon halo" (`--halo-coral`) appears only on focus/glow moments
  (focused input, the live-recording pill) — echoing the glowing-pill reference.

### Borders
- Hairlines (`rgba(255,255,255,.07–.16)`) do most dividing work. Coral borders
  only on focused/selected fields (`--border-coral`).

### Motion
- **Easing:** `--ease-out` `cubic-bezier(.22,1,.36,1)` — a confident settle, no
  bounce. Durations `120/200/360ms`.
- Fades + small (4–8px) translates. Sheets slide up from the bottom. Press
  states **scale down to ~0.97** and darken; hover **lightens the surface one
  step**. No spinning, no infinite decorative loops.

### Hover / press
- **Hover:** surface lightens one ramp step (e.g. `surface-1 → surface-2`); text
  goes `fg-2 → fg-1`. **Press:** `transform: scale(.97)` + one step darker.
- Primary (coral) button: hover `--coral-hover`, press `--coral-press` + scale.

### Imagery
- Artwork is shown **true to color** — warm or cool, the artist's choice — never
  filtered. Chrome around it is neutral. Placeholder/empty slots are matt-gray
  squircles. Use the `image-slot` component for user-supplied art.

---

## 4. Iconography

- **Style:** thin, **1.5px stroke**, rounded caps/joins, monochrome, currentColor
  — matching the line-icon feel across every reference board. No filled icons
  except the **active** bottom-nav item and tiny status dots.
- **Source:** [**Lucide**](https://lucide.dev) (CDN), the closest match to the
  references' uniform thin-stroke line set. Loaded via the Lucide CDN script in
  the UI kits.
  > ⚠️ **Substitution flag:** no original arsyen icon set was provided. Lucide is
  > used as the stand-in because it matches the stroke weight and rounded
  > terminals seen in the boards. Swap for the real set when available.
- **Sizing:** `20px` inline / nav, `24px` toolbar, `16px` for metadata rows.
  Icons inherit text color and dim with their label.
- **Emoji / unicode:** **never** used as icons. The brand mark is a wordmark, not
  an emoji.
- **Logo:** arsyen uses a lowercase **wordmark** (`arsyen` in Space Grotesk,
  weight 600, tight tracking), plus a monogram **"a"** glyph for app-icon / avatar
  contexts. See `assets/logo.html` for both lockups.

---

## 5. Index — what's in this folder

| Path | What it is |
|---|---|
| `README.md` | This file — context, voice, visual foundations, iconography. |
| `styles.css` | Global entry the compiler reads; imports the tokens. |
| `colors_and_type.css` | All CSS variables (color, type, spacing, radii, motion) + semantic text classes. |
| `assets/` | Brand swatches, logo lockups, and any shared imagery. |
| `preview/` | Design-system **cards** (the Design System tab specimens). |
| `ui_kits/app/` | **arsyen mobile app** UI kit — embossed screens + JSX components. |
| `ui_kits/web/` | **arsyen web app** UI kit — embossed shell, bottom tab bar, 5 core views. |
| `SKILL.md` | Agent-Skills manifest so this system can be used in Claude Code. |

### UI kits
- **`ui_kits/app/`** — the core product: embossed home feed, discover grid,
  artwork detail, commissions inbox, profile/studio, and an add-work composer.
  `index.html` is a click-through prototype (tap cards to open details, switch
  tabs, reply to commissions). Built from `Icon.jsx` · `UI.jsx` · `Chrome.jsx` ·
  `data.jsx` · `Screens.jsx` · `App.jsx`.
- **`ui_kits/web/`** — the **web app** (the desktop product itself, not a marketing
  page): an embossed shell with a top brand bar (the **top-right avatar opens
  Profile**) and a floating **bottom tab bar** — Projects · Discover · Feed + Chat
  · Tools · Settings — that swaps the central embossed surface. Views:
  **Go to Project** (collapsible Projects Navigator + project detail with a
  Board / **Canvas** / Milestones / Files switch; Canvas is an endless Notion-like
  doc whose inline tasks sync to the Board), **Discover** (search + filters +
  **portrait** featured/relevant artist cards to form a crew), **Feed + Chat**
  (media-only masonry feed → click opens an embossed post-detail overlay with
  comments + threads; collapsible Instagram-like chat list), **Tools** (grid of
  embossed square tools → each opens a full-screen tool page), and **Settings**.
  Built from `WebData.jsx`, `WebProjects.jsx`, `WebDiscover.jsx`, `WebFeed.jsx`,
  `WebTools.jsx`, `WebProfile.jsx`, `WebSettings.jsx`, `WebApp.jsx` (reuses the app
  kit's `Icon.jsx` / `UI.jsx`).
