/* @ds-bundle: {"format":3,"namespace":"ArsyenDesignSystem_05863c","components":[],"sourceHashes":{"ui_kits/app/AppProjects.jsx":"2af21ef1e0df","ui_kits/app/AppShell.jsx":"3fb1457ed840","ui_kits/app/AppSocial.jsx":"caca97b85977","ui_kits/app/Icon.jsx":"806e0e123fd6","ui_kits/app/UI.jsx":"233e983fd943","ui_kits/app/ios-frame.jsx":"be3343be4b51","ui_kits/web/WebApp.jsx":"0341ebc96966","ui_kits/web/WebChat.jsx":"42e983d502dd","ui_kits/web/WebData.jsx":"a8cc16fff5db","ui_kits/web/WebDiscover.jsx":"1155c75d484a","ui_kits/web/WebFeed.jsx":"b96046c74e56","ui_kits/web/WebProfile.jsx":"bd5c805cdc16","ui_kits/web/WebProjects.jsx":"d1fdfff6fb54","ui_kits/web/WebSettings.jsx":"a3f5fffc11d9","ui_kits/web/WebTools.jsx":"d4504d021b52"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ArsyenDesignSystem_05863c = window.ArsyenDesignSystem_05863c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/app/AppProjects.jsx
try { (() => {
// arsyen mobile — shared chrome + Projects flow (list → detail: Canvas / Board / Resources)
// Reuses: Icon, Button, Chip, Segmented, Avatar, ArtFill, IconBtn, StatBlock, WEB_* data

const APP_STAGE = {
  'To do': {
    c: 'var(--fg-3)',
    key: 'TODO'
  },
  'In progress': {
    c: 'var(--coral)',
    key: 'WIP'
  },
  'Review': {
    c: '#5B9DFF',
    key: 'REV'
  },
  'Done': {
    c: '#4ADE80',
    key: 'DONE'
  }
};
function AppTopBar({
  title,
  sub,
  onBack,
  right
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 20,
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '12px 16px',
      background: 'var(--neu-base)',
      boxShadow: '0 6px 16px rgba(0,0,0,0.35), var(--neu-hairline)'
    }
  }, onBack && /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 20,
      letterSpacing: '-0.015em',
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginTop: 1
    }
  }, sub)), right);
}
function StatusPill({
  status
}) {
  const map = {
    'In production': 'var(--coral)',
    'In review': '#5B9DFF',
    'Planning': '#F5B544'
  };
  const c = map[status] || 'var(--fg-3)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: c
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: c,
      boxShadow: `0 0 7px ${c}`
    }
  }), status);
}
function Crew({
  crew,
  size = 22
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex'
    }
  }, crew.map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      marginLeft: i ? -7 : 0,
      borderRadius: 999,
      boxShadow: '0 0 0 3px var(--neu-base)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: a,
    size: size
  }))));
}

// ---------- PROJECTS LIST ----------
function ProjectsView({
  onOpen,
  onProfile
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 96
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: "Projects",
    sub: `${WEB_PROJECTS.length} active`,
    right: /*#__PURE__*/React.createElement("button", {
      onClick: onProfile,
      style: {
        border: 'none',
        background: 'transparent',
        padding: 0,
        cursor: 'pointer',
        borderRadius: 999
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      index: WEB_ME.avatar,
      size: 34
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 0',
      display: 'grid',
      gap: 14
    }
  }, WEB_PROJECTS.map(p => /*#__PURE__*/React.createElement(ProjectCard, {
    key: p.id,
    p: p,
    onOpen: () => onOpen(p)
  }))));
}
function ProjectCard({
  p,
  onOpen
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onOpen,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-lift)',
      cursor: 'pointer',
      overflow: 'hidden',
      transform: pressed ? 'scale(0.99)' : 'none',
      transition: 'box-shadow 180ms var(--ease-out), transform 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 120,
      borderRadius: 12,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: p.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(90deg, rgba(11,12,13,0.65), transparent 70%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 14,
      bottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(StatusPill, {
    status: p.status
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 18,
      letterSpacing: '-0.015em',
      color: '#fff'
    }
  }, p.title)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '4px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement(Crew, {
    crew: p.crew
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.05em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, p.role), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 7,
      borderRadius: 999,
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset-sm)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${p.progress}%`,
      height: '100%',
      borderRadius: 999,
      background: 'var(--coral)',
      boxShadow: '0 0 8px var(--coral-glow)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-1)'
    }
  }, p.progress, "%")));
}

// ---------- PROJECT DETAIL ----------
function ProjectDetailScreen({
  project,
  onBack,
  onOpenTool
}) {
  const [tab, setTab] = React.useState('Canvas');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 50,
      background: 'var(--neu-base)',
      display: 'flex',
      flexDirection: 'column',
      animation: 'sheetUp 260ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 132,
      flexShrink: 0,
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: project.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(transparent 30%, rgba(11,12,13,0.85))'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 16,
      bottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(StatusPill, {
    status: project.status
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: '#fff'
    }
  }, project.title))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 20,
      left: 20
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    glass: true,
    onClick: onBack
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 20,
      right: 20
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "more",
    glass: true
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px 0',
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    options: ['Canvas', 'Board', 'Resources', 'Files'],
    value: tab,
    onChange: setTab
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto'
    }
  }, tab === 'Canvas' && /*#__PURE__*/React.createElement(MobileCanvas, {
    project: project
  }), tab === 'Board' && /*#__PURE__*/React.createElement(MobileBoard, {
    project: project
  }), tab === 'Resources' && /*#__PURE__*/React.createElement(MobileResources, {
    onOpenTool: onOpenTool
  }), tab === 'Files' && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, [0, 1, 2, 3].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 90,
      borderRadius: 9,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: (project.art + i) % 8
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--fg-3)',
      marginTop: 7
    }
  }, "plate_", String(i + 1).padStart(2, '0'), ".tif"))))));
}

// ---------- MOBILE CANVAS (notion-style doc) ----------
function MobileCanvas({
  project
}) {
  const blocks = [{
    type: 'h1',
    text: project.title
  }, {
    type: 'text',
    text: 'Single source of truth — notes, references, and tasks live here. Tasks created on the canvas sync to the Board.'
  }, {
    type: 'h2',
    text: 'Look & references'
  }, {
    type: 'images',
    imgs: [2, 6]
  }, {
    type: 'bullet',
    text: 'Cold key light, warm practicals.'
  }, {
    type: 'bullet',
    text: 'Grain held deliberately — analog soul.'
  }, {
    type: 'h2',
    text: 'Reference reel'
  }, {
    type: 'video',
    src: 'nightwork_ref.mp4'
  }, {
    type: 'todo',
    text: 'Confirm festival deadline',
    who: 0
  }, {
    type: 'todo',
    text: 'Book grading suite',
    who: 1,
    done: true
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 18px 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 10
    }
  }, "Canvas \xB7 tap \u283F to add a block"), blocks.map((b, i) => /*#__PURE__*/React.createElement(MobileBlock, {
    key: i,
    b: b
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '10px 2px',
      color: 'var(--fg-3)',
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 15
  }), " Add a block\u2026"));
}
function MobileBlock({
  b
}) {
  const t = b.type;
  if (t === 'h1') return /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 26,
      letterSpacing: '-0.02em',
      color: 'var(--fg-1)',
      margin: '2px 0 8px'
    }
  }, b.text);
  if (t === 'h2') return /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 18,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em',
      margin: '20px 0 10px'
    }
  }, b.text);
  if (t === 'text') return /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 15,
      lineHeight: 1.55,
      color: 'var(--fg-2)',
      margin: '0 0 8px'
    }
  }, b.text);
  if (t === 'bullet') return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      padding: '3px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: 'var(--fg-3)',
      marginTop: 8
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 14.5,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, b.text));
  if (t === 'images') return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10,
      margin: '4px 0 8px'
    }
  }, b.imgs.map(idx => /*#__PURE__*/React.createElement("div", {
    key: idx,
    style: {
      padding: 6,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 100,
      borderRadius: 8,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  })))));
  if (t === 'video') return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 180,
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)',
      margin: '4px 0 8px'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: 3
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(0,0,0,0.35)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 52,
      height: 52,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "22",
    height: "22",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  })))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 12,
      bottom: 10,
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      textTransform: 'uppercase',
      color: '#fff',
      background: 'rgba(0,0,0,0.5)',
      padding: '4px 9px',
      borderRadius: 999
    }
  }, "YouTube \xB7 ", b.src));
  if (t === 'todo') return /*#__PURE__*/React.createElement(MobileTodo, {
    b: b
  });
  return null;
}
function MobileTodo({
  b
}) {
  const [done, setDone] = React.useState(!!b.done);
  return /*#__PURE__*/React.createElement("div", {
    onClick: () => setDone(d => !d),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: '10px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      margin: '4px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: 6,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: done ? 'var(--coral)' : 'var(--neu-base)',
      color: 'var(--fg-on-coral)',
      boxShadow: done ? '2px 2px 5px rgba(0,0,0,0.4)' : 'var(--neu-inset-sm)'
    }
  }, done && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 13
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-text)',
      fontSize: 14,
      color: done ? 'var(--fg-3)' : 'var(--fg-1)',
      textDecoration: done ? 'line-through' : 'none'
    }
  }, b.text), /*#__PURE__*/React.createElement(Avatar, {
    index: b.who,
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8,
      textTransform: 'uppercase',
      color: 'var(--coral)'
    }
  }, "\u2192 board"));
}

// ---------- MOBILE BOARD (horizontal stages + task sheet) ----------
function MobileBoard({
  project
}) {
  const cols = Object.keys(project.stages);
  const [who, setWho] = React.useState('all');
  const [sel, setSel] = React.useState(null);
  const f = t => who === 'all' || t.who === who;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 30
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '14px 16px 6px',
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setWho('all'),
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      border: 'none',
      cursor: 'pointer',
      borderRadius: 999,
      padding: '7px 14px',
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 13,
      background: 'var(--neu-base)',
      color: who === 'all' ? 'var(--coral)' : 'var(--fg-2)',
      boxShadow: who === 'all' ? 'var(--neu-inset-sm)' : 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "users",
    size: 14
  }), " All"), project.crew.map(a => /*#__PURE__*/React.createElement("button", {
    key: a,
    onClick: () => setWho(a),
    style: {
      flexShrink: 0,
      border: 'none',
      cursor: 'pointer',
      padding: 3,
      borderRadius: 999,
      background: 'transparent',
      boxShadow: who === a ? 'var(--neu-inset)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      borderRadius: 999,
      boxShadow: who === a ? '0 0 0 2px var(--coral)' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: a,
    size: 28
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      padding: '8px 16px',
      overflowX: 'auto'
    }
  }, cols.map(c => {
    const items = project.stages[c].map((t, i) => ({
      t,
      i
    })).filter(({
      t
    }) => f(t));
    return /*#__PURE__*/React.createElement("div", {
      key: c,
      style: {
        width: 252,
        flexShrink: 0,
        borderRadius: 'var(--r-md)',
        background: 'var(--neu-well)',
        boxShadow: 'var(--neu-inset)',
        padding: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        padding: '2px 2px 12px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 7,
        height: 7,
        borderRadius: 999,
        background: APP_STAGE[c].c
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        color: 'var(--fg-2)'
      }
    }, c), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        color: 'var(--fg-3)'
      }
    }, items.length)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gap: 10
      }
    }, items.map(({
      t,
      i
    }) => /*#__PURE__*/React.createElement("div", {
      key: i,
      onClick: () => setSel({
        t,
        stage: c,
        num: i + 1
      }),
      style: {
        padding: '11px 12px',
        borderRadius: 11,
        cursor: 'pointer',
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-lift)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontFamily: 'var(--font-text)',
        fontSize: 13,
        color: 'var(--fg-1)'
      }
    }, t.t), /*#__PURE__*/React.createElement(Avatar, {
      index: t.who,
      size: 20
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 8.5,
        color: 'var(--fg-3)',
        marginTop: 8
      }
    }, APP_STAGE[c].key, "-", i + 1))), items.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 12,
        textAlign: 'center',
        fontFamily: 'var(--font-text)',
        fontSize: 12,
        color: 'var(--fg-3)'
      }
    }, "\u2014")));
  })), sel && /*#__PURE__*/React.createElement(MobileTaskSheet, {
    sel: sel,
    onClose: () => setSel(null)
  }));
}
function MobileTaskSheet({
  sel,
  onClose
}) {
  const {
    t,
    stage,
    num
  } = sel;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 60,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      background: 'rgba(5,5,6,0.5)',
      animation: 'fadeIn 160ms var(--ease-out)'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      maxHeight: '88%',
      overflowY: 'auto',
      borderRadius: '24px 24px 0 0',
      background: 'var(--neu-base)',
      boxShadow: '0 -20px 50px rgba(0,0,0,0.6)',
      padding: '8px 18px 28px',
      animation: 'sheetUp 280ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 4,
      borderRadius: 999,
      background: 'var(--surface-4)',
      margin: '8px auto 16px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)',
      padding: '5px 10px',
      borderRadius: 999,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, APP_STAGE[stage].key, "-", num), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 19,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em'
    }
  }, t.t)), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset)',
      padding: '4px 16px',
      marginBottom: 16
    }
  }, [['Status', stage, APP_STAGE[stage].c], ['Assignee', null, null], ['Priority', 'Medium', '#F5B544'], ['Type', 'Task', null], ['Story points', '3', null]].map((row, i, arr) => /*#__PURE__*/React.createElement("div", {
    key: row[0],
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '12px 0',
      boxShadow: i < arr.length - 1 ? 'var(--neu-hairline)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 100,
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.05em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, row[0]), row[0] === 'Assignee' ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: t.who,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-1)'
    }
  }, "Crew")) : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fg-1)',
      padding: '5px 12px',
      borderRadius: 999,
      boxShadow: 'var(--neu-lift)'
    }
  }, row[2] && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: row[2]
    }
  }), row[1])))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 10
    }
  }, "Attachments"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginBottom: 16
    }
  }, [2, 6].map(idx => /*#__PURE__*/React.createElement("div", {
    key: idx,
    style: {
      width: 96,
      height: 64,
      borderRadius: 10,
      boxShadow: 'var(--neu-lift)',
      padding: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      borderRadius: 7,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 10
    }
  }, "Comments"), [{
    who: 3,
    name: 'Søren',
    when: '3h',
    text: 'Pushed a rough — the swell still feels late.'
  }].map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: c.who,
    size: 26
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '9px 12px',
      borderRadius: '4px 12px 12px 12px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 12.5,
      color: 'var(--fg-1)'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, c.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      lineHeight: 1.4,
      color: 'var(--fg-2)'
    }
  }, c.text)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '7px 7px 7px 16px',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Comment\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 13
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 15
  })))));
}

// ---------- MOBILE RESOURCES (link to tools) ----------
function MobileResources({
  onOpenTool
}) {
  const groups = [{
    group: 'Moodboards',
    tool: 'Moodboard',
    icon: 'palette',
    items: [{
      name: 'Nightwork — look dev',
      art: 2,
      when: 'Jun 2'
    }, {
      name: 'Lighting refs',
      art: 6,
      when: 'May 28'
    }]
  }, {
    group: 'Scripts',
    tool: 'Brief builder',
    icon: 'fileText',
    items: [{
      name: 'Shooting script v3',
      when: 'Jun 4',
      meta: '14 pages'
    }]
  }, {
    group: 'Invoices',
    tool: 'Invoice',
    icon: 'briefcase',
    items: [{
      name: 'INV ARS-014',
      when: 'Jun 1',
      meta: '$1,800'
    }]
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-3)',
      marginBottom: 16
    }
  }, "Artefacts created in ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--fg-2)'
    }
  }, "Tools"), ", linked to this project."), groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.group,
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 8,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: g.icon,
    size: 14
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      letterSpacing: '0.07em',
      textTransform: 'uppercase',
      color: 'var(--fg-2)'
    }
  }, g.group), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, "\xB7 from ", g.tool)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 10
    }
  }, g.items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    onClick: () => onOpenTool && onOpenTool(g.tool),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: 10,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      cursor: 'pointer'
    }
  }, it.art != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 44,
      borderRadius: 9,
      overflow: 'hidden',
      flexShrink: 0,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: it.art
  })) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 11,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-3)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: g.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, it.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)',
      marginTop: 3
    }
  }, it.when, it.meta ? ` · ${it.meta}` : '')), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--coral)'
    }
  }, "Open ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 12
  }))))))));
}
Object.assign(window, {
  AppTopBar,
  StatusPill,
  Crew,
  ProjectsView,
  ProjectDetailScreen,
  MobileResources,
  APP_STAGE
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppProjects.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AppShell.jsx
try { (() => {
// arsyen mobile — app shell: logo splash + bottom tab bar (web-kit aesthetics) + Search mode + routing
const APP_TABS = [{
  id: 'projects',
  icon: 'folder',
  label: 'Projects'
}, {
  id: 'discover',
  icon: 'compass',
  label: 'Discover'
}, {
  id: 'feed',
  icon: 'feed',
  label: 'Feed'
}, {
  id: 'tools',
  icon: 'grid',
  label: 'Tools'
}, {
  id: 'search',
  icon: 'search',
  label: 'Search'
}, {
  id: 'settings',
  icon: 'settings',
  label: 'Settings'
}];

// ---------- LOGO SPLASH (load-up) ----------
function LogoSplash({
  onDone
}) {
  const [leaving, setLeaving] = React.useState(false);
  React.useEffect(() => {
    const a = setTimeout(() => setLeaving(true), 2300);
    const b = setTimeout(() => onDone(), 2900);
    return () => {
      clearTimeout(a);
      clearTimeout(b);
    };
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 200,
      background: '#000',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      opacity: leaving ? 0 : 1,
      transition: 'opacity 600ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      mixBlendMode: 'screen',
      background: 'radial-gradient(50% 60% at 22% 76%, rgba(255,60,90,0.10), transparent 60%), radial-gradient(50% 60% at 82% 26%, rgba(60,130,255,0.10), transparent 60%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "splash-mark",
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 800,
      fontSize: 52,
      letterSpacing: '-0.04em',
      color: '#eef2ff',
      textShadow: '-2px 0 6px rgba(255,45,85,0.45), 2px 0 6px rgba(58,107,255,0.45)'
    }
  }, "arsye", /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: '-0.06em'
    }
  }, "n")), /*#__PURE__*/React.createElement("div", {
    className: "splash-tag",
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      color: '#7a7d86',
      marginTop: 14
    }
  }, "Members only \xB7 by invitation"));
}

// ---------- BOTTOM BAR (matches web kit: pill, active tab inset + label) ----------
function AppTabBar({
  active,
  onChange,
  searchOpen,
  onToggleSearch
}) {
  const [q, setQ] = React.useState('');
  const inputRef = React.useRef(null);
  React.useEffect(() => {
    if (searchOpen && inputRef.current) inputRef.current.focus();
  }, [searchOpen]);
  if (searchOpen) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 40,
        padding: '11px 14px max(11px, env(safe-area-inset-bottom))',
        background: 'var(--neu-base)',
        boxShadow: '0 -10px 24px rgba(0,0,0,0.35), 0 -0.5px 0 rgba(255,255,255,0.05) inset'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 8px 8px 18px',
        borderRadius: 999,
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-inset)',
        animation: 'barExpand 220ms var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "search",
      size: 19,
      style: {
        color: 'var(--coral)'
      }
    }), /*#__PURE__*/React.createElement("input", {
      ref: inputRef,
      value: q,
      onChange: e => setQ(e.target.value),
      placeholder: "Search artists, projects, work\u2026",
      style: {
        flex: 1,
        background: 'transparent',
        border: 'none',
        outline: 'none',
        color: 'var(--fg-1)',
        fontFamily: 'var(--font-text)',
        fontSize: 15
      }
    }), /*#__PURE__*/React.createElement("button", {
      onClick: () => {
        setQ('');
        onToggleSearch();
      },
      style: {
        width: 40,
        height: 40,
        flexShrink: 0,
        borderRadius: 999,
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--fg-2)',
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-raise-sm)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "close",
      size: 18
    }))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      zIndex: 40,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      padding: '10px 6px max(10px, env(safe-area-inset-bottom))',
      background: 'var(--neu-base)',
      boxShadow: '0 -10px 24px rgba(0,0,0,0.35), 0 -0.5px 0 rgba(255,255,255,0.05) inset'
    }
  }, APP_TABS.map(t => {
    const isSearch = t.id === 'search';
    const on = !isSearch && active === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => isSearch ? onToggleSearch() : onChange(t.id),
      title: t.label,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        border: 'none',
        cursor: 'pointer',
        padding: on ? '10px 14px' : '10px',
        borderRadius: 999,
        background: 'var(--neu-base)',
        boxShadow: on ? 'var(--neu-inset)' : 'none',
        color: on ? 'var(--coral)' : 'var(--fg-3)',
        transition: 'box-shadow 200ms var(--ease-out), padding 200ms var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: t.icon,
      size: 21
    }), on && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-text)',
        fontWeight: 600,
        fontSize: 13,
        color: 'var(--fg-1)',
        whiteSpace: 'nowrap'
      }
    }, t.label));
  }));
}
function App() {
  const [booted, setBooted] = React.useState(false);
  const [tab, setTab] = React.useState('projects');
  const [searchOpen, setSearchOpen] = React.useState(false);
  const [project, setProject] = React.useState(null); // open project detail
  const [tool, setTool] = React.useState(null); // open tool sheet
  const [profile, setProfile] = React.useState(false); // profile overlay
  const [messages, setMessages] = React.useState(false); // messages overlay

  const openTool = t => {
    const tt = typeof t === 'string' ? WEB_TOOLS.find(x => x.name === t) || WEB_TOOLS[0] : t;
    setTool(tt);
  };
  const overlayUp = project || tool || messages || profile;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      background: 'var(--neu-base)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      overflowY: 'auto',
      WebkitOverflowScrolling: 'touch'
    }
  }, /*#__PURE__*/React.createElement("div", {
    key: tab,
    style: {
      animation: 'slideIn 260ms var(--ease-out)',
      minHeight: '100%'
    }
  }, tab === 'projects' && /*#__PURE__*/React.createElement(ProjectsView, {
    onOpen: setProject,
    onProfile: () => setProfile(true)
  }), tab === 'discover' && /*#__PURE__*/React.createElement(DiscoverView, {
    onMessages: () => setMessages(true),
    onProfile: () => setProfile(true)
  }), tab === 'feed' && /*#__PURE__*/React.createElement(FeedView, {
    onProfile: () => setProfile(true)
  }), tab === 'tools' && /*#__PURE__*/React.createElement(ToolsView, {
    onOpenTool: openTool,
    onProfile: () => setProfile(true)
  }), tab === 'settings' && /*#__PURE__*/React.createElement(SettingsView, {
    onProfile: () => setProfile(true)
  }))), project && /*#__PURE__*/React.createElement(ProjectDetailScreen, {
    project: project,
    onBack: () => setProject(null),
    onOpenTool: openTool
  }), tool && /*#__PURE__*/React.createElement(ToolSheet, {
    tool: tool,
    onClose: () => setTool(null)
  }), messages && /*#__PURE__*/React.createElement(MessagesScreen, {
    onBack: () => setMessages(false)
  }), profile && /*#__PURE__*/React.createElement(ProfileScreen, {
    onBack: () => setProfile(false)
  }), !overlayUp && /*#__PURE__*/React.createElement(AppTabBar, {
    active: tab,
    onChange: t => {
      setSearchOpen(false);
      setTab(t);
    },
    searchOpen: searchOpen,
    onToggleSearch: () => setSearchOpen(s => !s)
  }), !booted && /*#__PURE__*/React.createElement(LogoSplash, {
    onDone: () => setBooted(true)
  }));
}
ReactDOM.createRoot(document.getElementById('app')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AppSocial.jsx
try { (() => {
// arsyen mobile — Discover (+ Messages), Feed, Tools, Settings, Profile
// Reuses: Icon, Button, Chip, Segmented, Avatar, ArtFill, IconBtn, StatBlock, WEB_* data, AppTopBar

// ---------- DISCOVER ----------
function DiscoverView({
  onMessages,
  onProfile
}) {
  const [active, setActive] = React.useState([]);
  const toggle = f => setActive(p => p.includes(f) ? p.filter(x => x !== f) : [...p, f]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 110
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: "Discover",
    right: /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(IconBtn, {
      name: "chat",
      onClick: onMessages
    }), /*#__PURE__*/React.createElement("button", {
      onClick: onProfile,
      style: {
        border: 'none',
        background: 'transparent',
        padding: 0,
        cursor: 'pointer',
        borderRadius: 999
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      index: WEB_ME.avatar,
      size: 34
    })))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '12px 16px',
      color: 'var(--fg-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 17
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }, "Search artists, skills\u2026"), /*#__PURE__*/React.createElement(Icon, {
    name: "sliders",
    size: 15
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      margin: '14px -16px 0',
      padding: '0 16px'
    }
  }, DISCOVER_FILTERS.map(f => /*#__PURE__*/React.createElement(Chip, {
    key: f,
    active: active.includes(f),
    onClick: () => toggle(f)
  }, f)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 16px 0',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 12
    }
  }, WEB_ARTISTS.map(a => /*#__PURE__*/React.createElement(ArtistCard, {
    key: a.id,
    a: a
  }))));
}
function ArtistCard({
  a
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-lift)',
      overflow: 'hidden',
      cursor: 'pointer',
      transform: pressed ? 'scale(0.98)' : 'none',
      transition: 'box-shadow 180ms var(--ease-out), transform 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 7
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 168,
      borderRadius: 11,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: a.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(transparent 40%, rgba(10,10,12,0.78))'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 8,
      right: 8,
      fontFamily: 'var(--font-mono)',
      fontSize: 8.5,
      color: 'var(--coral)',
      background: 'var(--glass-fill)',
      WebkitBackdropFilter: 'blur(12px)',
      backdropFilter: 'blur(12px)',
      border: '1px solid var(--glass-edge)',
      borderRadius: 999,
      padding: '3px 7px'
    }
  }, a.match, "%"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 10,
      right: 10,
      bottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 14.5,
      color: '#fff',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, a.name), a.open && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      flexShrink: 0,
      background: '#4ADE80',
      boxShadow: '0 0 6px #4ADE80'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,0.72)',
      marginTop: 2,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, a.discipline)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '2px 10px 11px'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    full: true,
    style: {
      padding: '8px',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chat",
    size: 13
  }), " Message"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      flexShrink: 0,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-1)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user",
    size: 15
  }))));
}

// ---------- MESSAGES (instagram-like) ----------
function MessagesScreen({
  onBack
}) {
  const [openId, setOpenId] = React.useState(null);
  const [draft, setDraft] = React.useState('');
  const [mode, setMode] = React.useState('direct');
  const chat = [...WEB_CHATS, ...WEB_COMMUNITIES].find(c => c.id === openId);
  const isCommunity = chat && chat.members != null;
  if (chat) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        zIndex: 55,
        background: 'var(--neu-base)',
        display: 'flex',
        flexDirection: 'column',
        animation: 'sheetUp 220ms var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement(AppTopBar, {
      title: chat.name,
      sub: isCommunity ? `${chat.members} members` : chat.online ? 'active now' : 'offline',
      onBack: () => setOpenId(null),
      right: /*#__PURE__*/React.createElement(IconBtn, {
        name: "more"
      })
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: 16,
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, WEB_THREAD.map((m, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 8,
        flexDirection: m.me ? 'row-reverse' : 'row',
        alignItems: 'flex-end'
      }
    }, !m.me && /*#__PURE__*/React.createElement(Avatar, {
      index: m.avatar,
      size: 24
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: '76%'
      }
    }, isCommunity && !m.me && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 9,
        color: 'var(--fg-3)',
        margin: '0 0 3px 4px'
      }
    }, WEB_CREW_NAMES[m.avatar] || 'member'), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '10px 13px',
        borderRadius: m.me ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
        background: m.me ? 'var(--coral)' : 'var(--neu-base)',
        color: m.me ? 'var(--fg-on-coral)' : 'var(--fg-1)',
        boxShadow: m.me ? '3px 3px 8px rgba(0,0,0,0.4)' : 'var(--neu-lift)',
        fontFamily: 'var(--font-text)',
        fontSize: 14,
        lineHeight: 1.45
      }
    }, m.text))))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        borderRadius: 999,
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-inset)',
        padding: '7px 7px 7px 18px'
      }
    }, /*#__PURE__*/React.createElement("input", {
      value: draft,
      onChange: e => setDraft(e.target.value),
      placeholder: "Message\u2026",
      style: {
        flex: 1,
        background: 'transparent',
        border: 'none',
        outline: 'none',
        color: 'var(--fg-1)',
        fontFamily: 'var(--font-text)',
        fontSize: 14
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 38,
        height: 38,
        borderRadius: 999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--coral)',
        color: 'var(--fg-on-coral)',
        boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "send",
      size: 16
    })))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 55,
      background: 'var(--neu-base)',
      display: 'flex',
      flexDirection: 'column',
      animation: 'sheetUp 220ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: "Chat",
    onBack: onBack,
    right: /*#__PURE__*/React.createElement(IconBtn, {
      name: "plus"
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 16px 4px'
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    options: ['Direct', 'Community'],
    value: mode === 'direct' ? 'Direct' : 'Community',
    onChange: v => setMode(v === 'Direct' ? 'direct' : 'community')
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '8px 10px'
    }
  }, mode === 'direct' ? WEB_CHATS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => setOpenId(c.id),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '11px 12px',
      borderRadius: 14,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: c.avatar,
    size: 50
  }), c.online && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 1,
      bottom: 1,
      width: 12,
      height: 12,
      borderRadius: 999,
      background: '#4ADE80',
      boxShadow: '0 0 0 2.5px var(--neu-base)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: c.unread ? 700 : 600,
      fontSize: 15,
      color: 'var(--fg-1)'
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: c.unread ? 'var(--fg-1)' : 'var(--fg-3)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      marginTop: 2
    }
  }, c.last, " \xB7 ", c.when)), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 999,
      flexShrink: 0,
      background: 'var(--coral)',
      boxShadow: '0 0 7px var(--coral-glow)'
    }
  }))) : WEB_COMMUNITIES.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => setOpenId(c.id),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '11px 12px',
      borderRadius: 14,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 50,
      height: 50,
      borderRadius: 14,
      overflow: 'hidden',
      flexShrink: 0,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: c.art
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: c.unread ? 700 : 600,
      fontSize: 15,
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)',
      flexShrink: 0
    }
  }, c.members)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: c.unread ? 'var(--fg-1)' : 'var(--fg-3)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      marginTop: 2
    }
  }, c.last, " \xB7 ", c.when)), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 18,
      height: 18,
      padding: '0 5px',
      borderRadius: 999,
      flexShrink: 0,
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, c.unread)))));
}

// ---------- FEED (media-only) ----------
function FeedView({
  onProfile
}) {
  const [open, setOpen] = React.useState(null);
  const colA = WEB_FEED.filter((_, i) => i % 2 === 0);
  const colB = WEB_FEED.filter((_, i) => i % 2 === 1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 130
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: "Feed",
    right: /*#__PURE__*/React.createElement("button", {
      onClick: onProfile,
      style: {
        border: 'none',
        background: 'transparent',
        padding: 0,
        cursor: 'pointer',
        borderRadius: 999
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      index: WEB_ME.avatar,
      size: 34
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      padding: '14px 16px 4px'
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    active: true
  }, "For you"), /*#__PURE__*/React.createElement(Chip, null, "Following"), /*#__PURE__*/React.createElement(Chip, null, "Painting"), /*#__PURE__*/React.createElement(Chip, null, "3D"), /*#__PURE__*/React.createElement(Chip, null, "Photo")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 14px 0',
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 10,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr)',
      gap: 10
    }
  }, colA.map(p => /*#__PURE__*/React.createElement(FeedPin, {
    key: p.id,
    p: p,
    onOpen: () => setOpen(p)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr)',
      gap: 10,
      marginTop: 20
    }
  }, colB.map(p => /*#__PURE__*/React.createElement(FeedPin, {
    key: p.id,
    p: p,
    onOpen: () => setOpen(p)
  })))), open && /*#__PURE__*/React.createElement(PostDetailSheet, {
    post: open,
    onClose: () => setOpen(null)
  }));
}
function FeedPin({
  p,
  onOpen
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onOpen,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-lift)',
      cursor: 'pointer',
      padding: 4,
      transform: pressed ? 'scale(0.98)' : 'none',
      transition: 'box-shadow 180ms var(--ease-out), transform 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: p.h * 0.62,
      borderRadius: 9,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: p.art
  }), p.kind === 'video' && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 8,
      right: 8,
      width: 26,
      height: 26,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(0,0,0,0.5)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "12",
    height: "12",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: '8px 5px 3px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: p.avatar,
    size: 18
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 12,
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, p.title), /*#__PURE__*/React.createElement("span", {
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 3,
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowUp",
    size: 11
  }), p.up)));
}
function PostDetailSheet({
  post,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 60,
      background: 'var(--neu-base)',
      display: 'flex',
      flexDirection: 'column',
      animation: 'sheetUp 240ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flexShrink: 0,
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 300,
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: post.art
  }), post.kind === 'video' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "24",
    height: "24",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 20,
      left: 20
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    glass: true,
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 20,
      right: 20,
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "bookmark",
    glass: true
  }), /*#__PURE__*/React.createElement(IconBtn, {
    name: "share",
    glass: true
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '6px 18px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: post.avatar,
    size: 36
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)'
    }
  }, post.by), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, post.tag)), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    style: {
      padding: '9px 16px',
      fontSize: 13
    }
  }, "Follow")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 21,
      letterSpacing: '-0.015em',
      color: 'var(--fg-1)',
      margin: '14px 0 12px'
    }
  }, post.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--coral)',
      padding: '8px 14px',
      borderRadius: 999,
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowUp",
    size: 14
  }), " ", post.up), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--fg-2)',
      padding: '8px 14px',
      borderRadius: 999,
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "comment",
    size: 14
  }), " ", post.comments)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 14
    }
  }, "Comments"), WEB_COMMENTS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: c.avatar,
    size: 30
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '9px 12px',
      borderRadius: '4px 12px 12px 12px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 12.5,
      color: 'var(--fg-1)'
    }
  }, c.by), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, c.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      lineHeight: 1.45,
      color: 'var(--fg-2)'
    }
  }, c.text)), c.replies.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 10,
      paddingLeft: 6,
      borderLeft: '2px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: r.avatar,
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '8px 11px',
      borderRadius: '4px 12px 12px 12px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 12,
      color: 'var(--fg-1)'
    }
  }, r.by), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--fg-3)'
    }
  }, r.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12.5,
      lineHeight: 1.4,
      color: 'var(--fg-2)'
    }
  }, r.text))))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '7px 7px 7px 18px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Add a comment\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 15
  })))));
}

// ---------- TOOLS ----------
function ToolsView({
  onOpenTool,
  onProfile
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 96
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: "Tools",
    sub: "open one full-screen",
    right: /*#__PURE__*/React.createElement("button", {
      onClick: onProfile,
      style: {
        border: 'none',
        background: 'transparent',
        padding: 0,
        cursor: 'pointer',
        borderRadius: 999
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      index: WEB_ME.avatar,
      size: 34
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 0',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, WEB_TOOLS.map(t => /*#__PURE__*/React.createElement(ToolTile, {
    key: t.id,
    t: t,
    onOpen: () => onOpenTool(t)
  }))));
}
function ToolTile({
  t,
  onOpen
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: onOpen,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      textAlign: 'left',
      border: 'none',
      cursor: 'pointer',
      minHeight: 150,
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      padding: 18,
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-lift)',
      transform: pressed ? 'scale(0.98)' : 'none',
      transition: 'box-shadow 150ms var(--ease-out), transform 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 14,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: t.icon,
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 16,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em'
    }
  }, t.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12,
      color: 'var(--fg-3)',
      marginTop: 4,
      lineHeight: 1.35
    }
  }, t.sub)));
}
function ToolSheet({
  tool,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 65,
      background: 'var(--neu-base)',
      display: 'flex',
      flexDirection: 'column',
      animation: 'sheetUp 240ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: tool.name,
    sub: `${tool.tag} tool`,
    onBack: onClose,
    right: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      style: {
        padding: '9px 16px',
        fontSize: 13
      }
    }, "Export")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 12
    }
  }, "Board \xB7 drag references in"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12
    }
  }, [2, 6, 1, 3, 5, 4].map((idx, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: 7,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: [120, 160][i % 2],
      borderRadius: 9,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  })))))));
}

// ---------- SETTINGS ----------
function Toggle({
  on,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      width: 48,
      height: 28,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      position: 'relative',
      background: on ? 'var(--coral)' : 'var(--neu-base)',
      boxShadow: on ? 'inset 2px 2px 5px rgba(0,0,0,0.35)' : 'var(--neu-inset)',
      transition: 'background 200ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: on ? 23 : 3,
      width: 22,
      height: 22,
      borderRadius: 999,
      background: on ? 'var(--fg-on-coral)' : 'var(--fg-2)',
      boxShadow: '2px 2px 5px rgba(0,0,0,0.4)',
      transition: 'left 200ms var(--ease-out)'
    }
  }));
}
function SettingsView({
  onProfile
}) {
  const [s, setS] = React.useState({
    crew: true,
    mentions: true,
    digest: false,
    discover: true
  });
  const set = k => setS(p => ({
    ...p,
    [k]: !p[k]
  }));
  const Row = ({
    icon,
    title,
    sub,
    ctrl,
    last
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 13,
      padding: '14px 4px',
      boxShadow: last ? 'none' : 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      borderRadius: 11,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-2)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14.5,
      color: 'var(--fg-1)'
    }
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12,
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, sub)), ctrl);
  const card = (label, children) => /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.09em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '0 0 10px 4px'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 16px',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, children));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 96
    }
  }, /*#__PURE__*/React.createElement(AppTopBar, {
    title: "Settings",
    right: /*#__PURE__*/React.createElement("button", {
      onClick: onProfile,
      style: {
        border: 'none',
        background: 'transparent',
        padding: 0,
        cursor: 'pointer',
        borderRadius: 999
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      index: WEB_ME.avatar,
      size: 34
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: 16,
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: WEB_ME.avatar,
    size: 50
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 17,
      color: 'var(--fg-1)'
    }
  }, WEB_ME.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, WEB_ME.handle)), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 18,
    style: {
      color: 'var(--fg-3)'
    }
  })), card('Notifications', /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Row, {
    icon: "users",
    title: "Crew invitations",
    ctrl: /*#__PURE__*/React.createElement(Toggle, {
      on: s.crew,
      onToggle: () => set('crew')
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "comment",
    title: "Mentions & replies",
    ctrl: /*#__PURE__*/React.createElement(Toggle, {
      on: s.mentions,
      onToggle: () => set('mentions')
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "feed",
    title: "Weekly digest",
    ctrl: /*#__PURE__*/React.createElement(Toggle, {
      on: s.digest,
      onToggle: () => set('digest')
    }),
    last: true
  }))), card('Privacy', /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Row, {
    icon: "compass",
    title: "Discoverable in search",
    ctrl: /*#__PURE__*/React.createElement(Toggle, {
      on: s.discover,
      onToggle: () => set('discover')
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "lock",
    title: "Blocked artists",
    ctrl: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron",
      size: 18,
      style: {
        color: 'var(--fg-3)'
      }
    }),
    last: true
  }))), card('General', /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Row, {
    icon: "briefcase",
    title: "Billing & membership",
    ctrl: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron",
      size: 18,
      style: {
        color: 'var(--fg-3)'
      }
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: "fileText",
    title: "Terms & privacy",
    ctrl: /*#__PURE__*/React.createElement(Icon, {
      name: "chevron",
      size: 18,
      style: {
        color: 'var(--fg-3)'
      }
    }),
    last: true
  }))), /*#__PURE__*/React.createElement("button", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 9,
      width: '100%',
      padding: 15,
      borderRadius: 'var(--r-md)',
      border: 'none',
      cursor: 'pointer',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      color: 'var(--coral)',
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "logout",
    size: 18
  }), " Sign out")));
}

// ---------- PROFILE ----------
function ProfileScreen({
  onBack
}) {
  const me = WEB_ME;
  const [tab, setTab] = React.useState('Portfolio');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 55,
      background: 'var(--neu-base)',
      overflowY: 'auto',
      animation: 'sheetUp 240ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 130,
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: me.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(transparent 40%, rgba(20,20,22,0.6))'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 20,
      left: 20
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    glass: true,
    onClick: onBack
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 20,
      right: 20
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "settings",
    glass: true
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 18px 40px',
      marginTop: -32,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 999,
      width: 76,
      boxShadow: '0 0 0 5px var(--neu-base)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: me.avatar,
    size: 76
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fg-1)'
    }
  }, me.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, me.handle, " \xB7 ", me.discipline)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    style: {
      padding: '10px 18px'
    }
  }, "Edit")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fg-2)',
      margin: '14px 0 0'
    }
  }, me.bio), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 22,
      margin: '18px 0',
      padding: '16px 20px',
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset)'
    }
  }, me.stats.map(st => /*#__PURE__*/React.createElement(StatBlock, {
    key: st.label,
    value: st.value,
    label: st.label
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.09em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '6px 0 12px'
    }
  }, "Create"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12,
      marginBottom: 22
    }
  }, [['briefcase', 'Portfolio', true], ['fileText', 'Résumé', false], ['upload', 'Upload work', false], ['feed', 'Post', false]].map(([ic, label, accent]) => /*#__PURE__*/React.createElement("div", {
    key: label,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: 14,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      borderRadius: 11,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: accent ? 'var(--fg-on-coral)' : 'var(--coral)',
      background: accent ? 'var(--coral)' : 'var(--neu-base)',
      boxShadow: accent ? '3px 3px 8px rgba(0,0,0,0.4)' : 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 13.5,
      color: 'var(--fg-1)'
    }
  }, label)))), /*#__PURE__*/React.createElement(Segmented, {
    options: ['Portfolio', 'Posts', 'Chat', 'About'],
    value: tab,
    onChange: setTab
  }), tab === 'Chat' ? /*#__PURE__*/React.createElement(MobileTeamChat, null) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10,
      marginTop: 16
    }
  }, [2, 5, 6, 3, 1, 4].map((idx, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      padding: 7
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 120,
      borderRadius: 9,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  })))))));
}

// Team chat on the mobile profile — crew only
function MobileTeamChat() {
  const [draft, setDraft] = React.useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      paddingBottom: 12
    }
  }, WEB_TEAM.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.name,
    style: {
      flexShrink: 0,
      width: 64,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'inline-block'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: m.avatar,
    size: 48
  }), m.online && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 1,
      bottom: 1,
      width: 11,
      height: 11,
      borderRadius: 999,
      background: '#4ADE80',
      boxShadow: '0 0 0 2px var(--neu-base)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 11,
      color: 'var(--fg-1)',
      marginTop: 5,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, m.name.split(' ')[0]), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8,
      color: 'var(--fg-3)'
    }
  }, m.role)))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset)',
      padding: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.07em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      textAlign: 'center'
    }
  }, "Team \u2014 Nightwork \xB7 private to the crew"), WEB_TEAM_THREAD.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      flexDirection: m.me ? 'row-reverse' : 'row',
      alignItems: 'flex-end'
    }
  }, !m.me && /*#__PURE__*/React.createElement(Avatar, {
    index: m.who,
    size: 22
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '74%'
    }
  }, !m.me && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8.5,
      color: 'var(--fg-3)',
      margin: '0 0 3px 4px'
    }
  }, m.name, " \xB7 ", m.when), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '9px 12px',
      borderRadius: m.me ? '13px 13px 4px 13px' : '13px 13px 13px 4px',
      background: m.me ? 'var(--coral)' : 'var(--neu-base)',
      color: m.me ? 'var(--fg-on-coral)' : 'var(--fg-1)',
      boxShadow: m.me ? '3px 3px 8px rgba(0,0,0,0.4)' : 'var(--neu-lift)',
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      lineHeight: 1.4
    }
  }, m.text))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '7px 7px 7px 16px',
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    placeholder: "Message the team\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 15
  }))));
}
Object.assign(window, {
  DiscoverView,
  MessagesScreen,
  FeedView,
  ToolsView,
  ToolSheet,
  SettingsView,
  ProfileScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppSocial.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Icon.jsx
try { (() => {
// arsyen — icon set (Lucide-style, 1.5px stroke, currentColor)
// Single <Icon name=… size=… /> component. Monochrome line icons.

const ARSYEN_ICON_PATHS = {
  home: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M3 9.7 12 3l9 6.7V20a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"
  })),
  search: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m21 21-4.3-4.3"
  })),
  plus: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 5v14M5 12h14"
  })),
  inbox: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M4 4h16v12H7l-3 3z"
  })),
  user: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "8",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M4 21c0-4 4-6 8-6s8 2 8 6"
  })),
  bookmark: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M19 21l-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"
  })),
  bell: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M13.7 21a2 2 0 0 1-3.4 0"
  })),
  settings: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 6.8 19l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3 13.4H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 6.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 10 4.6V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 .9 2.7H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"
  })),
  share: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 6l-4-4-4 4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 2v13"
  })),
  heart: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M19 14c1.5-1.5 3-3.3 3-5.5A4.5 4.5 0 0 0 12 6 4.5 4.5 0 0 0 2 8.5c0 2.2 1.5 4 3 5.5l7 7z"
  })),
  back: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M15 18l-6-6 6-6"
  })),
  close: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M18 6 6 18M6 6l12 12"
  })),
  check: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M20 6 9 17l-5-5"
  })),
  more: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "5",
    cy: "12",
    r: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "12",
    r: "1"
  })),
  grid: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "7",
    height: "7",
    rx: "1.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14",
    y: "3",
    width: "7",
    height: "7",
    rx: "1.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "14",
    width: "7",
    height: "7",
    rx: "1.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14",
    y: "14",
    width: "7",
    height: "7",
    rx: "1.5"
  })),
  image: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "18",
    height: "18",
    rx: "3"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "8.5",
    r: "1.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m21 15-5-5L5 21"
  })),
  upload: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 16V4M7 9l5-5 5 5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"
  })),
  chevron: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "m9 6 6 6-6 6"
  })),
  star: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 3l2.6 5.6L21 9.3l-4.5 4.3 1.1 6.4L12 17l-5.6 3 1.1-6.4L3 9.3l6.4-.7z"
  })),
  eye: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "3"
  })),
  palette: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8",
    cy: "9.5",
    r: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "7.5",
    r: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "16",
    cy: "9.5",
    r: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 21a3 3 0 0 1 0-6 2 2 0 0 0 0-4"
  })),
  folder: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
  })),
  compass: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m15.5 8.5-2 5-5 2 2-5z"
  })),
  feed: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "7",
    height: "9",
    rx: "1.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14",
    y: "3",
    width: "7",
    height: "5",
    rx: "1.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14",
    y: "12",
    width: "7",
    height: "9",
    rx: "1.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "16",
    width: "7",
    height: "5",
    rx: "1.5"
  })),
  chat: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.5A8 8 0 1 1 21 12z"
  })),
  sliders: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M1 14h6M9 8h6M17 16h6"
  })),
  send: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M22 2 11 13"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M22 2 15 22l-4-9-9-4z"
  })),
  fileText: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M14 3v6h6"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M9 13h6M9 17h6"
  })),
  briefcase: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "7",
    width: "18",
    height: "13",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M3 13h18"
  })),
  arrowUp: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 19V5M6 11l6-6 6 6"
  })),
  comment: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M21 11.5a7.5 7.5 0 0 1-10.8 6.7L4 20l1.8-5.2A7.5 7.5 0 1 1 21 11.5z"
  })),
  lock: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "4",
    y: "10",
    width: "16",
    height: "11",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 10V7a4 4 0 0 1 8 0v3"
  })),
  pin: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "10",
    r: "2.5"
  })),
  users: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "8",
    r: "3.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 5a3.5 3.5 0 0 1 0 7M22 20c0-2.6-1.4-4.4-3.5-5.2"
  })),
  link: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"
  })),
  logout: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 17l5-5-5-5M21 12H9"
  })),
  sidebar: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "4",
    width: "18",
    height: "16",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M9 4v16"
  }))
};
function Icon({
  name,
  size = 22,
  fill = false,
  strokeWidth = 1.5,
  style = {}
}) {
  const p = ARSYEN_ICON_PATHS[name];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: fill ? 'currentColor' : 'none',
    stroke: fill ? 'none' : 'currentColor',
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    }
  }, p);
}
Object.assign(window, {
  Icon,
  ARSYEN_ICON_PATHS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Icon.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/UI.jsx
try { (() => {
// arsyen — shared UI primitives (matt black, glass, coral)
// Exports: Button, Chip, Segmented, Avatar, ArtFill, ART_PALETTES, IconBtn, StatBlock

// Abstract "artwork" gradient fills — the only saturated color in the system.
const ART_PALETTES = ['radial-gradient(120% 100% at 20% 15%, #ff8a5c 0%, transparent 55%), radial-gradient(120% 100% at 80% 85%, #6b5bff 0%, transparent 55%), #241c2e', 'radial-gradient(120% 100% at 70% 20%, #2e8f73 0%, transparent 60%), radial-gradient(100% 100% at 20% 90%, #d9b24a 0%, transparent 55%), #1a221c', 'radial-gradient(120% 100% at 30% 25%, #ff5d7a 0%, transparent 55%), radial-gradient(120% 100% at 85% 80%, #4a2f6e 0%, transparent 60%), #221525', 'radial-gradient(120% 120% at 50% 0%, #5b8dff 0%, transparent 55%), radial-gradient(100% 100% at 80% 100%, #1a2440 0%, transparent 60%), #11151f', 'radial-gradient(120% 100% at 15% 20%, #e8e3d6 0%, transparent 50%), radial-gradient(120% 100% at 80% 90%, #8a8577 0%, transparent 55%), #2a2823', 'radial-gradient(120% 120% at 60% 15%, #ff7847 0%, transparent 50%), radial-gradient(110% 100% at 20% 95%, #7a1f1f 0%, transparent 55%), #1f1311', 'radial-gradient(120% 100% at 40% 20%, #b07cff 0%, transparent 55%), radial-gradient(120% 100% at 85% 85%, #2a6f8f 0%, transparent 55%), #18121f', 'radial-gradient(130% 110% at 50% 10%, #3a3d42 0%, transparent 60%), radial-gradient(90% 90% at 70% 90%, #0e0f11 0%, transparent 60%), #161719'];
function ArtFill({
  index = 0,
  radius = 0,
  style = {},
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      background: ART_PALETTES[index % ART_PALETTES.length],
      borderRadius: radius,
      overflow: 'hidden',
      ...style
    }
  }, children);
}
function Button({
  children,
  variant = 'primary',
  full = false,
  onClick,
  style = {}
}) {
  const [pressed, setPressed] = React.useState(false);
  const base = {
    fontFamily: 'var(--font-text)',
    fontWeight: 600,
    fontSize: 15,
    border: 'none',
    cursor: 'pointer',
    borderRadius: 999,
    padding: '13px 22px',
    width: full ? '100%' : undefined,
    transition: 'all 160ms cubic-bezier(.22,1,.36,1)',
    transform: pressed ? 'scale(0.97)' : 'scale(1)',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: pressed ? 'var(--neu-inset)' : '5px 5px 12px rgba(0,0,0,0.45), -4px -4px 10px rgba(255,255,255,0.10)'
    },
    secondary: {
      background: 'var(--neu-base)',
      color: 'var(--fg-1)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-raise-sm)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--fg-2)',
      boxShadow: pressed ? 'var(--neu-inset-sm)' : 'none'
    }
  };
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, children);
}
function IconBtn({
  name,
  fill = false,
  size = 20,
  onClick,
  glass = false,
  active = false,
  style = {}
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      width: 42,
      height: 42,
      borderRadius: 999,
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: active ? 'var(--coral)' : 'var(--fg-1)',
      border: 'none',
      background: glass ? 'var(--glass-fill)' : 'var(--neu-base)',
      backdropFilter: glass ? 'blur(14px)' : undefined,
      WebkitBackdropFilter: glass ? 'blur(14px)' : undefined,
      boxShadow: glass ? pressed ? 'var(--neu-inset-sm)' : '0 1px 0 rgba(255,255,255,0.08) inset, 0 2px 8px rgba(0,0,0,0.4)' : pressed ? 'var(--neu-inset-sm)' : 'var(--neu-raise-sm)',
      transition: 'all 140ms cubic-bezier(.22,1,.36,1)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: name,
    size: size,
    fill: fill
  }));
}
function Chip({
  children,
  active = false,
  onClick
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      padding: '9px 17px',
      borderRadius: 999,
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      border: 'none',
      background: active ? 'var(--coral)' : 'var(--neu-base)',
      color: active ? 'var(--fg-on-coral)' : 'var(--fg-2)',
      boxShadow: active ? 'var(--neu-inset-sm)' : pressed ? 'var(--neu-inset-sm)' : 'var(--neu-lift)',
      transform: pressed ? 'scale(0.95)' : 'scale(1)',
      transition: 'all 160ms cubic-bezier(.22,1,.36,1)'
    }
  }, children);
}
function Segmented({
  options,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      borderRadius: 999,
      padding: 5
    }
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o,
    onClick: () => onChange(o),
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      border: 'none',
      cursor: 'pointer',
      padding: '8px 18px',
      borderRadius: 999,
      background: value === o ? 'var(--neu-base)' : 'transparent',
      color: value === o ? 'var(--fg-1)' : 'var(--fg-3)',
      boxShadow: value === o ? 'var(--neu-raise-sm)' : 'none',
      transition: 'all 160ms cubic-bezier(.22,1,.36,1)'
    }
  }, o)));
}
function Avatar({
  index = 0,
  size = 32,
  ring = false
}) {
  const grads = ['linear-gradient(135deg,#3a3d42,#26282b)', 'linear-gradient(135deg,#5a3d4a,#2a1c22)', 'linear-gradient(135deg,#3d4a5a,#1c2230)', 'linear-gradient(135deg,#4a4a3d,#26261c)'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: 999,
      flexShrink: 0,
      background: grads[index % grads.length],
      boxShadow: ring ? '0 0 0 2px var(--coral), var(--neu-raise-sm)' : 'var(--neu-raise-sm)'
    }
  });
}
function StatBlock({
  value,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 22,
      color: 'var(--fg-1)',
      letterSpacing: '-0.02em'
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, label));
}
Object.assign(window, {
  Button,
  IconBtn,
  Chip,
  Segmented,
  Avatar,
  ArtFill,
  ART_PALETTES,
  StatBlock
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/UI.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/ios-frame.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)

/* BEGIN USAGE */
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports (to window): IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard
//
// Usage — wrap your screen content in <IOSDevice> to get the bezel, status bar
// and home indicator (props: title, dark, keyboard):
//
//   <IOSDevice title="Settings">
//     ...your screen content...
//   </IOSDevice>
//   <IOSDevice dark title="Search" keyboard>…</IOSDevice>
/* END USAGE */

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      borderRadius: 48,
      overflow: 'hidden',
      position: 'relative',
      background: dark ? '#000' : '#F2F2F7',
      boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
      fontFamily: '-apple-system, system-ui, sans-serif',
      WebkitFontSmoothing: 'antialiased'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 11,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 126,
      height: 37,
      borderRadius: 24,
      background: '#000',
      zIndex: 50
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(IOSStatusBar, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column'
    }
  }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
    title: title,
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 60,
      height: 34,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-end',
      paddingBottom: 8,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 139,
      height: 5,
      borderRadius: 100,
      background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
    }
  })));
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/ios-frame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebApp.jsx
try { (() => {
// arsyen web app — shell: top brand bar + switching central surface + embossed BOTTOM tab bar
const WEB_TABS = [{
  id: 'projects',
  icon: 'folder',
  label: 'Projects'
}, {
  id: 'discover',
  icon: 'compass',
  label: 'Discover'
}, {
  id: 'feed',
  icon: 'feed',
  label: 'Feed + Chat'
}, {
  id: 'tools',
  icon: 'grid',
  label: 'Tools'
}, {
  id: 'settings',
  icon: 'settings',
  label: 'Settings'
}];
function WebTabBar({
  active,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: '50%',
      transform: 'translateX(-50%)',
      bottom: 18,
      zIndex: 60
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      padding: 8,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-lg)'
    }
  }, WEB_TABS.map(t => {
    const on = active === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => onChange(t.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        border: 'none',
        cursor: 'pointer',
        padding: on ? '11px 20px' : '11px 14px',
        borderRadius: 999,
        background: 'var(--neu-base)',
        boxShadow: on ? 'var(--neu-inset)' : 'none',
        color: on ? 'var(--coral)' : 'var(--fg-3)',
        transition: 'box-shadow 200ms var(--ease-out), padding 200ms var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: t.icon,
      size: 20
    }), on && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-text)',
        fontWeight: 600,
        fontSize: 14,
        color: 'var(--fg-1)',
        whiteSpace: 'nowrap'
      }
    }, t.label));
  })));
}
function WebTopBar({
  active,
  onProfile
}) {
  const onProfileView = active === 'profile';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '16px 28px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 800,
      fontSize: 22,
      letterSpacing: '-0.025em',
      color: '#eef2ff',
      textShadow: '-1.5px 0 4px rgba(255,45,85,0.45), 1.5px 0 4px rgba(58,107,255,0.45)'
    }
  }, "arsyen"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '9px 16px',
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      color: 'var(--fg-3)',
      minWidth: 200
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13
    }
  }, "Quick search\u2026"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)',
      padding: '2px 6px',
      borderRadius: 5,
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, "\u2318K")), /*#__PURE__*/React.createElement(IconBtn, {
    name: "bell"
  }), /*#__PURE__*/React.createElement("button", {
    onClick: onProfile,
    title: "Your profile",
    style: {
      border: 'none',
      background: 'transparent',
      padding: 0,
      cursor: 'pointer',
      borderRadius: 999,
      boxShadow: onProfileView ? 'var(--halo-coral)' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: WEB_ME.avatar,
    size: 38,
    ring: onProfileView
  }))));
}
function WebShell() {
  const [tab, setTab] = React.useState('projects');
  const [pendingTool, setPendingTool] = React.useState(null);
  const [zen, setZen] = React.useState(false); // canvas full-page focus mode
  const openTool = name => {
    setPendingTool(name);
    setTab('tools');
  };
  const goTab = t => {
    setZen(false);
    setTab(t);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--neu-base)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: zen ? 0 : 80,
      opacity: zen ? 0 : 1,
      overflow: 'hidden',
      transition: 'max-height 360ms var(--ease-out), opacity 220ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(WebTopBar, {
    active: tab,
    onProfile: () => setTab('profile')
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      paddingBottom: zen ? 0 : 78,
      transition: 'padding-bottom 300ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    key: tab,
    style: {
      position: 'absolute',
      inset: 0,
      opacity: 1,
      animation: 'slideIn 300ms var(--ease-out)'
    }
  }, tab === 'projects' && /*#__PURE__*/React.createElement(ViewProjects, {
    onOpenTool: openTool,
    zen: zen,
    onZen: setZen
  }), tab === 'discover' && /*#__PURE__*/React.createElement(ViewDiscover, null), tab === 'feed' && /*#__PURE__*/React.createElement(ViewFeed, null), tab === 'tools' && /*#__PURE__*/React.createElement(ViewTools, {
    openToolName: pendingTool,
    onConsumed: () => setPendingTool(null)
  }), tab === 'settings' && /*#__PURE__*/React.createElement(ViewSettings, null), tab === 'profile' && /*#__PURE__*/React.createElement(ViewProfile, {
    onBack: () => setTab('projects')
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      opacity: zen ? 0 : 1,
      transform: zen ? 'translateY(120%)' : 'none',
      transition: 'opacity 220ms var(--ease-out), transform 300ms var(--ease-out)',
      pointerEvents: zen ? 'none' : 'auto'
    }
  }, /*#__PURE__*/React.createElement(WebTabBar, {
    active: tab,
    onChange: goTab
  }))));
}
ReactDOM.createRoot(document.getElementById('site')).render(/*#__PURE__*/React.createElement(WebShell, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebApp.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebChat.jsx
try { (() => {
// arsyen web — shared collapsible Instagram-like chat panel (used in Discover)
// Two sections: Direct (DMs) and Community (groups the user belongs to).
function ChatPanel({
  collapsed,
  onToggle
}) {
  const [openId, setOpenId] = React.useState(null);
  const [mode, setMode] = React.useState('direct'); // 'direct' | 'community'
  const [draft, setDraft] = React.useState('');
  const chat = [...WEB_CHATS, ...WEB_COMMUNITIES].find(c => c.id === openId);
  const isCommunity = chat && chat.members != null;
  if (collapsed) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: 70,
        flexShrink: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 12,
        padding: '16px 0',
        borderRadius: 'var(--r-lg)',
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-raise)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: onToggle,
      title: "Open chat",
      style: {
        width: 42,
        height: 42,
        borderRadius: 13,
        border: 'none',
        cursor: 'pointer',
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--coral)',
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-raise-sm)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "chat",
      size: 20
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -2,
        right: -2,
        minWidth: 16,
        height: 16,
        padding: '0 4px',
        borderRadius: 999,
        background: 'var(--coral)',
        color: 'var(--fg-on-coral)',
        fontFamily: 'var(--font-mono)',
        fontSize: 9,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, "7")), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 1,
        background: 'var(--hairline)'
      }
    }), WEB_CHATS.map(c => /*#__PURE__*/React.createElement("button", {
      key: c.id,
      onClick: () => {
        onToggle();
        setMode('direct');
        setOpenId(c.id);
      },
      title: c.name,
      style: {
        position: 'relative',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        padding: 0
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      index: c.avatar,
      size: 42
    }), c.online && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        right: 1,
        bottom: 1,
        width: 10,
        height: 10,
        borderRadius: 999,
        background: '#4ADE80',
        boxShadow: '0 0 0 2px var(--neu-base)'
      }
    }), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -2,
        right: -2,
        width: 9,
        height: 9,
        borderRadius: 999,
        background: 'var(--coral)',
        boxShadow: '0 0 0 2px var(--neu-base)'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 1,
        background: 'var(--hairline)'
      }
    }), WEB_COMMUNITIES.slice(0, 3).map(c => /*#__PURE__*/React.createElement("button", {
      key: c.id,
      onClick: () => {
        onToggle();
        setMode('community');
        setOpenId(c.id);
      },
      title: c.name,
      style: {
        position: 'relative',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        padding: 0,
        width: 42,
        height: 42,
        borderRadius: 12,
        overflow: 'hidden',
        boxShadow: 'var(--neu-lift)'
      }
    }, /*#__PURE__*/React.createElement(ArtFill, {
      index: c.art
    }), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -2,
        right: -2,
        width: 9,
        height: 9,
        borderRadius: 999,
        background: 'var(--coral)',
        boxShadow: '0 0 0 2px var(--neu-base)'
      }
    }))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 340,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '16px 18px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, chat ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    onClick: () => setOpenId(null)
  }), isCommunity ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 10,
      overflow: 'hidden',
      flexShrink: 0,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: chat.art
  })) : /*#__PURE__*/React.createElement(Avatar, {
    index: chat.avatar,
    size: 34
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, chat.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: isCommunity ? 'var(--fg-3)' : chat.online ? '#4ADE80' : 'var(--fg-3)'
    }
  }, isCommunity ? `${chat.members} members` : chat.online ? 'active now' : 'offline'))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Icon, {
    name: "chat",
    size: 18,
    style: {
      color: 'var(--coral)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 17,
      color: 'var(--fg-1)',
      flex: 1
    }
  }, "Chat"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-1)',
      boxShadow: 'var(--neu-raise-sm)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 16
  }))), /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    title: "Collapse chat",
    style: {
      width: 32,
      height: 32,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-2)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 16
  }))), chat ?
  /*#__PURE__*/
  /* thread (DM or community group chat) */
  React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, WEB_THREAD.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      flexDirection: m.me ? 'row-reverse' : 'row',
      alignItems: 'flex-end'
    }
  }, !m.me && /*#__PURE__*/React.createElement(Avatar, {
    index: m.avatar,
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '74%'
    }
  }, isCommunity && !m.me && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--fg-3)',
      margin: '0 0 3px 4px'
    }
  }, WEB_CREW_NAMES[m.avatar] || 'member'), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 13px',
      borderRadius: m.me ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
      background: m.me ? 'var(--coral)' : 'var(--neu-base)',
      color: m.me ? 'var(--fg-on-coral)' : 'var(--fg-1)',
      boxShadow: m.me ? '3px 3px 8px rgba(0,0,0,0.4)' : 'var(--neu-raise-sm)',
      fontFamily: 'var(--font-text)',
      fontSize: 13.5,
      lineHeight: 1.45
    }
  }, m.text))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '8px 8px 8px 18px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    placeholder: isCommunity ? 'Message the community…' : 'Message…',
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => setDraft(''),
    style: {
      width: 38,
      height: 38,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 17
  }))))) :
  /*#__PURE__*/
  /* list: Direct / Community toggle */
  React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 14px 4px'
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    options: ['Direct', 'Community'],
    value: mode === 'direct' ? 'Direct' : 'Community',
    onChange: v => setMode(v === 'Direct' ? 'direct' : 'community')
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '8px 10px 16px'
    }
  }, mode === 'direct' ? WEB_CHATS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => setOpenId(c.id),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '11px 12px',
      borderRadius: 14,
      cursor: 'pointer'
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = 'var(--neu-inset-sm)',
    onMouseLeave: e => e.currentTarget.style.boxShadow = 'none'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: c.avatar,
    size: 48
  }), c.online && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 1,
      bottom: 1,
      width: 12,
      height: 12,
      borderRadius: 999,
      background: '#4ADE80',
      boxShadow: '0 0 0 2.5px var(--neu-base)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: c.unread ? 700 : 600,
      fontSize: 14,
      color: 'var(--fg-1)'
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12.5,
      color: c.unread ? 'var(--fg-1)' : 'var(--fg-3)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      marginTop: 2
    }
  }, c.last, " \xB7 ", c.when)), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 999,
      flexShrink: 0,
      background: 'var(--coral)',
      boxShadow: '0 0 7px var(--coral-glow)'
    }
  }))) : WEB_COMMUNITIES.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => setOpenId(c.id),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '11px 12px',
      borderRadius: 14,
      cursor: 'pointer'
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = 'var(--neu-inset-sm)',
    onMouseLeave: e => e.currentTarget.style.boxShadow = 'none'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 13,
      overflow: 'hidden',
      flexShrink: 0,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: c.art
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: c.unread ? 700 : 600,
      fontSize: 14,
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--fg-3)',
      flexShrink: 0
    }
  }, c.members)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12.5,
      color: c.unread ? 'var(--fg-1)' : 'var(--fg-3)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      marginTop: 2
    }
  }, c.last, " \xB7 ", c.when)), c.unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 18,
      height: 18,
      padding: '0 5px',
      borderRadius: 999,
      flexShrink: 0,
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, c.unread))))));
}
Object.assign(window, {
  ChatPanel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebChat.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebData.jsx
try { (() => {
// arsyen web app — sample data: projects, artists, feed, chat

const WEB_PROJECTS = [{
  id: 'p1',
  title: 'Nightwork — short film',
  type: 'Short film',
  art: 2,
  status: 'In production',
  progress: 64,
  role: 'Director',
  crew: [3, 1, 2, 0],
  updated: '2h ago',
  stages: {
    'To do': [{
      t: 'Lock color grade',
      who: 0
    }, {
      t: 'Sound design pass 2',
      who: 2
    }],
    'In progress': [{
      t: 'Edit reel 03',
      who: 1
    }, {
      t: 'Score — main theme',
      who: 3
    }],
    'Review': [{
      t: 'Poster comp',
      who: 0
    }],
    'Done': [{
      t: 'Storyboard',
      who: 1
    }, {
      t: 'Location scout',
      who: 2
    }]
  },
  milestones: [{
    label: 'Picture lock',
    date: 'Jun 18',
    done: false
  }, {
    label: 'Final mix',
    date: 'Jun 30',
    done: false
  }, {
    label: 'Festival cut',
    date: 'Jul 12',
    done: false
  }]
}, {
  id: 'p2',
  title: 'Paper Sun — album art',
  type: 'Album',
  art: 5,
  status: 'In review',
  progress: 82,
  role: 'Art director',
  crew: [0, 2],
  updated: '5h ago',
  stages: {
    'To do': [{
      t: 'Vinyl sleeve dielines',
      who: 2
    }],
    'In progress': [{
      t: 'Cover plate retouch',
      who: 0
    }],
    'Review': [{
      t: 'Tracklist typography',
      who: 0
    }, {
      t: 'Back cover',
      who: 2
    }],
    'Done': [{
      t: 'Moodboard',
      who: 0
    }, {
      t: 'Photo session',
      who: 2
    }]
  },
  milestones: [{
    label: 'Client sign-off',
    date: 'Jun 14',
    done: false
  }, {
    label: 'Print handoff',
    date: 'Jun 20',
    done: false
  }]
}, {
  id: 'p3',
  title: 'Static Garden — exhibition',
  type: 'Exhibition',
  art: 6,
  status: 'Planning',
  progress: 28,
  role: 'Curator',
  crew: [1, 3, 0],
  updated: '1d ago',
  stages: {
    'To do': [{
      t: 'Wall text drafts',
      who: 1
    }, {
      t: 'Lighting plan',
      who: 3
    }, {
      t: 'Invite list',
      who: 0
    }],
    'In progress': [{
      t: 'Floor layout',
      who: 1
    }],
    'Review': [],
    'Done': [{
      t: 'Venue booked',
      who: 0
    }]
  },
  milestones: [{
    label: 'Install',
    date: 'Aug 02',
    done: false
  }, {
    label: 'Opening night',
    date: 'Aug 09',
    done: false
  }]
}, {
  id: 'p4',
  title: 'Field Study — photo zine',
  type: 'Print',
  art: 4,
  status: 'In production',
  progress: 47,
  role: 'Editor',
  crew: [2, 0],
  updated: '2d ago',
  stages: {
    'To do': [{
      t: 'Sequence edit',
      who: 2
    }, {
      t: 'Paper stock test',
      who: 0
    }],
    'In progress': [{
      t: 'Scan negatives',
      who: 2
    }],
    'Review': [{
      t: 'Cover crop',
      who: 0
    }],
    'Done': [{
      t: 'Concept',
      who: 2
    }]
  },
  milestones: [{
    label: 'Proof copy',
    date: 'Jun 25',
    done: false
  }]
}];

// Artists to discover / form a crew
const WEB_ARTISTS = [{
  id: 'u0',
  name: 'Nadia Œ',
  handle: '@nadia.oe',
  avatar: 0,
  art: 4,
  discipline: 'Photographer',
  city: 'Lisbon',
  open: true,
  skills: ['Analog', 'Editorial', 'Print'],
  rate: '$$',
  match: 96
}, {
  id: 'u1',
  name: 'Mara Vey',
  handle: '@maravey',
  avatar: 1,
  art: 2,
  discipline: 'Painter',
  city: 'Oslo',
  open: true,
  skills: ['Oil', 'Portrait', 'Set design'],
  rate: '$$$',
  match: 93
}, {
  id: 'u2',
  name: 'Ilo Bran',
  handle: '@ilobran',
  avatar: 2,
  art: 1,
  discipline: 'Photographer',
  city: 'Berlin',
  open: false,
  skills: ['Documentary', '16mm'],
  rate: '$$',
  match: 88
}, {
  id: 'u3',
  name: 'Søren K.',
  handle: '@sorenk',
  avatar: 3,
  art: 3,
  discipline: '3D / Motion',
  city: 'Copenhagen',
  open: true,
  skills: ['Houdini', 'Score', 'Title design'],
  rate: '$$$',
  match: 84
}, {
  id: 'u4',
  name: 'Lena Asgard',
  handle: '@lasgard',
  avatar: 1,
  art: 6,
  discipline: 'Composer',
  city: 'Reykjavík',
  open: true,
  skills: ['Ambient', 'Strings', 'Mix'],
  rate: '$$',
  match: 80
}, {
  id: 'u5',
  name: 'Studio Æon',
  handle: '@studio.aeon',
  avatar: 2,
  art: 7,
  discipline: 'Design studio',
  city: 'Amsterdam',
  open: false,
  skills: ['Branding', 'Editorial'],
  rate: '$$$$',
  match: 77
}];
const DISCOVER_FILTERS = ['Discipline', 'Location', 'Open to crew', 'Skills', 'Rate'];

// Feed — media-only pins (image/video). Click opens detail with comments/threads.
const WEB_FEED = [{
  id: 'f1',
  kind: 'image',
  art: 2,
  h: 280,
  by: 'Mara Vey',
  avatar: 1,
  title: 'Nightwork no. 4',
  up: 214,
  comments: 18,
  tag: 'Painting'
}, {
  id: 'f2',
  kind: 'video',
  art: 3,
  h: 200,
  by: 'Søren K.',
  avatar: 3,
  title: 'Transmission — title test',
  up: 96,
  comments: 41,
  tag: '3D'
}, {
  id: 'f3',
  kind: 'image',
  art: 6,
  h: 320,
  by: 'Mara Vey',
  avatar: 1,
  title: 'Static garden',
  up: 332,
  comments: 27,
  tag: '3D'
}, {
  id: 'f4',
  kind: 'image',
  art: 1,
  h: 240,
  by: 'Ilo Bran',
  avatar: 2,
  title: 'Field study',
  up: 178,
  comments: 12,
  tag: 'Photo'
}, {
  id: 'f5',
  kind: 'image',
  art: 4,
  h: 300,
  by: 'Nadia Œ',
  avatar: 0,
  title: 'Dusk, again',
  up: 153,
  comments: 22,
  tag: 'Photo'
}, {
  id: 'f6',
  kind: 'image',
  art: 5,
  h: 220,
  by: 'Nadia Œ',
  avatar: 0,
  title: 'Paper sun',
  up: 287,
  comments: 31,
  tag: 'Mixed'
}, {
  id: 'f7',
  kind: 'video',
  art: 7,
  h: 260,
  by: 'Søren K.',
  avatar: 3,
  title: 'Plate motion study',
  up: 401,
  comments: 44,
  tag: '3D'
}, {
  id: 'f8',
  kind: 'image',
  art: 0,
  h: 200,
  by: 'Studio Æon',
  avatar: 2,
  title: 'Untitled (plate)',
  up: 119,
  comments: 8,
  tag: 'Print'
}];
const WEB_CHATS = [{
  id: 'ch1',
  name: 'Nightwork crew',
  who: 'group',
  avatar: 3,
  last: 'Søren: score draft is up 🎧',
  when: '2m',
  unread: 2,
  online: true
}, {
  id: 'ch2',
  name: 'Nadia Œ',
  who: 'dm',
  avatar: 0,
  last: 'sent the contact sheet',
  when: '18m',
  unread: 0,
  online: true
}, {
  id: 'ch3',
  name: 'Studio Æon',
  who: 'dm',
  avatar: 2,
  last: 'Let\u2019s lock the sleeve dielines',
  when: '1h',
  unread: 0,
  online: false
}, {
  id: 'ch4',
  name: 'Mara Vey',
  who: 'dm',
  avatar: 1,
  last: 'love it. ship it.',
  when: '3h',
  unread: 0,
  online: false
}];

// Tools — embossed square tiles, each opens a full-screen tool page
const WEB_TOOLS = [{
  id: 't1',
  icon: 'palette',
  name: 'Moodboard',
  sub: 'Collect references into a board',
  tag: 'Visual'
}, {
  id: 't2',
  icon: 'image',
  name: 'Color grade',
  sub: 'Build & save LUT-style palettes',
  tag: 'Visual'
}, {
  id: 't3',
  icon: 'fileText',
  name: 'Brief builder',
  sub: 'Turn a chat into a creative brief',
  tag: 'Docs'
}, {
  id: 't4',
  icon: 'briefcase',
  name: 'Invoice',
  sub: 'Bill a commission, get paid',
  tag: 'Business'
}, {
  id: 't5',
  icon: 'users',
  name: 'Call sheet',
  sub: 'Schedule a shoot with your crew',
  tag: 'Production'
}, {
  id: 't6',
  icon: 'grid',
  name: 'Storyboard',
  sub: 'Frame out a sequence',
  tag: 'Production'
}, {
  id: 't7',
  icon: 'star',
  name: 'Portfolio',
  sub: 'Compose a gallery-grade set',
  tag: 'Profile'
}, {
  id: 't8',
  icon: 'send',
  name: 'Contract',
  sub: 'Scope, terms, signatures',
  tag: 'Business'
}];

// Comments / threads on a feed post
const WEB_COMMENTS = [{
  id: 'cm1',
  by: 'Søren K.',
  avatar: 3,
  when: '4h',
  up: 12,
  text: 'The light handling here is unreal. What were you shooting with?',
  replies: [{
    by: 'Mara Vey',
    avatar: 1,
    when: '3h',
    text: 'Mostly natural — one bounce, late afternoon.'
  }]
}, {
  id: 'cm2',
  by: 'Nadia Œ',
  avatar: 0,
  when: '2h',
  up: 7,
  text: 'Saved to my crew board. We should talk about the exhibition.',
  replies: []
}, {
  id: 'cm3',
  by: 'Ilo Bran',
  avatar: 2,
  when: '1h',
  up: 3,
  text: 'That edge treatment is exactly the register I was after.',
  replies: []
}];
const WEB_THREAD = [{
  me: false,
  who: 'Søren K.',
  avatar: 3,
  text: 'Score draft for the main theme is up in the project.',
  when: '2:41'
}, {
  me: false,
  who: 'Søren K.',
  avatar: 3,
  text: 'Strings come in around 0:48 — tell me if it\u2019s too much.',
  when: '2:41'
}, {
  me: true,
  text: 'Just listened. The swell is perfect. Maybe pull the reverb back 10%?',
  when: '2:44'
}, {
  me: false,
  who: 'Nadia Œ',
  avatar: 0,
  text: 'agreed, drier fits the grade',
  when: '2:45'
}, {
  me: true,
  text: 'Let\u2019s lock it for picture this week then.',
  when: '2:46'
}];
const WEB_CREW_NAMES = {
  0: 'Nadia',
  1: 'Mara',
  2: 'Ilo',
  3: 'Søren'
};

// Communities the user belongs to (Discover > Chat > Community)
const WEB_COMMUNITIES = [{
  id: 'cm1',
  name: 'Pune Filmmakers',
  members: '1.2k',
  art: 2,
  last: 'Aanya: anyone free for a weekend shoot?',
  when: '8m',
  unread: 5,
  online: true
}, {
  id: 'cm2',
  name: 'Indie DOPs',
  members: '860',
  art: 6,
  last: 'New thread — anamorphic on a budget',
  when: '1h',
  unread: 0,
  online: true
}, {
  id: 'cm3',
  name: 'Oslo Night Shooters',
  members: '312',
  art: 3,
  last: 'Karl shared a location pin',
  when: '3h',
  unread: 2,
  online: false
}, {
  id: 'cm4',
  name: 'Colour & Grade',
  members: '2.1k',
  art: 5,
  last: 'LUT pack v4 is up',
  when: '1d',
  unread: 0,
  online: false
}];

// Project team (Profile > Chat — team members only)
const WEB_TEAM = [{
  name: 'Mara Vey',
  avatar: 1,
  role: 'Painter',
  online: true
}, {
  name: 'Ilo Bran',
  avatar: 2,
  role: 'DOP',
  online: true
}, {
  name: 'Søren K.',
  avatar: 3,
  role: 'Score / 3D',
  online: false
}, {
  name: 'Nadia Œ',
  avatar: 0,
  role: 'Photographer',
  online: true
}];
const WEB_TEAM_THREAD = [{
  who: 1,
  name: 'Mara',
  text: 'Grade v3 is on the canvas — take a look when you can.',
  when: '9:02',
  me: false
}, {
  who: 2,
  name: 'Ilo',
  text: 'Negatives scanned, uploading the contact sheet now.',
  when: '9:14',
  me: false
}, {
  me: true,
  text: 'Perfect. Let’s lock picture by Friday.',
  when: '9:20'
}, {
  who: 3,
  name: 'Søren',
  text: 'Score stems ready whenever you are.',
  when: '9:26',
  me: false
}];
const WEB_ME = {
  name: 'Renn Okabe',
  handle: '@studio.noir',
  avatar: 3,
  art: 3,
  discipline: 'Director · Oil & light',
  city: 'Oslo, NO',
  bio: 'Night studies, slow work. Building small crews for short films and exhibitions. Commissions open.',
  stats: [{
    value: '48',
    label: 'Works'
  }, {
    value: '4',
    label: 'Projects'
  }, {
    value: '1.2k',
    label: 'Followers'
  }, {
    value: '312',
    label: 'Following'
  }],
  skills: ['Direction', 'Oil', 'Editing', 'Color', 'Curation']
};
Object.assign(window, {
  WEB_PROJECTS,
  WEB_ARTISTS,
  DISCOVER_FILTERS,
  WEB_FEED,
  WEB_CHATS,
  WEB_THREAD,
  WEB_ME,
  WEB_TOOLS,
  WEB_COMMENTS,
  WEB_CREW_NAMES,
  WEB_COMMUNITIES,
  WEB_TEAM,
  WEB_TEAM_THREAD
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebData.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebDiscover.jsx
try { (() => {
// arsyen web — "Discover" view: search + filters + featured/relevant artists + posts

function RateDots({
  rate
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--fg-2)',
      letterSpacing: '1px'
    }
  }, rate);
}
function ArtistCard({
  a,
  featured = false
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-lift)',
      cursor: 'pointer',
      overflow: 'hidden',
      transform: pressed ? 'scale(0.985)' : 'none',
      transition: 'box-shadow 200ms var(--ease-out), transform 160ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: featured ? 300 : 230,
      borderRadius: 14,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: a.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(transparent 45%, rgba(10,10,12,0.72))'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 12,
      right: 12,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--coral)',
      background: 'var(--glass-fill)',
      WebkitBackdropFilter: 'blur(12px)',
      backdropFilter: 'blur(12px)',
      border: '1px solid var(--glass-edge)',
      borderRadius: 999,
      padding: '4px 9px'
    }
  }, a.match, "% match"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 14,
      right: 14,
      bottom: 14,
      display: 'flex',
      alignItems: 'flex-end',
      gap: 11
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 999,
      boxShadow: '0 0 0 3px rgba(0,0,0,0.35)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: a.avatar,
    size: 46
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 18,
      color: '#fff',
      letterSpacing: '-0.01em',
      whiteSpace: 'nowrap'
    }
  }, a.name), a.open && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      flexShrink: 0,
      background: '#4ADE80',
      boxShadow: '0 0 7px #4ADE80'
    },
    title: "Open to crew"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.05em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,0.75)',
      marginTop: 3,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, a.discipline, " \xB7 ", a.city))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, a.skills.map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12,
      color: 'var(--fg-2)',
      padding: '5px 11px',
      borderRadius: 999,
      whiteSpace: 'nowrap',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, s))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    style: {
      padding: '9px 16px',
      fontSize: 13,
      flex: 1,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chat",
    size: 15
  }), " Message"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      flexShrink: 0,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-1)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      cursor: 'pointer'
    },
    title: "View profile"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user",
    size: 17
  })))));
}
function SearchSuggest({
  query
}) {
  if (!query) return null;
  const hits = WEB_ARTISTS.filter(a => (a.name + a.discipline + a.skills.join()).toLowerCase().includes(query.toLowerCase())).slice(0, 4);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 10px)',
      left: 0,
      right: 0,
      zIndex: 40,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-lg)',
      padding: 8,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      padding: '8px 12px 6px'
    }
  }, "Realtime suggestions"), hits.length ? hits.map(a => /*#__PURE__*/React.createElement("div", {
    key: a.id,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '10px 12px',
      borderRadius: 10,
      cursor: 'pointer'
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = 'var(--neu-inset-sm)',
    onMouseLeave: e => e.currentTarget.style.boxShadow = 'none'
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: a.avatar,
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)'
    }
  }, a.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)'
    }
  }, a.discipline, " \xB7 ", a.city)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--coral)'
    }
  }, a.match, "%"))) : /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px',
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-3)'
    }
  }, "No artists match \u201C", query, "\u201D."));
}
function ViewDiscover() {
  const [query, setQuery] = React.useState('');
  const [focus, setFocus] = React.useState(false);
  const [active, setActive] = React.useState([]);
  const [chatCollapsed, setChatCollapsed] = React.useState(false);
  const toggle = f => setActive(p => p.includes(f) ? p.filter(x => x !== f) : [...p, f]);
  const featured = WEB_ARTISTS.slice(0, 2);
  const relevant = WEB_ARTISTS.slice(2);
  const cols = chatCollapsed ? 4 : 3;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      height: '100%',
      padding: 24,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 28px 18px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: focus ? 'var(--neu-inset), 0 0 0 2px var(--coral-soft)' : 'var(--neu-inset)',
      padding: '14px 20px',
      transition: 'box-shadow 160ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 19,
    style: {
      color: 'var(--fg-3)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: query,
    onChange: e => setQuery(e.target.value),
    onFocus: () => setFocus(true),
    onBlur: () => setTimeout(() => setFocus(false), 150),
    placeholder: "Search artists, disciplines, skills\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 16
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sliders",
    size: 15
  }), " Filters")), focus && /*#__PURE__*/React.createElement(SearchSuggest, {
    query: query
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 9,
      marginTop: 16,
      flexWrap: 'wrap'
    }
  }, DISCOVER_FILTERS.map(f => /*#__PURE__*/React.createElement(Chip, {
    key: f,
    active: active.includes(f),
    onClick: () => toggle(f)
  }, f)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '22px 28px 28px'
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    icon: "star",
    text: "Featured artists"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${cols}, 1fr)`,
      gap: 18,
      marginBottom: 30
    }
  }, featured.map(a => /*#__PURE__*/React.createElement(ArtistCard, {
    key: a.id,
    a: a,
    featured: true
  }))), /*#__PURE__*/React.createElement(SectionLabel, {
    icon: "compass",
    text: "Most relevant for your crew"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${cols}, 1fr)`,
      gap: 18
    }
  }, relevant.map(a => /*#__PURE__*/React.createElement(ArtistCard, {
    key: a.id,
    a: a
  }))))), /*#__PURE__*/React.createElement(ChatPanel, {
    collapsed: chatCollapsed,
    onToggle: () => setChatCollapsed(c => !c)
  }));
}
function SectionLabel({
  icon,
  text
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 16,
    style: {
      color: 'var(--coral)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--fg-2)'
    }
  }, text));
}
Object.assign(window, {
  ViewDiscover
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebDiscover.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebFeed.jsx
try { (() => {
// arsyen web — "Feed + Chat": media-only feed + post-detail overlay + collapsible Instagram-like chat

// ---- MEDIA-ONLY FEED PIN (no text, click to open detail) ----
function MediaPin({
  p,
  onOpen
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: () => onOpen(p),
    onPointerEnter: () => setHover(true),
    onPointerLeave: () => setHover(false),
    style: {
      breakInside: 'avoid',
      marginBottom: 16,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: hover ? 'var(--neu-lift-hi)' : 'var(--neu-lift)',
      cursor: 'pointer',
      padding: 8,
      transform: hover ? 'translateY(-3px)' : 'none',
      transition: 'box-shadow 220ms var(--ease-out), transform 220ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: p.h,
      borderRadius: 12,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: p.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      opacity: hover ? 1 : 0,
      background: 'linear-gradient(transparent 55%, rgba(8,8,10,0.78))',
      transition: 'opacity 180ms var(--ease-out)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 12,
      right: 12,
      bottom: 12,
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      opacity: hover ? 1 : 0,
      transform: hover ? 'none' : 'translateY(6px)',
      transition: 'all 180ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: p.avatar,
    size: 24
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 13,
      color: '#fff',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, p.title), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowUp",
    size: 14
  }), " ", p.up)), p.kind === 'video' && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 12,
      right: 12,
      width: 30,
      height: 30,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(0,0,0,0.5)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "14",
    height: "14",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  })))));
}

// ---- POST DETAIL OVERLAY (embossed surface: media + comments + threads) ----
function PostDetail({
  post,
  onClose
}) {
  const [draft, setDraft] = React.useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 80,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 28,
      background: 'rgba(5,5,6,0.62)',
      WebkitBackdropFilter: 'blur(6px)',
      backdropFilter: 'blur(6px)',
      animation: 'fadeIn 180ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      width: '100%',
      maxWidth: 1080,
      height: '100%',
      maxHeight: 720,
      borderRadius: 'var(--r-xl)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-lg)',
      overflow: 'hidden',
      animation: 'sheetUp 220ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 58%',
      position: 'relative',
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 'var(--r-lg)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: post.art
  }), post.kind === 'video' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: '0 8px 24px rgba(0,0,0,0.5)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "26",
    height: "26",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 42%',
      display: 'flex',
      flexDirection: 'column',
      minWidth: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: '18px 20px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: post.avatar,
    size: 38
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 15,
      color: 'var(--fg-1)'
    }
  }, post.by), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.05em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, post.tag, " \xB7 ", post.comments, " comments")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    style: {
      padding: '9px 16px',
      fontSize: 13
    }
  }, "Follow"), /*#__PURE__*/React.createElement(IconBtn, {
    name: "close",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px 12px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 22,
      letterSpacing: '-0.015em',
      color: 'var(--fg-1)'
    }
  }, post.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--coral)',
      padding: '8px 14px',
      borderRadius: 999,
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowUp",
    size: 15
  }), " ", post.up), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--fg-2)',
      padding: '8px 14px',
      borderRadius: 999,
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "comment",
    size: 15
  }), " ", post.comments), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "bookmark"
  }), /*#__PURE__*/React.createElement(IconBtn, {
    name: "share"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '16px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 14
    }
  }, "Comments"), WEB_COMMENTS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 11
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: c.avatar,
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 13px',
      borderRadius: '4px 14px 14px 14px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 13,
      color: 'var(--fg-1)'
    }
  }, c.by), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)'
    }
  }, c.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13.5,
      lineHeight: 1.45,
      color: 'var(--fg-2)'
    }
  }, c.text)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '7px 4px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--fg-3)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrowUp",
    size: 13
  }), " ", c.up), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12,
      color: 'var(--fg-3)',
      cursor: 'pointer'
    }
  }, "Reply")), c.replies.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 12,
      paddingLeft: 6,
      borderLeft: '2px solid var(--hairline)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: r.avatar,
    size: 26
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '9px 12px',
      borderRadius: '4px 12px 12px 12px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 12,
      color: 'var(--fg-1)'
    }
  }, r.by), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, r.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      lineHeight: 1.4,
      color: 'var(--fg-2)'
    }
  }, r.text)))))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '8px 8px 8px 18px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    placeholder: "Add a comment\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => setDraft(''),
    style: {
      width: 36,
      height: 36,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 16
  })))))));
}

// ---- COLLAPSIBLE INSTAGRAM-LIKE CHAT moved to WebChat.jsx ----

function ViewFeed() {
  const [openPost, setOpenPost] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      padding: 24,
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '18px 24px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 19,
      color: 'var(--fg-1)'
    }
  }, "Feed"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 16,
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    active: true
  }, "For you"), /*#__PURE__*/React.createElement(Chip, null, "Following"), /*#__PURE__*/React.createElement(Chip, null, "Painting"), /*#__PURE__*/React.createElement(Chip, null, "3D"), /*#__PURE__*/React.createElement(Chip, null, "Photo")), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    style: {
      padding: '9px 16px',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 15
  }), " Post media"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      columnCount: 5,
      columnGap: 16
    }
  }, WEB_FEED.map(p => /*#__PURE__*/React.createElement(MediaPin, {
    key: p.id,
    p: p,
    onOpen: setOpenPost
  }))))), openPost && /*#__PURE__*/React.createElement(PostDetail, {
    post: openPost,
    onClose: () => setOpenPost(null)
  }));
}
Object.assign(window, {
  ViewFeed
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebFeed.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebProfile.jsx
try { (() => {
// arsyen web — "Profile" view: details + create portfolio/resume/upload/post actions

function CreateAction({
  icon,
  title,
  sub,
  accent
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: 18,
      borderRadius: 'var(--r-md)',
      cursor: 'pointer',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-raise)',
      transition: 'box-shadow 150ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      borderRadius: 14,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: accent ? 'var(--fg-on-coral)' : 'var(--coral)',
      background: accent ? 'var(--coral)' : 'var(--neu-base)',
      boxShadow: accent ? '3px 3px 8px rgba(0,0,0,0.4)' : 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 15,
      color: 'var(--fg-1)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12.5,
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, sub)), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 18,
    style: {
      color: 'var(--fg-3)'
    }
  }));
}
function ViewProfile({
  onBack
}) {
  const me = WEB_ME;
  const [tab, setTab] = React.useState('Portfolio');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      padding: 24,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      maxWidth: 1040,
      margin: '0 auto',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 140,
      flexShrink: 0,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: me.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(transparent 40%, rgba(20,20,22,0.5))'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 24,
      left: 24
    }
  }, onBack && /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    glass: true,
    onClick: onBack
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 24,
      right: 24,
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "share",
    glass: true
  }), /*#__PURE__*/React.createElement(IconBtn, {
    name: "settings",
    glass: true
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '0 32px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 18,
      marginTop: -40,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 999,
      boxShadow: '0 0 0 5px var(--neu-base)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: me.avatar,
    size: 92
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      paddingBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 28,
      letterSpacing: '-0.02em',
      color: 'var(--fg-1)'
    }
  }, me.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--fg-3)',
      marginTop: 3
    }
  }, me.handle, " \xB7 ", me.discipline, " \xB7 ", me.city)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      paddingBottom: 6
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    style: {
      padding: '11px 18px'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "link",
    size: 16
  }), " Share"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    style: {
      padding: '11px 20px'
    }
  }, "Edit profile"))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 15,
      lineHeight: 1.55,
      color: 'var(--fg-2)',
      margin: '18px 0 0',
      maxWidth: 620
    }
  }, me.bio), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      marginTop: 14
    }
  }, me.skills.map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12.5,
      color: 'var(--fg-2)',
      padding: '6px 13px',
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, s))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 30,
      margin: '24px 0',
      padding: '20px 26px',
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset)'
    }
  }, me.stats.map(s => /*#__PURE__*/React.createElement(StatBlock, {
    key: s.label,
    value: s.value,
    label: s.label
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '8px 0 14px'
    }
  }, "Create"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CreateAction, {
    icon: "briefcase",
    title: "Create portfolio",
    sub: "Curate a gallery-grade showcase",
    accent: true
  }), /*#__PURE__*/React.createElement(CreateAction, {
    icon: "fileText",
    title: "Create r\xE9sum\xE9",
    sub: "A clean, exportable artist CV"
  }), /*#__PURE__*/React.createElement(CreateAction, {
    icon: "upload",
    title: "Upload work",
    sub: "Add a piece to your profile"
  }), /*#__PURE__*/React.createElement(CreateAction, {
    icon: "feed",
    title: "Post",
    sub: "Share to the feed or ask the room"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      margin: '28px 0 16px'
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    options: ['Portfolio', 'Posts', 'Chat', 'About'],
    value: tab,
    onChange: setTab
  })), tab === 'Chat' ? /*#__PURE__*/React.createElement(TeamChat, null) : tab === 'About' ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 15,
      lineHeight: 1.65,
      color: 'var(--fg-2)',
      margin: 0,
      maxWidth: 640
    }
  }, "Based in Oslo. Working in oil and light since 2016. I build small, deliberate crews for short films and exhibitions \u2014 slow correspondence, considered work. Currently open to commissions for covers, plates, and editions.") : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14
    }
  }, [2, 5, 6, 3, 1, 4, 7, 0].map((idx, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 130,
      borderRadius: 11,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  }))))))));
}

// Team chat — only the people on your project team (not public DMs)
function TeamChat() {
  const [draft, setDraft] = React.useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 240,
      flexShrink: 0,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      padding: '14px 16px 8px'
    }
  }, "Project team \xB7 ", WEB_TEAM.length), WEB_TEAM.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.name,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: '9px 16px',
      cursor: 'pointer'
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = 'var(--neu-inset-sm)',
    onMouseLeave: e => e.currentTarget.style.boxShadow = 'none'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: m.avatar,
    size: 36
  }), m.online && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 0,
      bottom: 0,
      width: 10,
      height: 10,
      borderRadius: 999,
      background: '#4ADE80',
      boxShadow: '0 0 0 2px var(--neu-base)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 13.5,
      color: 'var(--fg-1)'
    }
  }, m.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)',
      marginTop: 1
    }
  }, m.role))))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      display: 'flex',
      flexDirection: 'column',
      maxHeight: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '14px 18px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 9,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "users",
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)'
    }
  }, "Team \u2014 Nightwork"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, "private to the crew"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, WEB_TEAM_THREAD.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      flexDirection: m.me ? 'row-reverse' : 'row',
      alignItems: 'flex-end'
    }
  }, !m.me && /*#__PURE__*/React.createElement(Avatar, {
    index: m.who,
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '72%'
    }
  }, !m.me && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--fg-3)',
      margin: '0 0 3px 4px'
    }
  }, m.name, " \xB7 ", m.when), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 13px',
      borderRadius: m.me ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
      background: m.me ? 'var(--coral)' : 'var(--neu-base)',
      color: m.me ? 'var(--fg-on-coral)' : 'var(--fg-1)',
      boxShadow: m.me ? '3px 3px 8px rgba(0,0,0,0.4)' : 'var(--neu-lift)',
      fontFamily: 'var(--font-text)',
      fontSize: 13.5,
      lineHeight: 1.45
    }
  }, m.text))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '8px 8px 8px 18px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: draft,
    onChange: e => setDraft(e.target.value),
    placeholder: "Message the team\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 14
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => setDraft(''),
    style: {
      width: 38,
      height: 38,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 17
  }))))));
}
Object.assign(window, {
  ViewProfile
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebProfile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebProjects.jsx
try { (() => {
// arsyen web — "Go to Project" view: Projects Navigator (left) + detail/workflows (right)

function ProjectStatusPill({
  status
}) {
  const map = {
    'In production': 'var(--coral)',
    'In review': '#5B9DFF',
    'Planning': '#F5B544'
  };
  const c = map[status] || 'var(--fg-3)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: c
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: c,
      boxShadow: `0 0 7px ${c}`
    }
  }), status);
}
function CrewStack({
  crew,
  size = 24
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex'
    }
  }, crew.map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      marginLeft: i ? -8 : 0,
      borderRadius: 999,
      boxShadow: '0 0 0 3px var(--neu-base)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: a,
    size: size
  }))));
}

// ---- LEFT: Projects Navigator ----
function ProjectsNavigator({
  projects,
  activeId,
  onSelect,
  onCollapse
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 320,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px 20px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 19,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em'
    }
  }, "Projects"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginTop: 3
    }
  }, projects.length, " active")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 11,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-1)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    onClick: onCollapse,
    title: "Collapse",
    style: {
      width: 34,
      height: 34,
      borderRadius: 11,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-2)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sidebar",
    size: 17
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '4px 14px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, projects.map(p => {
    const on = p.id === activeId;
    return /*#__PURE__*/React.createElement("div", {
      key: p.id,
      onClick: () => onSelect(p.id),
      style: {
        padding: 12,
        borderRadius: 'var(--r-md)',
        cursor: 'pointer',
        background: 'var(--neu-base)',
        boxShadow: on ? 'var(--neu-inset)' : 'var(--neu-raise-sm)',
        transition: 'box-shadow 180ms var(--ease-out)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 56,
        height: 56,
        borderRadius: 12,
        overflow: 'hidden',
        flexShrink: 0,
        boxShadow: 'var(--neu-inset-sm)'
      }
    }, /*#__PURE__*/React.createElement(ArtFill, {
      index: p.art
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-text)',
        fontWeight: 600,
        fontSize: 14,
        color: 'var(--fg-1)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, p.title), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4
      }
    }, /*#__PURE__*/React.createElement(ProjectStatusPill, {
      status: p.status
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: 9
      }
    }, /*#__PURE__*/React.createElement(CrewStack, {
      crew: p.crew,
      size: 20
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 9.5,
        color: 'var(--fg-3)'
      }
    }, p.progress, "%")))));
  })));
}

// ---- LEFT (collapsed): thin rail of project thumbnails ----
function ProjectsRail({
  projects,
  activeId,
  onSelect,
  onExpand
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 72,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14,
      padding: '18px 0',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onExpand,
    title: "Show projects",
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      border: 'none',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-2)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "sidebar",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 1,
      background: 'var(--hairline)'
    }
  }), projects.map(p => {
    const on = p.id === activeId;
    return /*#__PURE__*/React.createElement("button", {
      key: p.id,
      onClick: () => onSelect(p.id),
      title: p.title,
      style: {
        width: 46,
        height: 46,
        borderRadius: 13,
        border: 'none',
        cursor: 'pointer',
        overflow: 'hidden',
        padding: 3,
        background: 'var(--neu-base)',
        boxShadow: on ? 'var(--neu-inset)' : 'var(--neu-raise-sm)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        height: '100%',
        borderRadius: 10,
        overflow: 'hidden',
        boxShadow: 'var(--neu-inset-sm)'
      }
    }, /*#__PURE__*/React.createElement(ArtFill, {
      index: p.art
    })));
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-1)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 18
  })));
}

// ---- RIGHT: Project detail + workflow board ----
const STAGE_META = {
  'To do': {
    c: 'var(--fg-3)',
    key: 'TODO'
  },
  'In progress': {
    c: 'var(--coral)',
    key: 'WIP'
  },
  'Review': {
    c: '#5B9DFF',
    key: 'REV'
  },
  'Done': {
    c: '#4ADE80',
    key: 'DONE'
  }
};
function TaskCard({
  task,
  stage,
  num,
  active,
  onClick
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      padding: '11px 12px',
      borderRadius: 12,
      cursor: 'pointer',
      background: 'var(--neu-base)',
      boxShadow: active ? 'var(--neu-inset)' : pressed ? 'var(--neu-inset-sm)' : 'var(--neu-lift)',
      transform: pressed ? 'scale(0.98)' : 'none',
      transition: 'box-shadow 180ms var(--ease-out), transform 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-1)',
      lineHeight: 1.35
    }
  }, task.t), /*#__PURE__*/React.createElement(Avatar, {
    index: task.who,
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 9
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8.5,
      letterSpacing: '0.05em',
      color: 'var(--fg-3)'
    }
  }, STAGE_META[stage].key, "-", num), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      borderRadius: 4,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 9
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 8.5,
      color: 'var(--fg-3)',
      textTransform: 'uppercase',
      letterSpacing: '0.05em'
    }
  }, "Med")));
}

// Jira-like embossed task detail panel (opens below the board)
function TaskPanel({
  task,
  stage,
  num,
  onClose
}) {
  const fields = [{
    label: 'Status',
    value: stage,
    dot: STAGE_META[stage].c
  }, {
    label: 'Assignee',
    avatar: task.who
  }, {
    label: 'Priority',
    value: 'Medium',
    dot: '#F5B544'
  }, {
    label: 'Type',
    value: 'Task'
  }, {
    label: 'Story points',
    value: '3'
  }, {
    label: 'Sprint',
    value: 'Sprint 4'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift-hi)',
      overflow: 'hidden',
      animation: 'panelDown 260ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '16px 20px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 9,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 15
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.06em',
      color: 'var(--fg-3)'
    }
  }, STAGE_META[stage].key, "-", num), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 18,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em'
    }
  }, task.t), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    style: {
      padding: '8px 16px',
      fontSize: 13
    }
  }, "Open"), /*#__PURE__*/React.createElement(IconBtn, {
    name: "close",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '18px 22px',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 8
    }
  }, "Description"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 14,
      lineHeight: 1.55,
      color: 'var(--fg-2)',
      margin: 0
    }
  }, "Carried over from the Canvas. ", task.t, " \u2014 blocking picture lock until resolved. Coordinate with crew before moving to Review."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '20px 0 10px'
    }
  }, "Attachments"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, [2, 6].map(idx => /*#__PURE__*/React.createElement("div", {
    key: idx,
    style: {
      width: 110,
      height: 72,
      borderRadius: 10,
      boxShadow: 'var(--neu-lift)',
      padding: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      borderRadius: 7,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 110,
      height: 72,
      borderRadius: 10,
      boxShadow: 'var(--neu-lift)',
      padding: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 7,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: 3
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "18",
    height: "18",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '20px 0 10px'
    }
  }, "Subtasks"), ['Gather source plates', 'First pass', 'Crew review'].map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '9px 12px',
      borderRadius: 10,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 5,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: i === 0 ? 'var(--fg-on-coral)' : 'var(--fg-3)',
      background: i === 0 ? 'var(--coral)' : 'var(--neu-base)',
      boxShadow: i === 0 ? '2px 2px 5px rgba(0,0,0,0.4)' : 'var(--neu-inset-sm)'
    }
  }, i === 0 && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 11
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-text)',
      fontSize: 13.5,
      color: 'var(--fg-1)',
      textDecoration: i === 0 ? 'line-through' : 'none',
      opacity: i === 0 ? 0.6 : 1
    }
  }, s))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '20px 0 10px'
    }
  }, "Comments"), [{
    who: 3,
    name: 'Søren',
    when: '3h',
    text: 'Pushed a rough — see the attached clip. The swell still feels late.'
  }, {
    who: 0,
    name: 'Nadia',
    when: '1h',
    text: 'Agreed. I can re-cut the front by tomorrow.'
  }].map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: c.who,
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '9px 12px',
      borderRadius: '4px 12px 12px 12px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 12.5,
      color: 'var(--fg-1)'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)'
    }
  }, c.when)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      lineHeight: 1.4,
      color: 'var(--fg-2)'
    }
  }, c.text))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      borderRadius: 999,
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset)',
      padding: '7px 7px 7px 16px',
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Comment on this ticket\u2026",
    style: {
      flex: 1,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--fg-1)',
      fontFamily: 'var(--font-text)',
      fontSize: 13
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: '3px 3px 8px rgba(0,0,0,0.4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "send",
    size: 15
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 280,
      flexShrink: 0,
      padding: '18px 22px',
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset)'
    }
  }, fields.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.label,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 0',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 96,
      flexShrink: 0,
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, f.label), f.avatar != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: f.avatar,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-1)'
    }
  }, "Crew")) : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fg-1)',
      padding: '5px 12px',
      borderRadius: 999,
      boxShadow: 'var(--neu-lift)'
    }
  }, f.dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: f.dot
    }
  }), f.value))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap',
      marginTop: 14
    }
  }, ['nightwork', 'grade', 'blocking'].map(l => /*#__PURE__*/React.createElement("span", {
    key: l,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--coral)',
      padding: '5px 10px',
      borderRadius: 999,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, l))))));
}
function WorkflowBoard({
  stages,
  crew = []
}) {
  const cols = Object.keys(stages);
  const [sel, setSel] = React.useState(null);
  const [who, setWho] = React.useState('all'); // 'all' | avatar index
  const filterTask = t => who === 'all' || t.who === who;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, "Assignee"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setWho('all'),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      border: 'none',
      cursor: 'pointer',
      borderRadius: 999,
      padding: '6px 14px',
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 13,
      background: 'var(--neu-base)',
      color: who === 'all' ? 'var(--coral)' : 'var(--fg-2)',
      boxShadow: who === 'all' ? 'var(--neu-inset-sm)' : 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "users",
    size: 14
  }), " All"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, crew.map(a => /*#__PURE__*/React.createElement("button", {
    key: a,
    onClick: () => setWho(a),
    title: `Filter ${WEB_CREW_NAMES[a] || 'crew'}`,
    style: {
      border: 'none',
      cursor: 'pointer',
      padding: 3,
      borderRadius: 999,
      background: 'transparent',
      boxShadow: who === a ? 'var(--neu-inset)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      borderRadius: 999,
      boxShadow: who === a ? '0 0 0 2px var(--coral)' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: a,
    size: 28
  }))))), who !== 'all' && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)'
    }
  }, "showing ", WEB_CREW_NAMES[who] || 'crew', "\u2019s tickets")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${cols.length}, 1fr)`,
      gap: 14
    }
  }, cols.map(c => {
    const items = stages[c].map((t, i) => ({
      t,
      i
    })).filter(({
      t
    }) => filterTask(t));
    return /*#__PURE__*/React.createElement("div", {
      key: c,
      style: {
        borderRadius: 'var(--r-md)',
        background: 'var(--neu-well)',
        boxShadow: 'var(--neu-inset)',
        padding: 12,
        minHeight: 200
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7,
        padding: '2px 4px 12px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 7,
        height: 7,
        borderRadius: 999,
        background: STAGE_META[c].c
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        letterSpacing: '0.07em',
        textTransform: 'uppercase',
        color: 'var(--fg-2)'
      }
    }, c), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        color: 'var(--fg-3)',
        marginLeft: 'auto'
      }
    }, items.length)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, items.map(({
      t,
      i
    }) => {
      const id = `${c}-${i}`;
      return /*#__PURE__*/React.createElement(TaskCard, {
        key: i,
        task: t,
        stage: c,
        num: i + 1,
        active: sel && sel.id === id,
        onClick: () => setSel(sel && sel.id === id ? null : {
          id,
          task: t,
          stage: c,
          num: i + 1
        })
      });
    }), items.length === 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '14px 4px',
        fontFamily: 'var(--font-text)',
        fontSize: 12,
        color: 'var(--fg-3)',
        textAlign: 'center'
      }
    }, "\u2014")));
  })), sel && /*#__PURE__*/React.createElement(TaskPanel, {
    task: sel.task,
    stage: sel.stage,
    num: sel.num,
    onClose: () => setSel(null)
  }));
}
function ProjectDetail({
  project,
  onCollapseToggle,
  collapsed,
  onOpenTool,
  zen,
  onZen
}) {
  const [tab, setTab] = React.useState('Canvas');
  const [zenMode, setZenMode] = React.useState(false); // full-page focus (hides outer chrome)
  const heroCollapsed = zenMode && tab === 'Canvas'; // only Canvas hides the project details bar
  const bodyRef = React.useRef(null);
  // switching tabs keeps the current focus level — stay full-page if you were full-page,
  // just swap the content and reset scroll. (Leave focus only via the Exit / restore chip.)
  const switchTab = t => {
    if (bodyRef.current) bodyRef.current.scrollTop = 0;
    setTab(t);
  };
  const exitZen = () => {
    setZenMode(false);
    if (bodyRef.current) bodyRef.current.scrollTop = 0;
  };
  const onBodyScroll = e => {
    // any tab: scrolling the surface pushes the whole page into focus mode
    if (e.target.scrollTop > 36) setZenMode(true);
  };
  const onBodyWheel = e => {
    // works even when content doesn't overflow (e.g. a short Board) — a downward intent enters focus
    if (e.deltaY > 4 && !zenMode) setZenMode(true);
  };
  // mirror the focus state up to the shell (top bar + tab bar + navigator hide)
  React.useEffect(() => {
    onZen && onZen(zenMode);
  }, [zenMode]);
  // when the Canvas takes over and the hero collapses, snap it to the top of the section
  React.useEffect(() => {
    if (heroCollapsed && bodyRef.current) {
      const el = bodyRef.current;
      requestAnimationFrame(() => {
        el.scrollTop = 0;
      });
    }
  }, [heroCollapsed]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      borderRadius: zenMode ? 0 : 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: zenMode ? 'none' : 'var(--neu-raise)',
      overflow: 'hidden',
      transition: 'border-radius 320ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxHeight: heroCollapsed ? 0 : 280,
      opacity: heroCollapsed ? 0 : 1,
      overflow: 'hidden',
      transition: 'max-height 360ms var(--ease-out), opacity 240ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 150,
      flexShrink: 0,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: project.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(90deg, rgba(11,12,13,0.7), transparent 60%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 20,
      bottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(ProjectStatusPill, {
    status: project.status
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 26,
      letterSpacing: '-0.02em',
      color: '#fff'
    }
  }, project.title)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 16,
      top: 16,
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "link",
    glass: true
  }), /*#__PURE__*/React.createElement(IconBtn, {
    name: "more",
    glass: true
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      padding: '14px 22px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement(Meta2, {
    label: "Your role",
    value: project.role
  }), /*#__PURE__*/React.createElement(Meta2, {
    label: "Type",
    value: project.type
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, "Crew"), /*#__PURE__*/React.createElement(CrewStack, {
    crew: project.crew,
    size: 24
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      minWidth: 160
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, "Progress"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-1)'
    }
  }, project.progress, "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 8,
      borderRadius: 999,
      background: 'var(--neu-well)',
      boxShadow: 'var(--neu-inset-sm)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${project.progress}%`,
      height: '100%',
      borderRadius: 999,
      background: 'var(--coral)',
      boxShadow: '0 0 10px var(--coral-glow)'
    }
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 22px 0',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Segmented, {
    options: ['Canvas', 'Board', 'Resources', 'Milestones', 'Files'],
    value: tab,
    onChange: switchTab
  }), zenMode && /*#__PURE__*/React.createElement("button", {
    onClick: exitZen,
    title: heroCollapsed ? 'Show project header' : 'Exit focus',
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      marginLeft: 'auto',
      border: 'none',
      cursor: 'pointer',
      borderRadius: 999,
      padding: '7px 13px',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      color: 'var(--fg-2)',
      fontFamily: 'var(--font-text)',
      fontSize: 12.5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 14,
    style: {
      transform: 'rotate(-90deg)'
    }
  }), " ", heroCollapsed ? project.title : 'Exit focus')), /*#__PURE__*/React.createElement("div", {
    ref: bodyRef,
    onScroll: onBodyScroll,
    onWheel: onBodyWheel,
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: tab === 'Canvas' ? 0 : '16px 22px 22px'
    }
  }, tab === 'Board' && /*#__PURE__*/React.createElement(WorkflowBoard, {
    stages: project.stages,
    crew: project.crew
  }), tab === 'Canvas' && /*#__PURE__*/React.createElement(ProjectCanvas, {
    project: project
  }), tab === 'Resources' && /*#__PURE__*/React.createElement(ProjectResources, {
    project: project,
    onOpenTool: onOpenTool
  }), tab === 'Milestones' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, project.milestones.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '16px 18px',
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-3)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 15
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 15,
      color: 'var(--fg-1)'
    }
  }, m.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--coral)'
    }
  }, m.date)))), tab === 'Files' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))',
      gap: 14
    }
  }, [0, 1, 2, 3, 4, 5].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)',
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 90,
      borderRadius: 10,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: (project.art + i) % 8
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--fg-3)',
      marginTop: 8
    }
  }, "plate_", String(i + 1).padStart(2, '0'), ".tif"))))));
}
function Meta2({
  label,
  value
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)'
    }
  }, value));
}

// ---- CANVAS: endless Notion-like project doc ----
// ---- block renderers ----
function CanvasBlockBody({
  block
}) {
  const t = block.type;
  if (t === 'h1') return /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 34,
      letterSpacing: '-0.025em',
      color: 'var(--fg-1)',
      margin: '4px 0'
    }
  }, block.text);
  if (t === 'h2') return /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 21,
      letterSpacing: '-0.01em',
      color: 'var(--fg-1)',
      margin: '6px 0'
    }
  }, block.text);
  if (t === 'text') return /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 16,
      lineHeight: 1.6,
      color: 'var(--fg-2)',
      margin: '4px 0'
    }
  }, block.text);
  if (t === 'bullet') return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 11,
      padding: '3px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: 'var(--fg-3)',
      marginTop: 9,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 15,
      lineHeight: 1.5,
      color: 'var(--fg-2)'
    }
  }, block.text));
  if (t === 'images') return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(${block.imgs.length}, minmax(0, 240px))`,
      gap: 12,
      padding: '4px 0'
    }
  }, block.imgs.map(idx => /*#__PURE__*/React.createElement("div", {
    key: idx,
    style: {
      padding: 8,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 150,
      borderRadius: 10,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  })))));
  if (t === 'video') return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 280,
      borderRadius: 'var(--r-md)',
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)',
      margin: '4px 0'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: 3
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(0,0,0,0.35)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 60,
      height: 60,
      borderRadius: 999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--coral)',
      color: 'var(--fg-on-coral)',
      boxShadow: '0 8px 24px rgba(0,0,0,0.5)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "24",
    height: "24",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 5v14l11-7z"
  })))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 14,
      bottom: 12,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: '#fff',
      background: 'rgba(0,0,0,0.5)',
      padding: '5px 10px',
      borderRadius: 999
    }
  }, "YouTube \xB7 ", block.src));
  if (t === 'link') return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: 14,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      margin: '4px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 11,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "link",
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)'
    }
  }, block.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--fg-3)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, block.url)), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 16,
    style: {
      color: 'var(--fg-3)'
    }
  }));
  if (t === 'todo') return /*#__PURE__*/React.createElement(CanvasTodo, {
    block: block
  });
  return null;
}
function CanvasTodo({
  block
}) {
  const [done, setDone] = React.useState(!!block.done);
  return /*#__PURE__*/React.createElement("div", {
    onClick: () => setDone(d => !d),
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 11,
      padding: '9px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)',
      margin: '3px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: 6,
      marginTop: 1,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: done ? 'var(--coral)' : 'var(--neu-base)',
      color: 'var(--fg-on-coral)',
      boxShadow: done ? '2px 2px 5px rgba(0,0,0,0.4)' : 'var(--neu-inset-sm)'
    }
  }, done && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 13
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-text)',
      fontSize: 14,
      lineHeight: 1.4,
      color: done ? 'var(--fg-3)' : 'var(--fg-1)',
      textDecoration: done ? 'line-through' : 'none'
    }
  }, block.text), /*#__PURE__*/React.createElement(Avatar, {
    index: block.who,
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 8.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--coral)',
      marginTop: 3
    }
  }, "\u2192 board"));
}
const BLOCK_MENU = [{
  type: 'text',
  icon: 'fileText',
  label: 'Text'
}, {
  type: 'h2',
  icon: 'fileText',
  label: 'Heading'
}, {
  type: 'bullet',
  icon: 'feed',
  label: 'Bulleted list'
}, {
  type: 'todo',
  icon: 'check',
  label: 'To-do (syncs to board)'
}, {
  type: 'images',
  icon: 'image',
  label: 'Image'
}, {
  type: 'video',
  icon: 'eye',
  label: 'Video / YouTube'
}, {
  type: 'link',
  icon: 'link',
  label: 'Link'
}];

// Wraps each block with a Notion-like hover gutter (add + drag handle) and DnD
function CanvasBlock({
  block,
  index,
  onAdd,
  onDragStart,
  onDragOver,
  onDrop,
  dragging,
  dropTarget
}) {
  const [hover, setHover] = React.useState(false);
  const [menu, setMenu] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setMenu(false);
    },
    onDragOver: e => {
      e.preventDefault();
      onDragOver(index);
    },
    onDrop: () => onDrop(index),
    style: {
      position: 'relative',
      paddingLeft: 56,
      marginBottom: 6,
      borderRadius: 8,
      boxShadow: dropTarget ? 'inset 0 2px 0 var(--coral)' : 'none',
      opacity: dragging ? 0.4 : 1,
      transition: 'opacity 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 12,
      top: 4,
      display: 'flex',
      gap: 4,
      opacity: hover ? 1 : 0,
      transition: 'opacity 140ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setMenu(m => !m),
    title: "Add block",
    style: {
      width: 22,
      height: 22,
      borderRadius: 6,
      border: 'none',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-2)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 14
  })), /*#__PURE__*/React.createElement("button", {
    draggable: true,
    title: "Drag to reorder",
    onDragStart: () => onDragStart(index),
    style: {
      width: 22,
      height: 22,
      borderRadius: 6,
      border: 'none',
      cursor: 'grab',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-3)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "13",
    height: "13",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "6",
    r: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "15",
    cy: "6",
    r: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "12",
    r: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "15",
    cy: "12",
    r: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "18",
    r: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "15",
    cy: "18",
    r: "1.4"
  })))), menu && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 40,
      top: 30,
      zIndex: 30,
      width: 230,
      padding: 7,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-lg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      padding: '6px 10px 4px'
    }
  }, "Add below"), BLOCK_MENU.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.type,
    onClick: () => {
      onAdd(index, m.type);
      setMenu(false);
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 10px',
      borderRadius: 8,
      cursor: 'pointer',
      color: 'var(--fg-1)'
    },
    onMouseEnter: e => e.currentTarget.style.boxShadow = 'var(--neu-inset-sm)',
    onMouseLeave: e => e.currentTarget.style.boxShadow = 'none'
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 24,
      height: 24,
      borderRadius: 7,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: m.icon,
    size: 13
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13.5
    }
  }, m.label)))), /*#__PURE__*/React.createElement(CanvasBlockBody, {
    block: block
  }));
}
let CANVAS_UID = 100;
function ProjectCanvas({
  project
}) {
  const [blocks, setBlocks] = React.useState([{
    id: 1,
    type: 'h1',
    text: project.title
  }, {
    id: 2,
    type: 'text',
    text: 'A night study reconstructed from memory rather than reference. This canvas is the single source of truth — notes, references, and tasks live here. Anyone with access can edit, and any task created here appears automatically on the Board.'
  }, {
    id: 3,
    type: 'h2',
    text: 'Look & references'
  }, {
    id: 4,
    type: 'images',
    imgs: [2, 6, 4, 5]
  }, {
    id: 5,
    type: 'bullet',
    text: 'Cold key light, warm practicals — the contrast carries the whole grade.'
  }, {
    id: 6,
    type: 'bullet',
    text: 'Grain held deliberately; never fully clean. Analog soul inside modern tooling.'
  }, {
    id: 7,
    type: 'h2',
    text: 'Reference reel'
  }, {
    id: 8,
    type: 'video',
    src: 'nightwork_ref.mp4'
  }, {
    id: 9,
    type: 'link',
    title: 'Shared grade — Frame.io review',
    url: 'frame.io/arsyen/nightwork/grade-v3'
  }, {
    id: 10,
    type: 'h2',
    text: 'Tasks'
  }, {
    id: 11,
    type: 'todo',
    text: 'Confirm festival deadline with producer',
    who: 0
  }, {
    id: 12,
    type: 'todo',
    text: 'Send score reference playlist to Søren',
    who: 3,
    done: true
  }, {
    id: 13,
    type: 'todo',
    text: 'Book grading suite for the week of the 18th',
    who: 1
  }]);
  const dragIdx = React.useRef(null);
  const [dragging, setDragging] = React.useState(null);
  const [dropTarget, setDropTarget] = React.useState(null);
  const placeholder = {
    text: 'New paragraph — start typing…',
    h2: 'New heading',
    bullet: 'List item',
    todo: 'New task',
    link_title: 'Pasted link',
    link_url: 'https://…'
  };
  const addAfter = (i, type) => {
    const id = ++CANVAS_UID;
    let b = {
      id,
      type
    };
    if (type === 'text') b.text = 'New paragraph — start typing…';else if (type === 'h2') b.text = 'New heading';else if (type === 'bullet') b.text = 'New list item';else if (type === 'todo') {
      b.text = 'New task';
      b.who = 0;
    } else if (type === 'images') b.imgs = [7, 0];else if (type === 'video') b.src = 'clip.mp4';else if (type === 'link') {
      b.title = 'Pasted link';
      b.url = 'https://…';
    }
    setBlocks(prev => {
      const n = [...prev];
      n.splice(i + 1, 0, b);
      return n;
    });
  };
  const onDragStart = i => {
    dragIdx.current = i;
    setDragging(i);
  };
  const onDragOver = i => {
    if (i !== dropTarget) setDropTarget(i);
  };
  const onDrop = i => {
    const from = dragIdx.current;
    if (from == null || from === i) {
      setDragging(null);
      setDropTarget(null);
      return;
    }
    setBlocks(prev => {
      const n = [...prev];
      const [m] = n.splice(from, 1);
      n.splice(from < i ? i : i, 0, m);
      return n;
    });
    dragIdx.current = null;
    setDragging(null);
    setDropTarget(null);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 940,
      margin: '0 auto',
      padding: '30px 40px 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingLeft: 56,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 10
    }
  }, "Project canvas \xB7 last edited 1h ago by you \xB7 drag ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fg-2)'
    }
  }, "\u22EE\u22EE"), " to reorder, ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fg-2)'
    }
  }, "+"), " to add"), blocks.map((b, i) => /*#__PURE__*/React.createElement(CanvasBlock, {
    key: b.id,
    block: b,
    index: i,
    onAdd: addAfter,
    onDragStart: onDragStart,
    onDragOver: onDragOver,
    onDrop: onDrop,
    dragging: dragging === i,
    dropTarget: dropTarget === i && dragging !== i
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingLeft: 56,
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '9px 0 0 56px',
      color: 'var(--fg-3)',
      fontFamily: 'var(--font-text)',
      fontSize: 14,
      cursor: 'text'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 16
  }), " Type \u2018/\u2019 for a block, or just start writing\u2026"));
}

// ---- RESOURCES: artefacts created from the Tools section ----
function ProjectResources({
  project,
  onOpenTool
}) {
  const groups = [{
    group: 'Moodboards',
    tool: 'Moodboard',
    icon: 'palette',
    items: [{
      name: 'Nightwork — look dev',
      art: 2,
      when: 'Jun 2'
    }, {
      name: 'Lighting & grain refs',
      art: 6,
      when: 'May 28'
    }]
  }, {
    group: 'Scripts',
    tool: 'Brief builder',
    icon: 'fileText',
    items: [{
      name: 'Shooting script v3',
      when: 'Jun 4',
      meta: '14 pages'
    }, {
      name: 'Director\u2019s brief',
      when: 'May 30',
      meta: '2 pages'
    }]
  }, {
    group: 'Invoices',
    tool: 'Invoice',
    icon: 'briefcase',
    items: [{
      name: 'INV ARS-014 — cover plate',
      when: 'Jun 1',
      meta: '$1,800'
    }, {
      name: 'INV ARS-009 — concept',
      when: 'May 20',
      meta: '$400'
    }]
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "grid",
    size: 15,
    style: {
      color: 'var(--coral)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-3)'
    }
  }, "Artefacts created from the ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--fg-2)',
      fontWeight: 600
    }
  }, "Tools"), " section, attached to this project.")), groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.group,
    style: {
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 9,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: g.icon,
    size: 15
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-2)'
    }
  }, g.group), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)'
    }
  }, "\xB7 from ", g.tool)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
      gap: 14
    }
  }, g.items.map((it, i) => /*#__PURE__*/React.createElement(ResourceCard, {
    key: i,
    item: it,
    icon: g.icon,
    tool: g.tool,
    onOpen: () => onOpenTool && onOpenTool(g.tool)
  })), /*#__PURE__*/React.createElement("button", {
    onClick: () => onOpenTool && onOpenTool(g.tool),
    style: {
      minHeight: 96,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      border: 'none',
      cursor: 'pointer',
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)',
      color: 'var(--fg-3)',
      fontFamily: 'var(--font-text)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 18
  }), " New in ", g.tool)))));
}
function ResourceCard({
  item,
  icon,
  tool,
  onOpen
}) {
  const [pressed, setPressed] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    onClick: onOpen,
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => {
      setPressed(false);
      setHover(false);
    },
    onPointerEnter: () => setHover(true),
    style: {
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-lift)',
      cursor: 'pointer',
      overflow: 'hidden',
      transform: pressed ? 'scale(0.985)' : 'none',
      transition: 'box-shadow 180ms var(--ease-out), transform 140ms var(--ease-out)'
    }
  }, item.art != null ?
  /*#__PURE__*/
  /* moodboard: a stacked-corner PREVIEW (not the full board) that links out */
  React.createElement("div", {
    style: {
      position: 'relative',
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 14,
      right: 14,
      top: 3,
      height: 12,
      borderRadius: '8px 8px 0 0',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-lift)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 96,
      borderRadius: 10,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: item.art
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(8,8,10,0.35)',
      opacity: hover ? 1 : 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'opacity 160ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: '#fff',
      background: 'var(--glass-fill)',
      WebkitBackdropFilter: 'blur(10px)',
      backdropFilter: 'blur(10px)',
      border: '1px solid var(--glass-edge)',
      borderRadius: 999,
      padding: '6px 12px'
    }
  }, "Open in ", tool, " ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 12
  }))))) : /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 96,
      borderRadius: 10,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-3)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 26
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '4px 14px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 14,
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, item.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--fg-3)'
    }
  }, item.when), item.meta ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--coral)'
    }
  }, item.meta) : /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      fontFamily: 'var(--font-mono)',
      fontSize: 9.5,
      color: 'var(--coral)'
    }
  }, "Open ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 11
  })))));
}
function ViewProjects({
  onOpenTool,
  zen,
  onZen
}) {
  const [activeId, setActiveId] = React.useState(WEB_PROJECTS[0].id);
  const [collapsed, setCollapsed] = React.useState(false);
  const project = WEB_PROJECTS.find(p => p.id === activeId);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: zen ? 0 : 20,
      height: '100%',
      padding: zen ? 0 : 24,
      boxSizing: 'border-box',
      transition: 'padding 320ms var(--ease-out), gap 320ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      width: zen ? 0 : 'auto',
      opacity: zen ? 0 : 1,
      overflow: 'hidden',
      transition: 'width 320ms var(--ease-out), opacity 200ms var(--ease-out)'
    }
  }, collapsed ? /*#__PURE__*/React.createElement(ProjectsRail, {
    projects: WEB_PROJECTS,
    activeId: activeId,
    onSelect: setActiveId,
    onExpand: () => setCollapsed(false)
  }) : /*#__PURE__*/React.createElement(ProjectsNavigator, {
    projects: WEB_PROJECTS,
    activeId: activeId,
    onSelect: setActiveId,
    onCollapse: () => setCollapsed(true)
  })), /*#__PURE__*/React.createElement(ProjectDetail, {
    project: project,
    collapsed: collapsed,
    onCollapseToggle: () => setCollapsed(c => !c),
    onOpenTool: onOpenTool,
    zen: zen,
    onZen: onZen
  }));
}
Object.assign(window, {
  ViewProjects
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebProjects.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebSettings.jsx
try { (() => {
// arsyen web — "Settings" view: general app settings (embossed toggles, rows)

function Toggle({
  on,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    style: {
      width: 50,
      height: 30,
      borderRadius: 999,
      border: 'none',
      cursor: 'pointer',
      position: 'relative',
      background: on ? 'var(--coral)' : 'var(--neu-base)',
      boxShadow: on ? 'inset 2px 2px 5px rgba(0,0,0,0.35)' : 'var(--neu-inset)',
      transition: 'background 200ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: on ? 23 : 3,
      width: 24,
      height: 24,
      borderRadius: 999,
      background: on ? 'var(--fg-on-coral)' : 'var(--fg-2)',
      boxShadow: '2px 2px 5px rgba(0,0,0,0.4)',
      transition: 'left 200ms var(--ease-out)'
    }
  }));
}
function SettingRow({
  icon,
  title,
  sub,
  control,
  last
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '16px 4px',
      boxShadow: last ? 'none' : 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-2)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 19
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 15,
      color: 'var(--fg-1)'
    }
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 12.5,
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, sub)), control);
}
function SettingsCard({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      margin: '0 0 12px 4px'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 20px',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)'
    }
  }, children));
}
function ViewSettings() {
  const [s, setS] = React.useState({
    crew: true,
    mentions: true,
    digest: false,
    discoverable: true,
    sales: true
  });
  const set = k => setS(p => ({
    ...p,
    [k]: !p[k]
  }));
  const chev = /*#__PURE__*/React.createElement(Icon, {
    name: "chevron",
    size: 18,
    style: {
      color: 'var(--fg-3)'
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      padding: 24,
      boxSizing: 'border-box',
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 30,
      letterSpacing: '-0.02em',
      color: 'var(--fg-1)',
      margin: '4px 0 24px'
    }
  }, "Settings"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: 18,
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    index: WEB_ME.avatar,
    size: 56
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 18,
      color: 'var(--fg-1)'
    }
  }, WEB_ME.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, WEB_ME.handle, " \xB7 arsyen member since 2024")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    style: {
      padding: '10px 18px'
    }
  }, "Manage account")), /*#__PURE__*/React.createElement(SettingsCard, {
    label: "Notifications"
  }, /*#__PURE__*/React.createElement(SettingRow, {
    icon: "users",
    title: "Crew invitations",
    sub: "When someone invites you to a project",
    control: /*#__PURE__*/React.createElement(Toggle, {
      on: s.crew,
      onToggle: () => set('crew')
    })
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "comment",
    title: "Mentions & replies",
    sub: "On your posts and in chats",
    control: /*#__PURE__*/React.createElement(Toggle, {
      on: s.mentions,
      onToggle: () => set('mentions')
    })
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "feed",
    title: "Weekly digest",
    sub: "A quiet summary, once a week",
    control: /*#__PURE__*/React.createElement(Toggle, {
      on: s.digest,
      onToggle: () => set('digest')
    }),
    last: true
  })), /*#__PURE__*/React.createElement(SettingsCard, {
    label: "Privacy & discovery"
  }, /*#__PURE__*/React.createElement(SettingRow, {
    icon: "compass",
    title: "Discoverable in search",
    sub: "Let other artists find you for crews",
    control: /*#__PURE__*/React.createElement(Toggle, {
      on: s.discoverable,
      onToggle: () => set('discoverable')
    })
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "bookmark",
    title: "Show work is for sale",
    sub: "Display pricing on your pieces",
    control: /*#__PURE__*/React.createElement(Toggle, {
      on: s.sales,
      onToggle: () => set('sales')
    })
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "lock",
    title: "Blocked artists",
    sub: "Manage who can reach you",
    control: chev,
    last: true
  })), /*#__PURE__*/React.createElement(SettingsCard, {
    label: "Appearance"
  }, /*#__PURE__*/React.createElement(SettingRow, {
    icon: "palette",
    title: "Theme",
    sub: "Matt black \xB7 embossed",
    control: /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--fg-2)',
        padding: '7px 13px',
        borderRadius: 999,
        boxShadow: 'var(--neu-inset-sm)'
      }
    }, "Default")
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "eye",
    title: "Reduce motion",
    sub: "Calm the chromatic & glow effects",
    control: /*#__PURE__*/React.createElement(Toggle, {
      on: false,
      onToggle: () => {}
    }),
    last: true
  })), /*#__PURE__*/React.createElement(SettingsCard, {
    label: "General"
  }, /*#__PURE__*/React.createElement(SettingRow, {
    icon: "briefcase",
    title: "Billing & membership",
    control: chev
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "link",
    title: "Connected accounts",
    control: chev
  }), /*#__PURE__*/React.createElement(SettingRow, {
    icon: "fileText",
    title: "Terms & privacy",
    control: chev,
    last: true
  })), /*#__PURE__*/React.createElement("button", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 9,
      width: '100%',
      padding: '15px',
      borderRadius: 'var(--r-md)',
      border: 'none',
      cursor: 'pointer',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      color: 'var(--coral)',
      fontFamily: 'var(--font-text)',
      fontWeight: 600,
      fontSize: 15,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "logout",
    size: 18
  }), " Sign out")));
}
Object.assign(window, {
  ViewSettings
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebSettings.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/WebTools.jsx
try { (() => {
// arsyen web — "Tools" view: grid of embossed square tools → full-screen tool page

function ToolTile({
  tool,
  onOpen
}) {
  const [pressed, setPressed] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: () => onOpen(tool),
    onPointerDown: () => setPressed(true),
    onPointerUp: () => setPressed(false),
    onPointerLeave: () => setPressed(false),
    style: {
      minHeight: 220,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: 18,
      textAlign: 'left',
      padding: 22,
      border: 'none',
      cursor: 'pointer',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: pressed ? 'var(--neu-inset)' : 'var(--neu-raise)',
      transition: 'box-shadow 150ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: tool.icon,
    size: 26
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 18,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em'
    }
  }, tool.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 13,
      color: 'var(--fg-3)',
      lineHeight: 1.4
    }
  }, tool.sub), /*#__PURE__*/React.createElement("span", {
    style: {
      marginTop: 7,
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fg-2)',
      padding: '5px 10px',
      borderRadius: 999,
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, tool.tag)));
}

// Full-screen tool workspace (generic embossed shell + tool-specific body)
function ToolPage({
  tool,
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 70,
      padding: 24,
      boxSizing: 'border-box',
      animation: 'fadeIn 160ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '16px 22px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    name: "back",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--coral)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: tool.icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 19,
      color: 'var(--fg-1)',
      letterSpacing: '-0.01em'
    }
  }, tool.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.05em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginTop: 2
    }
  }, tool.tag, " tool")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    style: {
      padding: '10px 16px',
      fontSize: 13
    }
  }, "Save"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    style: {
      padding: '10px 18px',
      fontSize: 13
    }
  }, "Export")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement(ToolBody, {
    tool: tool
  }))));
}
function ToolBody({
  tool
}) {
  // a couple of representative workspaces; others share the moodboard layout
  if (tool.id === 't2') {
    // Color grade
    const swatches = ['#1a0f14', '#3a1c22', '#7a2f33', '#c45c4a', '#e8b06a', '#f4e3c8'];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 860,
        margin: '0 auto'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 260,
        borderRadius: 'var(--r-md)',
        overflow: 'hidden',
        boxShadow: 'var(--neu-inset)',
        marginBottom: 20
      }
    }, /*#__PURE__*/React.createElement(ArtFill, {
      index: 2
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        letterSpacing: '0.1em',
        textTransform: 'uppercase',
        color: 'var(--fg-3)',
        marginBottom: 12
      }
    }, "Extracted palette"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(6, 1fr)',
        gap: 12
      }
    }, swatches.map(c => /*#__PURE__*/React.createElement("div", {
      key: c,
      style: {
        borderRadius: 'var(--r-md)',
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-raise-sm)',
        padding: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 80,
        borderRadius: 10,
        background: c,
        boxShadow: 'var(--neu-inset-sm)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 10,
        color: 'var(--fg-3)',
        marginTop: 8,
        textAlign: 'center'
      }
    }, c)))));
  }
  if (tool.id === 't4' || tool.id === 't8') {
    // Invoice / Contract — document
    return /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 720,
        margin: '0 auto',
        padding: 36,
        borderRadius: 'var(--r-lg)',
        background: 'var(--neu-base)',
        boxShadow: 'var(--neu-inset)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 28
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 22,
        color: 'var(--fg-1)'
      }
    }, tool.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        color: 'var(--fg-3)',
        marginTop: 4
      }
    }, "#ARS-2026-014 \xB7 Renn Okabe")), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 56,
        height: 56,
        borderRadius: 16,
        background: 'var(--coral)',
        color: 'var(--fg-on-coral)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 30,
        letterSpacing: '-0.04em'
      }
    }, "a")), ['Concept & moodboard', 'Cover plate — final', 'Two revisions'].map((row, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        padding: '14px 0',
        boxShadow: 'var(--neu-hairline)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-text)',
        fontSize: 15,
        color: 'var(--fg-1)'
      }
    }, row), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 14,
        color: 'var(--fg-2)'
      }
    }, "$", [400, 1200, 200][i]))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: 20
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 600,
        fontSize: 18,
        color: 'var(--fg-1)'
      }
    }, "Total"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 600,
        fontSize: 18,
        color: 'var(--coral)'
      }
    }, "$1,800")));
  }
  // default: moodboard / storyboard grid
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--fg-3)',
      marginBottom: 14
    }
  }, "Board \xB7 drag references in"), /*#__PURE__*/React.createElement("div", {
    style: {
      columnCount: 4,
      columnGap: 14
    }
  }, [2, 6, 1, 3, 5, 4, 7, 0, 2, 5].map((idx, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      breakInside: 'avoid',
      marginBottom: 14,
      padding: 7,
      borderRadius: 'var(--r-md)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: [150, 200, 120, 180][i % 4],
      borderRadius: 10,
      overflow: 'hidden',
      boxShadow: 'var(--neu-inset-sm)'
    }
  }, /*#__PURE__*/React.createElement(ArtFill, {
    index: idx
  }))))));
}
function ViewTools({
  openToolName,
  onConsumed
}) {
  const [open, setOpen] = React.useState(null);
  React.useEffect(() => {
    if (openToolName) {
      const t = WEB_TOOLS.find(x => x.name === openToolName) || WEB_TOOLS[0];
      setOpen(t);
      onConsumed && onConsumed();
    }
  }, [openToolName]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      padding: 24,
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      borderRadius: 'var(--r-lg)',
      background: 'var(--neu-base)',
      boxShadow: 'var(--neu-raise)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 28px 18px',
      boxShadow: 'var(--neu-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: 'var(--fg-1)'
    }
  }, "Tools"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-text)',
      fontSize: 14,
      color: 'var(--fg-3)',
      marginTop: 4
    }
  }, "Everything you need to run the work \u2014 open one to fill the screen.")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 20
    }
  }, WEB_TOOLS.map(t => /*#__PURE__*/React.createElement(ToolTile, {
    key: t.id,
    tool: t,
    onOpen: setOpen
  }))))), open && /*#__PURE__*/React.createElement(ToolPage, {
    tool: open,
    onBack: () => setOpen(null)
  }));
}
Object.assign(window, {
  ViewTools
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/WebTools.jsx", error: String((e && e.message) || e) }); }

})();
