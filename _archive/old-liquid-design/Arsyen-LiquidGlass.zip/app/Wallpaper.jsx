// arsyen — Liquid Glass wallpaper engine
// A persistent canvas of large, soft light-blobs drifting in slow lissajous
// paths over a near-black base. Rendered at low internal resolution and
// CSS-blurred so the gradients stay buttery (Apple-wallpaper feel).
// Reacts to: cursor (parallax) + active tab (hue palette lerp).

const WP_PALETTES = {
  // each: [r,g,b, radiusFrac, depth(parallax), driftScale]
  projects: [
    [255, 85, 93,  0.62, 0.9, 1.0],   // coral
    [150, 70, 220, 0.55, 0.5, 0.8],   // violet
    [232, 64, 120, 0.48, 1.3, 1.2],   // magenta
    [64, 110, 210, 0.52, 0.3, 0.7],   // blue
    [210, 96, 60,  0.40, 1.1, 1.1],   // ember
  ],
  discover: [
    [120, 80, 235, 0.60, 0.9, 0.9],   // violet
    [56, 120, 224, 0.58, 0.5, 0.8],   // blue
    [86, 60, 200, 0.46, 1.3, 1.1],    // indigo
    [40, 170, 180, 0.42, 0.3, 0.7],   // teal
    [255, 85, 93,  0.36, 1.2, 1.2],   // coral accent
  ],
  profile: [
    [255, 85, 93,  0.58, 0.9, 1.0],   // coral
    [240, 150, 70, 0.50, 0.5, 0.8],   // amber
    [225, 70, 130, 0.48, 1.3, 1.1],   // rose
    [70, 110, 215, 0.50, 0.3, 0.7],   // blue
    [150, 80, 220, 0.42, 1.1, 1.1],   // violet
  ],
};

function Wallpaper({ tab, glow = 1, motion = 1, reactivity = 1, black = false, emboss = false, accentRgb = null }) {
  const canvasRef = React.useRef(null);
  const stateRef = React.useRef(null);
  // keep live tweak values in a ref so the rAF loop reads the latest
  const cfg = React.useRef({ tab, glow, motion, reactivity, black, emboss, accentRgb });
  cfg.current = { tab, glow, motion, reactivity, black, emboss, accentRgb };

  React.useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { alpha: false });
    const RES = 0.42; // internal render scale
    let raf, W, H;

    // current (animated) colors, lerped toward the active palette
    const N = 5;
    const cur = Array.from({ length: N }, (_, i) => {
      const p = WP_PALETTES.projects[i];
      return { r: p[0], g: p[1], b: p[2], rad: p[3], depth: p[4], drift: p[5],
               px: 0.2 + i * 0.16, py: 0.3 + (i % 2) * 0.4 };
    });

    const mouse = { x: 0.5, y: 0.5, tx: 0.5, ty: 0.5 };

    function resize() {
      W = canvas.width = Math.max(2, Math.floor(window.innerWidth * RES));
      H = canvas.height = Math.max(2, Math.floor(window.innerHeight * RES));
      canvas.style.width = window.innerWidth + 'px';
      canvas.style.height = window.innerHeight + 'px';
    }
    resize();
    window.addEventListener('resize', resize);

    function onMove(e) {
      mouse.tx = e.clientX / window.innerWidth;
      mouse.ty = e.clientY / window.innerHeight;
    }
    window.addEventListener('pointermove', onMove);

    stateRef.current = { cur, mouse };

    let t0 = performance.now();
    function frame(now) {
      const { tab, glow, motion, reactivity, black, emboss, accentRgb } = cfg.current;
      const pal = WP_PALETTES[tab] || WP_PALETTES.projects;
      const dt = Math.min(64, now - t0); t0 = now;
      // a constant base flow so the wallpaper is ALWAYS moving, plus the
      // motion multiplier on top of it.
      const time = now * 0.00022 * (0.55 + motion);

      // embossed mode: a matt charcoal field (the embossing base) with a
      // very faint, slowly drifting light patch so it isn't dead-flat.
      if (emboss) {
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = '#191a1d';
        ctx.fillRect(0, 0, W, H);
        ctx.globalCompositeOperation = 'lighter';
        const hx = (0.5 + 0.2 * Math.sin(time * 0.5)) * W;
        const hy = (0.42 + 0.16 * Math.cos(time * 0.4)) * H;
        const hr = Math.max(W, H) * 0.55;
        const hg = ctx.createRadialGradient(hx, hy, 0, hx, hy, hr);
        hg.addColorStop(0, 'rgba(70,73,80,0.40)');
        hg.addColorStop(1, 'rgba(70,73,80,0)');
        ctx.fillStyle = hg;
        ctx.fillRect(0, 0, W, H);
        raf = requestAnimationFrame(frame);
        return;
      }

      // pure-black mode: solid void, no blobs
      if (black) {
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, W, H);
        raf = requestAnimationFrame(frame);
        return;
      }

      // lerp colors toward target palette (lead blob biased to chosen accent)
      const k = 1 - Math.pow(0.0015, dt / 16);
      for (let i = 0; i < N; i++) {
        const tgt = pal[i];
        const tr = (i === 0 && accentRgb) ? accentRgb[0] : tgt[0];
        const tg = (i === 0 && accentRgb) ? accentRgb[1] : tgt[1];
        const tb = (i === 0 && accentRgb) ? accentRgb[2] : tgt[2];
        cur[i].r += (tr - cur[i].r) * k;
        cur[i].g += (tg - cur[i].g) * k;
        cur[i].b += (tb - cur[i].b) * k;
        cur[i].rad += (tgt[3] - cur[i].rad) * k;
        cur[i].depth += (tgt[4] - cur[i].depth) * k;
        cur[i].drift += (tgt[5] - cur[i].drift) * k;
      }
      // smooth cursor
      mouse.x += (mouse.tx - mouse.x) * 0.06;
      mouse.y += (mouse.ty - mouse.y) * 0.06;
      const mdx = (mouse.x - 0.5);
      const mdy = (mouse.y - 0.5);

      // base
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#070809';
      ctx.fillRect(0, 0, W, H);

      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < N; i++) {
        const b = cur[i];
        const ph = i * 1.7;
        // slow lissajous drift, unique per blob (always animating)
        const dx = Math.sin(time * (0.7 + i * 0.13) + ph) * 0.23 * b.drift;
        const dy = Math.cos(time * (0.5 + i * 0.17) + ph * 1.3) * 0.20 * b.drift;
        const par = b.depth * reactivity * 0.10;
        const cx = (0.2 + i * 0.16 + dx - mdx * par) * W;
        const cy = (0.32 + (i % 2) * 0.36 + dy - mdy * par) * H;
        const rad = b.rad * Math.max(W, H) * (0.92 + 0.08 * Math.sin(time * 2.4 + ph));
        const a = 0.42 * glow;
        const grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
        grd.addColorStop(0, `rgba(${b.r|0},${b.g|0},${b.b|0},${a})`);
        grd.addColorStop(0.5, `rgba(${b.r|0},${b.g|0},${b.b|0},${a * 0.34})`);
        grd.addColorStop(1, `rgba(${b.r|0},${b.g|0},${b.b|0},0)`);
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(cx, cy, rad, 0, Math.PI * 2);
        ctx.fill();
      }

      // subtle dark core so center stays legible behind heavy text panels
      ctx.globalCompositeOperation = 'source-over';
      const core = ctx.createRadialGradient(W/2, H*0.55, 0, W/2, H*0.55, Math.max(W,H)*0.5);
      core.addColorStop(0, 'rgba(6,7,9,0.16)');
      core.addColorStop(1, 'rgba(6,7,9,0)');
      ctx.fillStyle = core;
      ctx.fillRect(0, 0, W, H);

      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onMove);
    };
  }, []);

  // CSS blur smooths the low-res canvas into liquid gradients
  return (
    <canvas
      id="wallpaper"
      ref={canvasRef}
      style={{ filter: 'blur(40px) saturate(1.15)', transform: 'scale(1.12)' }}
    />
  );
}

window.Wallpaper = Wallpaper;
