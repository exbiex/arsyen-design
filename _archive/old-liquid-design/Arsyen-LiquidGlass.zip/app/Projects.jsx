// arsyen — Projects view (Liquid Glass)
// Left: glass project list. Right: larger glass project detail with a
// Board / Canvas / Milestones / Files switch. Selecting a project on the
// left swaps the right panel content (no page change).

function ProjectListItem({ p, active, onClick }) {
  return (
    <button onClick={onClick} className={'lift' + (active ? ' is-selected' : '')} style={{
      display: 'flex', gap: 12, alignItems: 'center', textAlign: 'left',
      padding: 12, borderRadius: 'var(--r-md)', width: '100%',
      background: active
        ? 'linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0.02)), rgba(var(--g-tint), 0.34)'
        : 'rgba(255,255,255,0.03)',
      border: active ? '1px solid rgba(255,255,255,0.18)' : '1px solid rgba(255,255,255,0.06)',
      boxShadow: active ? 'inset 0 1px 0 rgba(255,255,255,0.25)' : 'none',
    }}>
      <div className="glass-well" style={{ width: 46, height: 46, flexShrink: 0, padding: 0 }}>
        <ArtFill index={p.artIdx} radius={'calc(var(--r-md) - 4px)'} />
      </div>
      <div className="col" style={{ gap: 5, minWidth: 0, flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--fg-1)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.title}</div>
        <div className="row" style={{ gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: statusColor(p.status) }} />
          <span className="mono-label" style={{ color: statusColor(p.status) }}>{p.status}</span>
        </div>
        <div className="row" style={{ gap: 8, marginTop: 2 }}>
          <Crew ids={p.crew} size={18} />
          <div style={{ flex: 1, height: 4, borderRadius: 99, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
            <div style={{ width: p.progress + '%', height: '100%', background: 'var(--accent)', borderRadius: 99 }} />
          </div>
          <span className="mono-label" style={{ color: 'var(--fg-2)' }}>{p.progress}%</span>
        </div>
      </div>
    </button>
  );
}

function statusColor(s) {
  if (s === 'In production') return 'var(--accent)';
  if (s === 'In review') return 'var(--info)';
  if (s === 'Planning') return 'var(--warn)';
  return 'var(--fg-2)';
}

const PROJ_TABS = ['Board', 'Canvas', 'Milestones', 'Files'];

function BoardColumn({ name, tasks, accent }) {
  return (
    <div className="glass-well panel-in" style={{ flex: 1, minWidth: 0, padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div className="row" style={{ justifyContent: 'space-between', padding: '0 2px 4px' }}>
        <div className="row" style={{ gap: 7 }}>
          <span style={{ width: 7, height: 7, borderRadius: 99, background: accent }} />
          <span className="mono-label" style={{ color: 'var(--fg-2)' }}>{name}</span>
        </div>
        <span className="mono-label">{tasks.length}</span>
      </div>
      {tasks.map((t, i) => (
        <div key={i} className="lift" style={{
          padding: 12, borderRadius: 'var(--r-sm)',
          background: 'linear-gradient(180deg, rgba(255,255,255,0.07), rgba(255,255,255,0.01))',
          border: '1px solid rgba(255,255,255,0.08)',
          boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.12)',
        }}>
          <div style={{ fontSize: 13.5, fontWeight: 500, color: 'var(--fg-1)', marginBottom: 10 }}>{t.t}</div>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="mono-label">{name.slice(0,3).toUpperCase()}-{i+1}</span>
            <Avatar index={t.who} size={20} />
          </div>
        </div>
      ))}
      {tasks.length === 0 && (
        <div style={{ fontSize: 12, color: 'var(--fg-3)', padding: '14px 2px', fontStyle: 'italic' }}>Nothing here yet.</div>
      )}
    </div>
  );
}

function CanvasView({ p }) {
  const allTasks = Object.entries(p.stages).flatMap(([st, ts]) => ts.map(t => ({ ...t, st })));
  return (
    <div className="panel-in glass-well" style={{ padding: 24, borderRadius: 'var(--r-lg)', lineHeight: 1.7 }}>
      <div className="mono-label" style={{ marginBottom: 10 }}>Canvas · live doc</div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 600, color: 'var(--fg-1)', marginBottom: 6 }}>Production notes</div>
      <p style={{ color: 'var(--fg-2)', fontSize: 14.5, maxWidth: 620, margin: '0 0 18px' }}>
        Everything for <b style={{ color: 'var(--fg-1)' }}>{p.title}</b> lives here. Inline tasks below sync straight to the Board — check one and it moves.
      </p>
      <div className="col" style={{ gap: 8, maxWidth: 560 }}>
        {allTasks.slice(0, 6).map((t, i) => (
          <label key={i} className="row" style={{ gap: 11, padding: '9px 12px', borderRadius: 'var(--r-sm)', background: 'rgba(255,255,255,0.04)', cursor: 'pointer' }}>
            <span style={{ width: 17, height: 17, borderRadius: 5, border: '1.5px solid ' + (t.st === 'Done' ? 'var(--accent)' : 'rgba(255,255,255,0.25)'),
              background: t.st === 'Done' ? 'var(--accent)' : 'transparent', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
              {t.st === 'Done' && <Icon name="check" size={12} style={{ color: '#fff' }} strokeWidth={2.5} />}
            </span>
            <span style={{ fontSize: 14, color: t.st === 'Done' ? 'var(--fg-3)' : 'var(--fg-1)', textDecoration: t.st === 'Done' ? 'line-through' : 'none' }}>{t.t}</span>
            <span className="mono-label" style={{ marginLeft: 'auto' }}>{t.st}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

function MilestonesView({ p }) {
  return (
    <div className="panel-in col" style={{ gap: 12, maxWidth: 560 }}>
      {p.milestones.map((m, i) => (
        <div key={i} className="glass-well row" style={{ padding: 16, gap: 14, justifyContent: 'space-between' }}>
          <div className="row" style={{ gap: 14 }}>
            <div style={{ width: 38, height: 38, borderRadius: 12, display: 'grid', placeItems: 'center',
              background: 'rgba(255,85,93,0.12)', border: '1px solid rgba(255,85,93,0.3)' }}>
              <Icon name="star" size={18} style={{ color: 'var(--accent)' }} />
            </div>
            <div className="col" style={{ gap: 3 }}>
              <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--fg-1)' }}>{m.label}</span>
              <span className="mono-label">Upcoming</span>
            </div>
          </div>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 18, fontWeight: 600, color: 'var(--fg-1)' }}>{m.date}</span>
        </div>
      ))}
    </div>
  );
}

function FilesView({ p }) {
  const files = ['Treatment_v4.pdf', 'Grade_LUT.cube', 'Score_main_v3.wav', 'Storyboard.png', 'Contact_sheet.jpg', 'Budget.xlsx'];
  return (
    <div className="panel-in" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 12 }}>
      {files.map((f, i) => (
        <div key={i} className="glass-well lift col" style={{ padding: 16, gap: 12, cursor: 'pointer' }}>
          <Icon name="fileText" size={22} style={{ color: 'var(--fg-2)' }} />
          <span style={{ fontSize: 13, color: 'var(--fg-1)', wordBreak: 'break-word' }}>{f}</span>
        </div>
      ))}
    </div>
  );
}

function ProjectDetail({ p, sub, setSub }) {
  const cols = [
    ['To do', 'var(--fg-2)'], ['In progress', 'var(--accent)'],
    ['Review', 'var(--info)'], ['Done', 'var(--ok)'],
  ];
  return (
    <div className="col" style={{ height: '100%', gap: 18 }}>
      {/* hero banner */}
      <div style={{ position: 'relative', height: 132, borderRadius: 'var(--r-lg)', overflow: 'hidden', flexShrink: 0 }}>
        <ArtFill index={p.artIdx} radius={0} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, rgba(8,8,10,0.78), rgba(8,8,10,0.15) 70%)' }} />
        <div className="col" style={{ position: 'absolute', left: 22, bottom: 18, gap: 8 }}>
          <div className="row" style={{ gap: 7 }}>
            <span style={{ width: 7, height: 7, borderRadius: 99, background: statusColor(p.status) }} />
            <span className="mono-label" style={{ color: statusColor(p.status) }}>{p.status}</span>
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 600, letterSpacing: '-0.02em', color: '#fff', textShadow: '0 2px 20px rgba(0,0,0,0.5)' }}>{p.title}</div>
        </div>
        <div className="row" style={{ position: 'absolute', right: 16, top: 16, gap: 8 }}>
          <button className="glass-chip" style={{ width: 38, height: 38, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center' }}><Icon name="link" size={17} /></button>
          <button className="glass-chip" style={{ width: 38, height: 38, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center' }}><Icon name="more" size={17} /></button>
        </div>
      </div>

      {/* meta row */}
      <div className="row" style={{ gap: 28, padding: '0 4px', flexWrap: 'wrap' }}>
        <Meta label="Your role" value={p.role} />
        <Meta label="Type" value={p.type} />
        <div className="col" style={{ gap: 6 }}><span className="mono-label">Crew</span><Crew ids={p.crew} size={22} /></div>
        <div className="col" style={{ gap: 6, marginLeft: 'auto', minWidth: 180 }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <span className="mono-label">Progress</span>
            <span className="mono-label" style={{ color: 'var(--fg-1)' }}>{p.progress}%</span>
          </div>
          <div style={{ height: 6, borderRadius: 99, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
            <div style={{ width: p.progress + '%', height: '100%', background: 'linear-gradient(90deg, var(--accent), #ff8a5c)', borderRadius: 99 }} />
          </div>
        </div>
      </div>

      {/* segmented switch */}
      <div className="row seg-trough" style={{ gap: 6, padding: 5, alignSelf: 'flex-start', borderRadius: 'var(--r-pill)',
        background: 'rgba(0,0,0,0.25)', border: '1px solid rgba(255,255,255,0.06)' }}>
        {PROJ_TABS.map(t => (
          <button key={t} onClick={() => setSub(t)} className={'glass-chip' + (sub === t ? ' is-active' : '')}
            style={{ padding: '8px 18px', fontSize: 13.5, fontWeight: 600, border: 'none', background: sub === t ? undefined : 'transparent', boxShadow: sub === t ? undefined : 'none' }}>
            {t}
          </button>
        ))}
      </div>

      {/* content */}
      <div style={{ flex: 1, overflow: 'auto', paddingRight: 4, paddingBottom: 4 }}>
        {sub === 'Board' && (
          <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
            {cols.map(([name, accent]) => (
              <BoardColumn key={name} name={name} tasks={p.stages[name] || []} accent={accent} />
            ))}
          </div>
        )}
        {sub === 'Canvas' && <CanvasView p={p} />}
        {sub === 'Milestones' && <MilestonesView p={p} />}
        {sub === 'Files' && <FilesView p={p} />}
      </div>
    </div>
  );
}

function Meta({ label, value }) {
  return (
    <div className="col" style={{ gap: 5 }}>
      <span className="mono-label">{label}</span>
      <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--fg-1)' }}>{value}</span>
    </div>
  );
}

function ProjectsView() {
  const projects = window.WEB_PROJECTS.map((p, i) => ({ ...p, artIdx: i }));
  const [selId, setSel] = React.useState(projects[0].id);
  const [sub, setSub] = React.useState('Board');
  const sel = projects.find(p => p.id === selId);
  return (
    <div className="row view-enter" style={{ gap: 20, height: '100%', alignItems: 'stretch' }}>
      {/* left list */}
      <div className="glass" style={{ width: 340, flexShrink: 0, padding: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div className="col" style={{ gap: 2 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 21, fontWeight: 600, color: 'var(--fg-1)' }}>Projects</span>
            <span className="mono-label">{projects.length} active</span>
          </div>
          <button className="glass-chip" style={{ width: 36, height: 36, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center' }}>
            <Icon name="plus" size={18} style={{ color: 'var(--accent)' }} />
          </button>
        </div>
        <div className="col" style={{ gap: 10, overflow: 'auto', marginRight: -6, paddingRight: 6 }}>
          {projects.map(p => (
            <ProjectListItem key={p.id} p={p} active={p.id === selId} onClick={() => { setSel(p.id); }} />
          ))}
        </div>
      </div>
      {/* right detail */}
      <div className="glass" key={selId} style={{ flex: 1, minWidth: 0, padding: 22 }}>
        <ProjectDetail p={sel} sub={sub} setSub={setSub} />
      </div>
    </div>
  );
}

window.ProjectsView = ProjectsView;
