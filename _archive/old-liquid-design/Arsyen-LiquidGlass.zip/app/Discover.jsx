// arsyen — Discover view (Liquid Glass)
// Left: glass search + filters + portrait artist cards. Right: glass chat rail.

function ArtistCard({ a, featured }) {
  return (
    <div className="glass lift r-md" style={{ padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div style={{ position: 'relative', height: featured ? 200 : 150 }}>
        <ArtFill index={a.artIdx} radius={0} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(transparent 42%, rgba(8,8,10,0.82))' }} />
        <span className="glass-chip" style={{ position: 'absolute', top: 12, right: 12, padding: '4px 10px', fontSize: 11, fontWeight: 700,
          color: 'var(--accent)', fontFamily: 'var(--font-mono)' }}>{a.match}% match</span>
        <div className="row" style={{ position: 'absolute', left: 14, bottom: 12, gap: 10 }}>
          <Avatar index={a.avatar} size={40} ring online={a.open} />
          <div className="col" style={{ gap: 3 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>{a.name}</span>
            <span className="mono-label" style={{ color: 'rgba(255,255,255,0.7)' }}>{a.discipline} · {a.city}</span>
          </div>
        </div>
      </div>
      <div className="col" style={{ padding: 14, gap: 12 }}>
        <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
          {a.skills.map(s => (
            <span key={s} className="glass-chip" style={{ padding: '5px 11px', fontSize: 12 }}>{s}</span>
          ))}
        </div>
        <div className="row" style={{ gap: 8 }}>
          <button className="glass-coral row" style={{ flex: 1, justifyContent: 'center', gap: 8, padding: '11px 0', fontWeight: 600, fontSize: 14 }}>
            <Icon name="chat" size={16} /> Message
          </button>
          <button className="glass-chip" style={{ width: 44, height: 44, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center' }}>
            <Icon name="user" size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatRow({ c }) {
  return (
    <button className="row lift" style={{ gap: 12, padding: '11px 12px', borderRadius: 'var(--r-md)', textAlign: 'left', width: '100%',
      background: 'rgba(255,255,255,0.03)' }}>
      <Avatar index={c.avatar} size={42} online={c.online} />
      <div className="col" style={{ gap: 3, minWidth: 0, flex: 1 }}>
        <div className="row" style={{ justifyContent: 'space-between', gap: 8 }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--fg-1)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</span>
          <span className="mono-label" style={{ flexShrink: 0 }}>{c.when}</span>
        </div>
        <span style={{ fontSize: 13, color: 'var(--fg-2)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.last}</span>
      </div>
      {c.unread > 0 && <span style={{ width: 8, height: 8, borderRadius: 99, background: 'var(--accent)', flexShrink: 0 }} />}
    </button>
  );
}

function DiscoverView() {
  const artists = window.WEB_ARTISTS.map((a, i) => ({ ...a, artIdx: (i + 2) % 8 }));
  const chats = window.WEB_CHATS;
  const [chatTab, setChatTab] = React.useState('Direct');
  const communities = window.WEB_COMMUNITIES;
  const [activeFilter, setActiveFilter] = React.useState('Open to crew');

  return (
    <div className="row view-enter" style={{ gap: 20, height: '100%', alignItems: 'stretch' }}>
      {/* main */}
      <div className="glass" style={{ flex: 1, minWidth: 0, padding: 22, display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* search */}
        <div className="glass-well row" style={{ padding: '4px 6px 4px 16px', gap: 12, borderRadius: 'var(--r-pill)' }}>
          <Icon name="search" size={19} style={{ color: 'var(--fg-3)' }} />
          <input placeholder="Search artists, disciplines, skills…" style={{
            flex: 1, background: 'none', border: 'none', outline: 'none', color: 'var(--fg-1)', fontSize: 15, padding: '12px 0' }} />
          <button className="glass-chip row" style={{ gap: 7, padding: '9px 14px', fontSize: 12.5 }}>
            <Icon name="sliders" size={15} /> Filters
          </button>
        </div>
        {/* filter chips */}
        <div className="row" style={{ gap: 9, flexWrap: 'wrap' }}>
          {window.DISCOVER_FILTERS.map(f => (
            <button key={f} onClick={() => setActiveFilter(f)} className={'glass-chip' + (activeFilter === f ? ' is-active' : '')}
              style={{ padding: '8px 15px', fontSize: 13 }}>{f}</button>
          ))}
        </div>

        <div className="col" style={{ gap: 16, overflow: 'auto', marginRight: -6, paddingRight: 6 }}>
          <div className="row" style={{ gap: 8 }}>
            <Icon name="star" size={14} style={{ color: 'var(--accent)' }} fill />
            <span className="mono-label" style={{ color: 'var(--fg-2)' }}>Featured artists</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
            {artists.slice(0, 2).map(a => <ArtistCard key={a.id} a={a} featured />)}
          </div>
          <div className="row" style={{ gap: 8, marginTop: 4 }}>
            <Icon name="compass" size={14} style={{ color: 'var(--fg-2)' }} />
            <span className="mono-label" style={{ color: 'var(--fg-2)' }}>Most relevant for your crew</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {artists.slice(2, 5).map(a => <ArtistCard key={a.id} a={a} />)}
          </div>
        </div>
      </div>

      {/* chat rail */}
      <div className="glass" style={{ width: 320, flexShrink: 0, padding: 18, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div className="row" style={{ gap: 9 }}>
            <Icon name="chat" size={18} style={{ color: 'var(--accent)' }} />
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 600, color: 'var(--fg-1)' }}>Chat</span>
          </div>
          <button className="glass-chip" style={{ width: 34, height: 34, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center' }}>
            <Icon name="plus" size={16} />
          </button>
        </div>
        <div className="row seg-trough" style={{ gap: 6, padding: 5, borderRadius: 'var(--r-pill)', background: 'rgba(0,0,0,0.25)', border: '1px solid rgba(255,255,255,0.06)' }}>
          {['Direct', 'Community'].map(t => (
            <button key={t} onClick={() => setChatTab(t)} className={'glass-chip' + (chatTab === t ? ' is-active' : '')}
              style={{ flex: 1, padding: '8px 0', fontSize: 13, fontWeight: 600, background: chatTab === t ? undefined : 'transparent', boxShadow: chatTab === t ? undefined : 'none' }}>{t}</button>
          ))}
        </div>
        <div className="col" style={{ gap: 4, overflow: 'auto', marginRight: -6, paddingRight: 6 }}>
          {(chatTab === 'Direct' ? chats : communities).map(c => <ChatRow key={c.id} c={c} />)}
        </div>
      </div>
    </div>
  );
}

window.DiscoverView = DiscoverView;
