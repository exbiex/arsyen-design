// arsyen — Profile / Settings view (Liquid Glass)
// Left: glass profile card. Right: glass settings with toggles & rows.

function Toggle({ on, onClick }) {
  return (
    <button onClick={onClick} className="emb-toggle" style={{
      width: 46, height: 27, borderRadius: 'var(--r-pill)', padding: 3, flexShrink: 0,
      background: on ? 'var(--accent)' : 'rgba(255,255,255,0.12)',
      boxShadow: on ? '0 0 16px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,0.3)' : 'inset 0 1px 3px rgba(0,0,0,0.4)',
      transition: 'background var(--dur) var(--ease-out)', display: 'flex',
      justifyContent: on ? 'flex-end' : 'flex-start',
    }}>
      <span className="emb-knob" style={{ width: 21, height: 21, borderRadius: 99, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.4)', transition: 'all var(--dur) var(--ease-out)' }} />
    </button>
  );
}

function SettingRow({ icon, label, sub, children }) {
  return (
    <div className="row" style={{ gap: 14, padding: '14px 4px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
      <div style={{ width: 36, height: 36, borderRadius: 'var(--r-md)', display: 'grid', placeItems: 'center', flexShrink: 0,
        background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
        <Icon name={icon} size={18} style={{ color: 'var(--fg-2)' }} />
      </div>
      <div className="col" style={{ gap: 2, flex: 1, minWidth: 0 }}>
        <span style={{ fontSize: 14.5, fontWeight: 600, color: 'var(--fg-1)' }}>{label}</span>
        {sub && <span style={{ fontSize: 12.5, color: 'var(--fg-3)' }}>{sub}</span>}
      </div>
      {children}
    </div>
  );
}

/* ---- in-product Appearance controls ---- */
function Seg({ value, options, onChange, accentLed }) {
  return (
    <div className="ap-seg">
      {options.map(o => (
        <button key={o} className={(value === o ? 'on' : '') + (accentLed && value === o ? ' accentled' : '')} onClick={() => onChange(o)}>{o}</button>
      ))}
    </div>
  );
}

function Swatches({ options, value, onChange }) {
  return (
    <div className="ap-swatches">
      {options.map(o => (
        <button key={o.name} className={'ap-swatch' + (value === o.name ? ' on' : '')}
          onClick={() => onChange(o.name)} title={o.name}
          style={{ background: o.hex, color: o.hex }} />
      ))}
    </div>
  );
}

function ApRow({ icon, label, value, children }) {
  return (
    <div className="row" style={{ gap: 14, padding: '13px 4px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
      <div style={{ width: 36, height: 36, borderRadius: 'var(--r-md)', display: 'grid', placeItems: 'center', flexShrink: 0,
        background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
        <Icon name={icon} size={18} style={{ color: 'var(--fg-2)' }} />
      </div>
      <div className="col" style={{ gap: 9, flex: 1, minWidth: 0 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <span style={{ fontSize: 14.5, fontWeight: 600, color: 'var(--fg-1)' }}>{label}</span>
          {value != null && <span className="mono-label" style={{ color: 'var(--fg-2)' }}>{value}</span>}
        </div>
        {children}
      </div>
    </div>
  );
}

function ApSlider({ value, min, max, onChange }) {
  const fill = ((value - min) / (max - min)) * 100;
  return (
    <input type="range" className="ap-range" min={min} max={max} value={value}
      style={{ '--fill': fill + '%' }}
      onChange={e => onChange(parseInt(e.target.value, 10))} />
  );
}

function ProfileView({ ap = {}, setTweak = () => {}, accentOptions = [] }) {
  const me = window.WEB_ME;
  const [toggles, setToggles] = React.useState({ commissions: true, mentions: true, crew: false, public: true });
  const flip = k => setToggles(t => ({ ...t, [k]: !t[k] }));
  const living = ap.backdrop === 'Living';

  return (
    <div className="row view-enter" style={{ gap: 20, height: '100%', alignItems: 'stretch' }}>
      {/* profile card */}
      <div className="glass" style={{ width: 360, flexShrink: 0, padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ position: 'relative', height: 130, flexShrink: 0 }}>
          <ArtFill index={me.art} radius={0} />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(transparent 30%, rgba(8,8,10,0.85))' }} />
        </div>
        <div className="col" style={{ padding: '0 22px 22px', marginTop: -42, gap: 14, overflow: 'auto' }}>
          <div style={{ alignSelf: 'flex-start' }}>
            <Avatar index={me.avatar} size={84} ring online />
          </div>
          <div className="col" style={{ gap: 4 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 25, fontWeight: 600, color: 'var(--fg-1)' }}>{me.name}</span>
            <span className="mono-label" style={{ color: 'var(--fg-2)' }}>{me.discipline}</span>
            <span className="row" style={{ gap: 6, marginTop: 4, fontSize: 13, color: 'var(--fg-3)' }}>
              <Icon name="pin" size={14} /> {me.city}
            </span>
          </div>
          <p style={{ fontSize: 14, color: 'var(--fg-2)', lineHeight: 1.55, margin: 0 }}>{me.bio}</p>
          {/* stats */}
          <div className="glass-well row" style={{ padding: '14px 8px', justifyContent: 'space-around' }}>
            {me.stats.map(s => (
              <div key={s.label} className="col" style={{ alignItems: 'center', gap: 3 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 21, fontWeight: 700, color: 'var(--fg-1)' }}>{s.value}</span>
                <span className="mono-label">{s.label}</span>
              </div>
            ))}
          </div>
          <div className="row" style={{ gap: 7, flexWrap: 'wrap' }}>
            {me.skills.map(s => <span key={s} className="glass-chip" style={{ padding: '6px 12px', fontSize: 12.5 }}>{s}</span>)}
          </div>
          <div className="row" style={{ gap: 8 }}>
            <button className="glass-coral" style={{ flex: 1, padding: '12px 0', fontWeight: 600, fontSize: 14 }}>Edit profile</button>
            <button className="glass-chip" style={{ width: 46, height: 46, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center' }}>
              <Icon name="share" size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* settings */}
      <div className="glass" style={{ flex: 1, minWidth: 0, padding: 24, display: 'flex', flexDirection: 'column', gap: 6, overflow: 'auto' }}>
        <div className="col" style={{ gap: 3, marginBottom: 12 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 600, color: 'var(--fg-1)' }}>Settings</span>
          <span style={{ fontSize: 13.5, color: 'var(--fg-3)' }}>Tune your studio, the way you like it.</span>
        </div>

        <span className="mono-label" style={{ marginTop: 10, marginBottom: 4 }}>Notifications</span>
        <SettingRow icon="briefcase" label="Commission requests" sub="When someone wants to commission you">
          <Toggle on={toggles.commissions} onClick={() => flip('commissions')} />
        </SettingRow>
        <SettingRow icon="comment" label="Mentions & replies" sub="On your work and in threads">
          <Toggle on={toggles.mentions} onClick={() => flip('mentions')} />
        </SettingRow>
        <SettingRow icon="users" label="Crew activity" sub="Updates from your active crews">
          <Toggle on={toggles.crew} onClick={() => flip('crew')} />
        </SettingRow>

        <span className="mono-label" style={{ marginTop: 18, marginBottom: 4 }}>Privacy</span>
        <SettingRow icon="eye" label="Public portfolio" sub="Anyone can view your published work">
          <Toggle on={toggles.public} onClick={() => flip('public')} />
        </SettingRow>
        <SettingRow icon="lock" label="Commissions" sub="Open to commission requests">
          <span className="glass-chip is-active" style={{ padding: '7px 14px', fontSize: 12.5, color: 'var(--accent)' }}>Open</span>
        </SettingRow>

        <div className="row" style={{ justifyContent: 'space-between', marginTop: 18, marginBottom: 4 }}>
          <span className="mono-label">Appearance</span>
          <span className="mono-label" style={{ color: 'var(--fg-2)' }}>{living ? 'Living · ' + (ap.accent || 'Coral') : 'Pure black'}</span>
        </div>

        {/* backdrop mode */}
        <ApRow icon="image" label="Backdrop">
          <Seg value={living ? 'Living' : 'Pure black'} options={['Pure black', 'Living']} accentLed
            onChange={v => setTweak('backdrop', v)} />
        </ApRow>

        {/* living wallpaper customisation */}
        <div className={'ap-group' + (living ? '' : ' is-off')} style={{ display: 'flex', flexDirection: 'column' }}>
          <ApRow icon="palette" label="Accent color">
            <Swatches options={accentOptions} value={ap.accent} onChange={v => setTweak('accent', v)} />
          </ApRow>
          <ApRow icon="star" label="Glow" value={ap.glow + '%'}>
            <ApSlider value={ap.glow} min={40} max={160} onChange={v => setTweak('glow', v)} />
          </ApRow>
          <ApRow icon="compass" label="Motion speed" value={ap.motion + '%'}>
            <ApSlider value={ap.motion} min={0} max={220} onChange={v => setTweak('motion', v)} />
          </ApRow>
          <ApRow icon="pin" label="Cursor reactivity" value={ap.reactivity + '%'}>
            <ApSlider value={ap.reactivity} min={0} max={240} onChange={v => setTweak('reactivity', v)} />
          </ApRow>
        </div>

        {/* shape applies in any mode */}
        <ApRow icon="grid" label="Shape" >
          <Seg value={ap.corners} options={['Square', 'Soft', 'Round']} onChange={v => setTweak('corners', v)} />
        </ApRow>

        <button className="row" style={{ gap: 10, marginTop: 22, padding: '13px 16px', borderRadius: 'var(--r-md)', alignSelf: 'flex-start',
          background: 'rgba(255,85,93,0.10)', border: '1px solid rgba(255,85,93,0.28)', color: 'var(--accent)', fontWeight: 600, fontSize: 14 }}>
          <Icon name="logout" size={17} /> Sign out
        </button>
      </div>
    </div>
  );
}

window.ProfileView = ProfileView;
