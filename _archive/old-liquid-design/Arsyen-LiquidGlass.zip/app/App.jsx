// arsyen — Liquid Glass shell. One wallpaper, swapping glass views.

const NAV = [
  { id: 'projects', icon: 'folder',   label: 'Projects' },
  { id: 'discover', icon: 'compass',  label: 'Discover' },
  { id: 'profile',  icon: 'settings', label: 'Studio' },
];

const ACCENTS = {
  Coral:  ['#FF555D', 'rgba(255,85,93,0.45)'],
  Violet: ['#9B6BFF', 'rgba(155,107,255,0.45)'],
  Azure:  ['#4F9BFF', 'rgba(79,155,255,0.45)'],
  Amber:  ['#F5A742', 'rgba(245,167,66,0.42)'],
};

// corner presets — [sm, md, lg, xl, pill]
const CORNERS = {
  Square: [4, 6, 8, 9, 9],
  Soft:   [8, 13, 18, 22, 22],
  Round:  [10, 16, 22, 30, 999],
};

const ACCENT_LIST = Object.entries(ACCENTS).map(([name, a]) => ({ name, hex: a[0] }));
function hexToRgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "surface": "Glass",
  "backdrop": "Pure black",
  "corners": "Square",
  "blur": 26,
  "translucency": 7,
  "glow": 100,
  "motion": 100,
  "reactivity": 100,
  "accent": "Coral"
}/*EDITMODE-END*/;

function TopBar({ tab, setTab }) {
  return (
    <div className="row" style={{ justifyContent: 'space-between', padding: '0 6px', flexShrink: 0 }}>
      <div className="row" style={{ gap: 12 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 23, fontWeight: 600, letterSpacing: '-0.03em', color: 'var(--fg-1)' }}>arsyen</span>
      </div>
      <div className="row" style={{ gap: 12 }}>
        <div className="glass-chip row" style={{ gap: 10, padding: '9px 14px 9px 16px', minWidth: 230 }}>
          <Icon name="search" size={16} style={{ color: 'var(--fg-3)' }} />
          <span style={{ flex: 1, fontSize: 13.5, color: 'var(--fg-3)' }}>Quick search…</span>
          <span className="mono-label" style={{ padding: '2px 6px', borderRadius: 6, background: 'rgba(255,255,255,0.07)' }}>⌘K</span>
        </div>
        <button className="glass-chip" style={{ width: 42, height: 42, borderRadius: 'var(--r-pill)', display: 'grid', placeItems: 'center', position: 'relative' }}>
          <Icon name="bell" size={19} />
          <span style={{ position: 'absolute', top: 9, right: 10, width: 7, height: 7, borderRadius: 99, background: 'var(--accent)', boxShadow: '0 0 8px var(--accent-glow)' }} />
        </button>
        <button onClick={() => setTab('profile')} style={{ borderRadius: '50%', boxShadow: tab === 'profile' ? '0 0 0 2px var(--accent)' : 'none' }}>
          <Avatar index={3} size={42} ring online />
        </button>
      </div>
    </div>
  );
}

function TabBar({ tab, setTab }) {
  return (
    <div className="row panel-in" style={{ justifyContent: 'center', flexShrink: 0, pointerEvents: 'none' }}>
      <div className="glass r-pill row" style={{ gap: 6, padding: 7, pointerEvents: 'auto' }}>
        {NAV.map(n => {
          const active = tab === n.id;
          return (
            <button key={n.id} onClick={() => setTab(n.id)} className="row"
              style={{
                gap: 9, padding: active ? '11px 20px 11px 16px' : '11px', borderRadius: 'var(--r-pill)',
                background: active ? 'linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0.02)), color-mix(in srgb, var(--accent) 30%, transparent)' : 'transparent',
                border: active ? '1px solid color-mix(in srgb, var(--accent) 45%, transparent)' : '1px solid transparent',
                boxShadow: active ? '0 4px 16px var(--accent-glow), inset 0 1px 0 rgba(255,255,255,0.25)' : 'none',
                color: active ? '#fff' : 'var(--fg-2)',
                transition: 'all var(--dur) var(--ease-out)',
              }}>
              <Icon name={n.icon} size={21} fill={active && n.icon !== 'settings'} style={{ color: active ? 'var(--accent)' : 'var(--fg-2)' }} />
              {active && <span style={{ fontSize: 14, fontWeight: 600 }}>{n.label}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = React.useState('projects');

  // push tweak values into CSS custom properties
  React.useEffect(() => {
    const r = document.documentElement.style;
    r.setProperty('--g-blur', t.blur + 'px');
    r.setProperty('--g-alpha', (t.translucency / 100).toFixed(3));
    const [c, glow] = ACCENTS[t.accent] || ACCENTS.Coral;
    r.setProperty('--accent', c);
    r.setProperty('--accent-glow', glow);
    const cz = CORNERS[t.corners] || CORNERS.Square;
    ['--r-sm', '--r-md', '--r-lg', '--r-xl', '--r-pill'].forEach((v, i) => r.setProperty(v, cz[i] + 'px'));
    document.documentElement.setAttribute('data-surface', t.surface === 'Embossed' ? 'emboss' : 'glass');
  }, [t.blur, t.translucency, t.accent, t.corners, t.surface]);

  const View = { projects: ProjectsView, discover: DiscoverView, profile: ProfileView }[tab];
  const accentRgb = hexToRgb((ACCENTS[t.accent] || ACCENTS.Coral)[0]);

  return (
    <React.Fragment>
      <Wallpaper tab={tab} glow={t.glow / 100} motion={t.motion / 100} reactivity={t.reactivity / 100} black={t.backdrop === 'Pure black'} emboss={t.surface === 'Embossed'} accentRgb={accentRgb} />
      <div id="wallpaper-veil"></div>
      <div id="app-layer" style={{ display: 'flex', flexDirection: 'column', gap: 18, padding: '20px 26px 24px' }}>
        <TopBar tab={tab} setTab={setTab} />
        <div key={tab} style={{ flex: 1, minHeight: 0 }}>
          {tab === 'profile'
            ? <ProfileView ap={t} setTweak={setTweak} accentOptions={ACCENT_LIST} />
            : <View />}
        </div>
        <TabBar tab={tab} setTab={setTab} />
      </div>

      <TweaksPanel>
        <TweakSection label="Surface" />
        <TweakRadio label="Material" value={t.surface} options={['Glass', 'Embossed']} onChange={v => setTweak('surface', v)} />
        <TweakSection label="Backdrop" />
        <TweakRadio label="Mode" value={t.backdrop} options={['Living', 'Pure black']} onChange={v => setTweak('backdrop', v)} />
        <TweakSection label="Shape" />
        <TweakRadio label="Corners" value={t.corners} options={['Square', 'Soft', 'Round']} onChange={v => setTweak('corners', v)} />
        <TweakSection label="Glass" />
        <TweakSlider label="Blur" value={t.blur} min={6} max={60} unit="px" onChange={v => setTweak('blur', v)} />
        <TweakSlider label="Translucency" value={t.translucency} min={4} max={70} unit="%" onChange={v => setTweak('translucency', v)} />
        <TweakColor label="Accent" value={t.accent ? ACCENTS[t.accent][0] : '#FF555D'}
          options={Object.values(ACCENTS).map(a => a[0])}
          onChange={hex => { const name = Object.keys(ACCENTS).find(k => ACCENTS[k][0] === hex); if (name) setTweak('accent', name); }} />
        <TweakSection label="Wallpaper" />
        <TweakSlider label="Glow" value={t.glow} min={40} max={160} unit="%" onChange={v => setTweak('glow', v)} />
        <TweakSlider label="Motion speed" value={t.motion} min={0} max={220} unit="%" onChange={v => setTweak('motion', v)} />
        <TweakSlider label="Cursor reactivity" value={t.reactivity} min={0} max={240} unit="%" onChange={v => setTweak('reactivity', v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
