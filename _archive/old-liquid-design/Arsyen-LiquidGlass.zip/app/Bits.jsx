// arsyen — shared visual bits for the Liquid Glass shell.
// Artwork gradients + avatars copied from the design system so the
// generative "art" colour stays true to the brand world.

const ART_PALETTES = [
  'radial-gradient(120% 100% at 20% 15%, #ff8a5c 0%, transparent 55%), radial-gradient(120% 100% at 80% 85%, #6b5bff 0%, transparent 55%), #241c2e',
  'radial-gradient(120% 100% at 70% 20%, #2e8f73 0%, transparent 60%), radial-gradient(100% 100% at 20% 90%, #d9b24a 0%, transparent 55%), #1a221c',
  'radial-gradient(120% 100% at 30% 25%, #ff5d7a 0%, transparent 55%), radial-gradient(120% 100% at 85% 80%, #4a2f6e 0%, transparent 60%), #221525',
  'radial-gradient(120% 120% at 50% 0%, #5b8dff 0%, transparent 55%), radial-gradient(100% 100% at 80% 100%, #1a2440 0%, transparent 60%), #11151f',
  'radial-gradient(120% 100% at 15% 20%, #e8e3d6 0%, transparent 50%), radial-gradient(120% 100% at 80% 90%, #8a8577 0%, transparent 55%), #2a2823',
  'radial-gradient(120% 120% at 60% 15%, #ff7847 0%, transparent 50%), radial-gradient(110% 100% at 20% 95%, #7a1f1f 0%, transparent 55%), #1f1311',
  'radial-gradient(120% 100% at 40% 20%, #b07cff 0%, transparent 55%), radial-gradient(120% 100% at 85% 85%, #2a6f8f 0%, transparent 55%), #18121f',
  'radial-gradient(130% 110% at 50% 10%, #3a3d42 0%, transparent 60%), radial-gradient(90% 90% at 70% 90%, #0e0f11 0%, transparent 60%), #161719',
];

const AVATAR_GRADS = [
  'linear-gradient(135deg,#3a3d42,#26282b)',
  'linear-gradient(135deg,#5a3d4a,#2a1c22)',
  'linear-gradient(135deg,#3d4a5a,#1c2230)',
  'linear-gradient(135deg,#4a4a3d,#26261c)',
];

function ArtFill({ index = 0, radius = 0, style = {}, children, className = '' }) {
  return (
    <div className={className} style={{
      width: '100%', height: '100%',
      background: ART_PALETTES[index % ART_PALETTES.length],
      borderRadius: radius, overflow: 'hidden', position: 'relative', ...style,
    }}>{children}</div>
  );
}

function Avatar({ index = 0, size = 32, ring = false, online = false }) {
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: AVATAR_GRADS[index % AVATAR_GRADS.length],
        boxShadow: ring
          ? '0 0 0 2px rgba(255,255,255,0.18), inset 0 1px 0 rgba(255,255,255,0.12)'
          : 'inset 0 1px 0 rgba(255,255,255,0.12)',
      }} />
      {online && (
        <span style={{
          position: 'absolute', right: -1, bottom: -1, width: size * 0.28, height: size * 0.28,
          minWidth: 8, minHeight: 8, borderRadius: '50%', background: 'var(--ok)',
          boxShadow: '0 0 0 2px rgba(10,11,13,0.7)',
        }} />
      )}
    </div>
  );
}

// little stacked-avatar crew row
function Crew({ ids = [], size = 22 }) {
  return (
    <div className="row" style={{ paddingLeft: size * 0.32 }}>
      {ids.map((id, i) => (
        <div key={i} style={{ marginLeft: -size * 0.32, position: 'relative', zIndex: ids.length - i }}>
          <Avatar index={id} size={size} ring />
        </div>
      ))}
    </div>
  );
}

window.ART_PALETTES = ART_PALETTES;
window.ArtFill = ArtFill;
window.Avatar = Avatar;
window.Crew = Crew;
