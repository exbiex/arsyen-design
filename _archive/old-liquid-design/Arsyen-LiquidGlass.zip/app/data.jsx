// arsyen web app — sample data: projects, artists, feed, chat

const WEB_PROJECTS = [
  {
    id: 'p1', title: 'Nightwork — short film', type: 'Short film', art: 2,
    status: 'In production', progress: 64, role: 'Director', crew: [3, 1, 2, 0],
    updated: '2h ago',
    stages: {
      'To do':        [{ t: 'Lock color grade', who: 0 }, { t: 'Sound design pass 2', who: 2 }],
      'In progress':  [{ t: 'Edit reel 03', who: 1 }, { t: 'Score — main theme', who: 3 }],
      'Review':       [{ t: 'Poster comp', who: 0 }],
      'Done':         [{ t: 'Storyboard', who: 1 }, { t: 'Location scout', who: 2 }],
    },
    milestones: [
      { label: 'Picture lock', date: 'Jun 18', done: false },
      { label: 'Final mix', date: 'Jun 30', done: false },
      { label: 'Festival cut', date: 'Jul 12', done: false },
    ],
  },
  {
    id: 'p2', title: 'Paper Sun — album art', type: 'Album', art: 5,
    status: 'In review', progress: 82, role: 'Art director', crew: [0, 2],
    updated: '5h ago',
    stages: {
      'To do':        [{ t: 'Vinyl sleeve dielines', who: 2 }],
      'In progress':  [{ t: 'Cover plate retouch', who: 0 }],
      'Review':       [{ t: 'Tracklist typography', who: 0 }, { t: 'Back cover', who: 2 }],
      'Done':         [{ t: 'Moodboard', who: 0 }, { t: 'Photo session', who: 2 }],
    },
    milestones: [
      { label: 'Client sign-off', date: 'Jun 14', done: false },
      { label: 'Print handoff', date: 'Jun 20', done: false },
    ],
  },
  {
    id: 'p3', title: 'Static Garden — exhibition', type: 'Exhibition', art: 6,
    status: 'Planning', progress: 28, role: 'Curator', crew: [1, 3, 0],
    updated: '1d ago',
    stages: {
      'To do':        [{ t: 'Wall text drafts', who: 1 }, { t: 'Lighting plan', who: 3 }, { t: 'Invite list', who: 0 }],
      'In progress':  [{ t: 'Floor layout', who: 1 }],
      'Review':       [],
      'Done':         [{ t: 'Venue booked', who: 0 }],
    },
    milestones: [
      { label: 'Install', date: 'Aug 02', done: false },
      { label: 'Opening night', date: 'Aug 09', done: false },
    ],
  },
  {
    id: 'p4', title: 'Field Study — photo zine', type: 'Print', art: 4,
    status: 'In production', progress: 47, role: 'Editor', crew: [2, 0],
    updated: '2d ago',
    stages: {
      'To do':        [{ t: 'Sequence edit', who: 2 }, { t: 'Paper stock test', who: 0 }],
      'In progress':  [{ t: 'Scan negatives', who: 2 }],
      'Review':       [{ t: 'Cover crop', who: 0 }],
      'Done':         [{ t: 'Concept', who: 2 }],
    },
    milestones: [{ label: 'Proof copy', date: 'Jun 25', done: false }],
  },
];

// Artists to discover / form a crew
const WEB_ARTISTS = [
  { id: 'u0', name: 'Nadia Œ',   handle: '@nadia.oe',   avatar: 0, art: 4, discipline: 'Photographer', city: 'Lisbon',  open: true,  skills: ['Analog', 'Editorial', 'Print'],  rate: '$$', match: 96 },
  { id: 'u1', name: 'Mara Vey',  handle: '@maravey',    avatar: 1, art: 2, discipline: 'Painter',      city: 'Oslo',    open: true,  skills: ['Oil', 'Portrait', 'Set design'], rate: '$$$', match: 93 },
  { id: 'u2', name: 'Ilo Bran',  handle: '@ilobran',    avatar: 2, art: 1, discipline: 'Photographer', city: 'Berlin',  open: false, skills: ['Documentary', '16mm'],          rate: '$$', match: 88 },
  { id: 'u3', name: 'Søren K.',  handle: '@sorenk',     avatar: 3, art: 3, discipline: '3D / Motion',   city: 'Copenhagen', open: true, skills: ['Houdini', 'Score', 'Title design'], rate: '$$$', match: 84 },
  { id: 'u4', name: 'Lena Asgard', handle: '@lasgard',  avatar: 1, art: 6, discipline: 'Composer',     city: 'Reykjavík', open: true, skills: ['Ambient', 'Strings', 'Mix'],   rate: '$$', match: 80 },
  { id: 'u5', name: 'Studio Æon', handle: '@studio.aeon', avatar: 2, art: 7, discipline: 'Design studio', city: 'Amsterdam', open: false, skills: ['Branding', 'Editorial'],     rate: '$$$$', match: 77 },
];

const DISCOVER_FILTERS = ['Discipline', 'Location', 'Open to crew', 'Skills', 'Rate'];

// Feed — media-only pins (image/video). Click opens detail with comments/threads.
const WEB_FEED = [
  { id: 'f1', kind: 'image', art: 2, h: 280, by: 'Mara Vey',   avatar: 1, title: 'Nightwork no. 4', up: 214, comments: 18, tag: 'Painting' },
  { id: 'f2', kind: 'video', art: 3, h: 200, by: 'Søren K.',   avatar: 3, title: 'Transmission — title test', up: 96, comments: 41, tag: '3D' },
  { id: 'f3', kind: 'image', art: 6, h: 320, by: 'Mara Vey',   avatar: 1, title: 'Static garden', up: 332, comments: 27, tag: '3D' },
  { id: 'f4', kind: 'image', art: 1, h: 240, by: 'Ilo Bran',   avatar: 2, title: 'Field study', up: 178, comments: 12, tag: 'Photo' },
  { id: 'f5', kind: 'image', art: 4, h: 300, by: 'Nadia Œ',    avatar: 0, title: 'Dusk, again', up: 153, comments: 22, tag: 'Photo' },
  { id: 'f6', kind: 'image', art: 5, h: 220, by: 'Nadia Œ',    avatar: 0, title: 'Paper sun', up: 287, comments: 31, tag: 'Mixed' },
  { id: 'f7', kind: 'video', art: 7, h: 260, by: 'Søren K.',   avatar: 3, title: 'Plate motion study', up: 401, comments: 44, tag: '3D' },
  { id: 'f8', kind: 'image', art: 0, h: 200, by: 'Studio Æon', avatar: 2, title: 'Untitled (plate)', up: 119, comments: 8, tag: 'Print' },
];

const WEB_CHATS = [
  { id: 'ch1', name: 'Nightwork crew', who: 'group', avatar: 3, last: 'Søren: score draft is up 🎧', when: '2m', unread: 2, online: true },
  { id: 'ch2', name: 'Nadia Œ', who: 'dm', avatar: 0, last: 'sent the contact sheet', when: '18m', unread: 0, online: true },
  { id: 'ch3', name: 'Studio Æon', who: 'dm', avatar: 2, last: 'Let\u2019s lock the sleeve dielines', when: '1h', unread: 0, online: false },
  { id: 'ch4', name: 'Mara Vey', who: 'dm', avatar: 1, last: 'love it. ship it.', when: '3h', unread: 0, online: false },
];

// Tools — embossed square tiles, each opens a full-screen tool page
const WEB_TOOLS = [
  { id: 't1', icon: 'palette',   name: 'Moodboard',     sub: 'Collect references into a board', tag: 'Visual' },
  { id: 't2', icon: 'image',     name: 'Color grade',   sub: 'Build & save LUT-style palettes', tag: 'Visual' },
  { id: 't3', icon: 'fileText',  name: 'Brief builder', sub: 'Turn a chat into a creative brief', tag: 'Docs' },
  { id: 't4', icon: 'briefcase', name: 'Invoice',       sub: 'Bill a commission, get paid', tag: 'Business' },
  { id: 't5', icon: 'users',     name: 'Call sheet',    sub: 'Schedule a shoot with your crew', tag: 'Production' },
  { id: 't6', icon: 'grid',      name: 'Storyboard',    sub: 'Frame out a sequence', tag: 'Production' },
  { id: 't7', icon: 'star',      name: 'Portfolio',     sub: 'Compose a gallery-grade set', tag: 'Profile' },
  { id: 't8', icon: 'send',      name: 'Contract',      sub: 'Scope, terms, signatures', tag: 'Business' },
];

// Comments / threads on a feed post
const WEB_COMMENTS = [
  { id: 'cm1', by: 'Søren K.', avatar: 3, when: '4h', up: 12, text: 'The light handling here is unreal. What were you shooting with?',
    replies: [ { by: 'Mara Vey', avatar: 1, when: '3h', text: 'Mostly natural — one bounce, late afternoon.' } ] },
  { id: 'cm2', by: 'Nadia Œ', avatar: 0, when: '2h', up: 7, text: 'Saved to my crew board. We should talk about the exhibition.', replies: [] },
  { id: 'cm3', by: 'Ilo Bran', avatar: 2, when: '1h', up: 3, text: 'That edge treatment is exactly the register I was after.', replies: [] },
];

const WEB_THREAD = [
  { me: false, who: 'Søren K.', avatar: 3, text: 'Score draft for the main theme is up in the project.', when: '2:41' },
  { me: false, who: 'Søren K.', avatar: 3, text: 'Strings come in around 0:48 — tell me if it\u2019s too much.', when: '2:41' },
  { me: true,  text: 'Just listened. The swell is perfect. Maybe pull the reverb back 10%?', when: '2:44' },
  { me: false, who: 'Nadia Œ', avatar: 0, text: 'agreed, drier fits the grade', when: '2:45' },
  { me: true,  text: 'Let\u2019s lock it for picture this week then.', when: '2:46' },
];

const WEB_CREW_NAMES = { 0: 'Nadia', 1: 'Mara', 2: 'Ilo', 3: 'Søren' };

// Communities the user belongs to (Discover > Chat > Community)
const WEB_COMMUNITIES = [
  { id: 'cm1', name: 'Pune Filmmakers', members: '1.2k', art: 2, last: 'Aanya: anyone free for a weekend shoot?', when: '8m', unread: 5, online: true },
  { id: 'cm2', name: 'Indie DOPs', members: '860', art: 6, last: 'New thread — anamorphic on a budget', when: '1h', unread: 0, online: true },
  { id: 'cm3', name: 'Oslo Night Shooters', members: '312', art: 3, last: 'Karl shared a location pin', when: '3h', unread: 2, online: false },
  { id: 'cm4', name: 'Colour & Grade', members: '2.1k', art: 5, last: 'LUT pack v4 is up', when: '1d', unread: 0, online: false },
];

// Project team (Profile > Chat — team members only)
const WEB_TEAM = [
  { name: 'Mara Vey', avatar: 1, role: 'Painter', online: true },
  { name: 'Ilo Bran', avatar: 2, role: 'DOP', online: true },
  { name: 'Søren K.', avatar: 3, role: 'Score / 3D', online: false },
  { name: 'Nadia Œ', avatar: 0, role: 'Photographer', online: true },
];
const WEB_TEAM_THREAD = [
  { who: 1, name: 'Mara', text: 'Grade v3 is on the canvas — take a look when you can.', when: '9:02', me: false },
  { who: 2, name: 'Ilo', text: 'Negatives scanned, uploading the contact sheet now.', when: '9:14', me: false },
  { me: true, text: 'Perfect. Let’s lock picture by Friday.', when: '9:20' },
  { who: 3, name: 'Søren', text: 'Score stems ready whenever you are.', when: '9:26', me: false },
];

const WEB_ME = {
  name: 'Renn Okabe', handle: '@studio.noir', avatar: 3, art: 3,
  discipline: 'Director · Oil & light', city: 'Oslo, NO',
  bio: 'Night studies, slow work. Building small crews for short films and exhibitions. Commissions open.',
  stats: [ { value: '48', label: 'Works' }, { value: '4', label: 'Projects' }, { value: '1.2k', label: 'Followers' }, { value: '312', label: 'Following' } ],
  skills: ['Direction', 'Oil', 'Editing', 'Color', 'Curation'],
};

Object.assign(window, { WEB_PROJECTS, WEB_ARTISTS, DISCOVER_FILTERS, WEB_FEED, WEB_CHATS, WEB_THREAD, WEB_ME, WEB_TOOLS, WEB_COMMENTS, WEB_CREW_NAMES, WEB_COMMUNITIES, WEB_TEAM, WEB_TEAM_THREAD });
